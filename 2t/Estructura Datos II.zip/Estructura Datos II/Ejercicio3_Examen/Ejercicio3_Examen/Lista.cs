﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3_Examen
{
    class Lista
    {
        Nodo cabeza, nuevo;

        public Lista()
        {
            cabeza = null;
            nuevo = null;
        }

        public Nodo getCabeza()
        {
            return cabeza;
        }
        private void crearNodo(char letra)
        {
            nuevo = new Nodo();
            nuevo.setLetra(letra);
            nuevo.setSig(null);
        }

        public void agregar(char letra)
        {
            crearNodo(letra);
            if (cabeza == null)
            {

                
                cabeza = nuevo;
                
                
            }
            else
            {
                Nodo punt = cabeza;
                while (punt.getSig() != null)
                {
                    punt = punt.getSig();
                }
                punt.setSig(nuevo);
                nuevo.setAnt(punt);
            }
        }
        public bool palidromo()
        {
            Nodo principio = cabeza;
            while(principio.getSig() != null)
            {
                principio = principio.getSig();
            }
            Nodo final = principio;
            principio = cabeza;

            while(principio != null && final != null)
            {
                if(principio.getLetra() != final.getLetra())
                {
                    return false;
                }

                principio = principio.getSig();
                final = final.getAnt();
            }
            return true;
        }
    }
}
