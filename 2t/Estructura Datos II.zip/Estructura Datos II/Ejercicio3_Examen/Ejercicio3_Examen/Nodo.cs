﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3_Examen
{
    class Nodo
    {
        char letra;
        Nodo anterior;
        Nodo siguiente;
        public Nodo()
        {
            letra = ' ';
            anterior = null;
            siguiente = null;
        }

        public char getLetra()
        {
            return letra;
        }
        public Nodo getAnt()
        {
            return anterior;
        }
        public Nodo getSig()
        {
            return siguiente;
        }
        public void setLetra(char letra)
        {
            this.letra = letra;
        }
        public void setAnt(Nodo anterior)
        {
            this.anterior = anterior;
        }
        public void setSig(Nodo siguiente)
        {
            this.siguiente = siguiente;
        }
    }
}
