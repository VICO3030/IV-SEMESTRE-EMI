﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3_Examen
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {

            Estatica.palabra.agregar(char.Parse(txt_letra.Text));
            MessageBox.Show("Agregado");
            txt_letra.Clear();
        }
        public void mostrar()
        {
            lst_palabra.Items.Clear();
            Nodo punt = Estatica.palabra.getCabeza();
            while(punt != null)
            {
                lst_palabra.Items.Add(punt.getLetra());
                punt = punt.getSig();
            }
        }
        private void btn_evaluar_Click(object sender, EventArgs e)
        {
            mostrar();
            if (Estatica.palabra.palidromo())
            {
                lbl_respuesta.Text = "la palabra ingresada es palindromo";
            }
            else
            {
                lbl_respuesta.Text = "la palabra ingresada no es palindromo";
            }
        }

        private void frm_principal_Load(object sender, EventArgs e)
        {

        }
    }
}
