﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_2
{
    class Pila
    {
		NodoPila cima, nuevo;
		public Pila()
		{
			cima = null;
			nuevo = null;
		}
		//getters
		public NodoPila getCima() { return cima; }
		//setters
		public void setCima(NodoPila cima) { this.cima = cima; }
		//METODOS
		public void apilar(int num)
		{
			nuevo = new NodoPila(num);
			nuevo.Sig = cima;
			cima = nuevo;
		}
		public NodoPila desapilar()
		{
			NodoPila aux = cima;
			cima = cima.Sig;
			aux.Sig = null;
			return aux;
		}
		public bool vacia() { return cima == null; }
	}
}
