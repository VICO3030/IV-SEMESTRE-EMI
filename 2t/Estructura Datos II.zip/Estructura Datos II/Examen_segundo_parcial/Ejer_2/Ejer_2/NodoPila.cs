﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_2
{
    class NodoPila
    {
        int num;
        NodoPila siguiente;

        public NodoPila(int num)
        {
            this.num = num;
            siguiente = null;
        }

        public int Num { get => num; set => num = value; }
        public NodoPila Sig { get => siguiente; set => siguiente = value; }
    }
}
