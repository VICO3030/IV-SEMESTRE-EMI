﻿
namespace Ejer_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_apilar = new System.Windows.Forms.Button();
            this.btn_salir = new System.Windows.Forms.Button();
            this.lst_pila_ingresados = new System.Windows.Forms.ListBox();
            this.lst_pila_primos = new System.Windows.Forms.ListBox();
            this.btn_evaluar = new System.Windows.Forms.Button();
            this.lbl_n_primos = new System.Windows.Forms.Label();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_num
            // 
            this.txt_num.Location = new System.Drawing.Point(100, 6);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(100, 20);
            this.txt_num.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese dato:";
            // 
            // btn_apilar
            // 
            this.btn_apilar.Location = new System.Drawing.Point(125, 32);
            this.btn_apilar.Name = "btn_apilar";
            this.btn_apilar.Size = new System.Drawing.Size(75, 23);
            this.btn_apilar.TabIndex = 2;
            this.btn_apilar.Text = "Apilar";
            this.btn_apilar.UseVisualStyleBackColor = true;
            this.btn_apilar.Click += new System.EventHandler(this.btn_apilar_Click);
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(377, 136);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(75, 23);
            this.btn_salir.TabIndex = 3;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // lst_pila_ingresados
            // 
            this.lst_pila_ingresados.FormattingEnabled = true;
            this.lst_pila_ingresados.Location = new System.Drawing.Point(206, 6);
            this.lst_pila_ingresados.Name = "lst_pila_ingresados";
            this.lst_pila_ingresados.Size = new System.Drawing.Size(120, 95);
            this.lst_pila_ingresados.TabIndex = 4;
            // 
            // lst_pila_primos
            // 
            this.lst_pila_primos.FormattingEnabled = true;
            this.lst_pila_primos.Location = new System.Drawing.Point(332, 6);
            this.lst_pila_primos.Name = "lst_pila_primos";
            this.lst_pila_primos.Size = new System.Drawing.Size(120, 95);
            this.lst_pila_primos.TabIndex = 5;
            // 
            // btn_evaluar
            // 
            this.btn_evaluar.Location = new System.Drawing.Point(377, 107);
            this.btn_evaluar.Name = "btn_evaluar";
            this.btn_evaluar.Size = new System.Drawing.Size(75, 23);
            this.btn_evaluar.TabIndex = 6;
            this.btn_evaluar.Text = "Evaluar";
            this.btn_evaluar.UseVisualStyleBackColor = true;
            this.btn_evaluar.Click += new System.EventHandler(this.btn_evaluar_Click);
            // 
            // lbl_n_primos
            // 
            this.lbl_n_primos.AutoSize = true;
            this.lbl_n_primos.Location = new System.Drawing.Point(97, 136);
            this.lbl_n_primos.Name = "lbl_n_primos";
            this.lbl_n_primos.Size = new System.Drawing.Size(16, 13);
            this.lbl_n_primos.TabIndex = 7;
            this.lbl_n_primos.Text = "...";
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.Location = new System.Drawing.Point(296, 107);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(75, 23);
            this.btn_limpiar.TabIndex = 8;
            this.btn_limpiar.Text = "Limpiar";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 162);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.lbl_n_primos);
            this.Controls.Add(this.btn_evaluar);
            this.Controls.Add(this.lst_pila_primos);
            this.Controls.Add(this.lst_pila_ingresados);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.btn_apilar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_num);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_apilar;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.ListBox lst_pila_ingresados;
        private System.Windows.Forms.ListBox lst_pila_primos;
        private System.Windows.Forms.Button btn_evaluar;
        private System.Windows.Forms.Label lbl_n_primos;
        private System.Windows.Forms.Button btn_limpiar;
    }
}

