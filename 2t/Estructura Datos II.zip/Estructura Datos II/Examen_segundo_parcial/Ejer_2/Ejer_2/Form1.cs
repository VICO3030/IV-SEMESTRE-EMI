﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_2
{
    public partial class Form1 : Form
    {
        Pila pila = new Pila();
        Pila primos = new Pila();
        Pila pila_aux = new Pila();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_apilar_Click(object sender, EventArgs e)
        {
            pila.apilar(int.Parse(txt_num.Text));
            MessageBox.Show("Dato apilado");
            txt_num.Clear();
            mostrar_ingresados();
        }
        private void fillAux(Pila pila)
        {
            NodoPila aux;
            while (!pila.vacia())
            {
                aux = pila.desapilar();
                pila_aux.apilar(aux.Num);
            }
        }
        private void fillOrigin(Pila pila)
        {
            NodoPila aux;
            while (!pila_aux.vacia())
            {
                aux = pila_aux.desapilar();
                pila.apilar(aux.Num);
            }
        }
        public void mostrar_ingresados()
        {
            lst_pila_ingresados.Items.Clear();
            NodoPila aux;
            while (!pila.vacia())
            {
                aux = pila.desapilar();
                lst_pila_ingresados.Items.Add(aux.Num);
                pila_aux.apilar(aux.Num);
            }
            fillOrigin(pila);
        }
        public void mostrar_primos()
        {
            lst_pila_primos.Items.Clear();
            NodoPila aux;
            while (!primos.vacia())
            {
                aux = primos.desapilar();
                lst_pila_primos.Items.Add(aux.Num);
                pila_aux.apilar(aux.Num);
            }
            fillOrigin(primos);
        }
        public bool es_primo(int num)
        {
            int c = 2;
            while(c < num)
            {
                if (num % c == 0) return false;
                c++;
            }
            return true;
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public int contar_primos()
        {
            int c = 0;
            fillAux(primos);
            NodoPila aux;
            while (!pila_aux.vacia())
            {
                aux = pila_aux.desapilar();
                c++;
                primos.apilar(aux.Num);
            }
            return c;
        }
        private void btn_evaluar_Click(object sender, EventArgs e)
        {
            fillAux(pila);
            NodoPila aux;
            while (!pila_aux.vacia())
            {
                aux = pila_aux.desapilar();
                if (es_primo(aux.Num))
                    primos.apilar(aux.Num);
                else
                    pila.apilar(aux.Num);
            }
            mostrar_ingresados();
            mostrar_primos();
            lbl_n_primos.Text = "NUMEROS PRIMOS ENCONTRADOS: " + contar_primos().ToString();
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            lst_pila_ingresados.Items.Clear();
            lst_pila_primos.Items.Clear();
        }
    }
}
