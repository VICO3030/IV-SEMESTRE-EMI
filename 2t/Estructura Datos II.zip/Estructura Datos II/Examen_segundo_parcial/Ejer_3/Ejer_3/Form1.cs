﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_3
{
    public partial class Form1 : Form
    {
        Cola cola = new Cola();
        Cola atendidos = new Cola();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void mostrar()
        {
            int i = 1;
            lst_generada.Items.Clear();
            NodoCola punt = cola.get_frente();
            while(punt != null)
            {
                lst_generada.Items.Add("Carnet #" + i.ToString() + ": " + punt.Ci.ToString());
                punt = punt.Sig;
                i++;
            }
        }
        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            for(int i = 1; i<=int.Parse(txt_n.Text); i++)
            {
                cola.encolar(rnd.Next(10000, 99999));
            }
            MessageBox.Show("Cola generada");
            mostrar();
        }

        public int last_digit(int num)
        {
            return num % 10;
        }
        public void vaciar_cola(int digito)
        {
            NodoCola punt = cola.get_frente();
            while (punt != null)
            {
                
                punt = punt.Sig;
            }
        }
        public void llenar_atendidos(int digito)
        {
            NodoCola punt = cola.get_frente();
            while(punt != null)
            {
                if (last_digit(punt.Ci) == digito) atendidos.encolar(punt.Ci);
                punt = punt.Sig;
            }


        }
        private void btn_atender_Click(object sender, EventArgs e)
        {


        }
    }
}
