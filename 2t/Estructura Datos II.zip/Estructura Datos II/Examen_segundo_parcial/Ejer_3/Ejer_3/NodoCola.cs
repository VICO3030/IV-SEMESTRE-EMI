﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_3
{
    class NodoCola
    {
        int ci;
        NodoCola siguiente;

        public NodoCola(int ci)
        {
            this.ci = ci;
            siguiente = null;
        }

        public int Ci { get => ci; set => ci = value; }
        public NodoCola Sig { get => siguiente; set => siguiente = value; }
    }
}
