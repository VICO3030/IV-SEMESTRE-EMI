﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_3
{
    class Cola
    {
		NodoCola frente, final, nuevo;
		//CONSTRUCTOR
		public Cola()
		{
			frente = null;
			final = null;
			nuevo = null;
		}
		//getters y setters
		public NodoCola get_frente() { return frente; }
		public NodoCola get_final() { return final; }
		//metodos
		public void encolar(int num)
		{
			nuevo = new NodoCola(num);
			if (frente == null) frente = nuevo;
			else final.Sig = nuevo;
			final = nuevo;
		}
		public NodoCola desencolar()
		{
			NodoCola aux;
			aux = frente;
			frente = frente.Sig;
			aux.Sig = null;
			return aux;
		}
		public void eliminar(int num)
		{
			NodoCola anterior = frente, actual = anterior.Sig;

			while (actual != null)
			{
				if (actual.Ci == num) break;
				anterior = actual;
				actual = actual.Sig;
			}

			anterior.Sig = actual.Sig;
			actual.Sig = null;
		}
		public bool existe(int num)
        {
			NodoCola punt = frente;
			while(punt != null)
            {
				if (punt.Ci == num) return true;
				punt = punt.Sig;
            }
			return false;
        }
	}
}
