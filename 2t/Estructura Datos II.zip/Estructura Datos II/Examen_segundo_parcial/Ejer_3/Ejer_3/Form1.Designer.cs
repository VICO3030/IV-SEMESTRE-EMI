﻿
namespace Ejer_3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_n = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.lst_generada = new System.Windows.Forms.ListBox();
            this.lst_atendidos = new System.Windows.Forms.ListBox();
            this.btn_atender = new System.Windows.Forms.Button();
            this.btn_salir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_dias = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_dia = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_n
            // 
            this.txt_n.Location = new System.Drawing.Point(15, 25);
            this.txt_n.Name = "txt_n";
            this.txt_n.Size = new System.Drawing.Size(100, 20);
            this.txt_n.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese numero de personas";
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.Location = new System.Drawing.Point(15, 51);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(75, 23);
            this.btn_aceptar.TabIndex = 2;
            this.btn_aceptar.Text = "Aceptar";
            this.btn_aceptar.UseVisualStyleBackColor = true;
            this.btn_aceptar.Click += new System.EventHandler(this.btn_aceptar_Click);
            // 
            // lst_generada
            // 
            this.lst_generada.FormattingEnabled = true;
            this.lst_generada.Location = new System.Drawing.Point(242, 25);
            this.lst_generada.Name = "lst_generada";
            this.lst_generada.Size = new System.Drawing.Size(120, 95);
            this.lst_generada.TabIndex = 3;
            // 
            // lst_atendidos
            // 
            this.lst_atendidos.FormattingEnabled = true;
            this.lst_atendidos.Location = new System.Drawing.Point(368, 25);
            this.lst_atendidos.Name = "lst_atendidos";
            this.lst_atendidos.Size = new System.Drawing.Size(120, 95);
            this.lst_atendidos.TabIndex = 4;
            // 
            // btn_atender
            // 
            this.btn_atender.Location = new System.Drawing.Point(413, 126);
            this.btn_atender.Name = "btn_atender";
            this.btn_atender.Size = new System.Drawing.Size(75, 23);
            this.btn_atender.TabIndex = 5;
            this.btn_atender.Text = "Atender";
            this.btn_atender.UseVisualStyleBackColor = true;
            this.btn_atender.Click += new System.EventHandler(this.btn_atender_Click);
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(413, 155);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(75, 23);
            this.btn_salir.TabIndex = 6;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Elija el dia de atencion";
            // 
            // cmb_dias
            // 
            this.cmb_dias.FormattingEnabled = true;
            this.cmb_dias.Items.AddRange(new object[] {
            "Lunes",
            "Martes",
            "Miercoles",
            "Jueves",
            "Viernes"});
            this.cmb_dias.Location = new System.Drawing.Point(15, 93);
            this.cmb_dias.Name = "cmb_dias";
            this.cmb_dias.Size = new System.Drawing.Size(121, 21);
            this.cmb_dias.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Para atender";
            // 
            // lbl_dia
            // 
            this.lbl_dia.AutoSize = true;
            this.lbl_dia.Location = new System.Drawing.Point(368, 9);
            this.lbl_dia.Name = "lbl_dia";
            this.lbl_dia.Size = new System.Drawing.Size(16, 13);
            this.lbl_dia.TabIndex = 10;
            this.lbl_dia.Text = "...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 185);
            this.Controls.Add(this.lbl_dia);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmb_dias);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.btn_atender);
            this.Controls.Add(this.lst_atendidos);
            this.Controls.Add(this.lst_generada);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_n);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_n;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.ListBox lst_generada;
        private System.Windows.Forms.ListBox lst_atendidos;
        private System.Windows.Forms.Button btn_atender;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_dias;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_dia;
    }
}

