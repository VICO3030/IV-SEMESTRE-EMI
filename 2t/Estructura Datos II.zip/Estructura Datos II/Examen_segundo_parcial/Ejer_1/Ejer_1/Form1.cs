﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_1
{
    
    public partial class Form1 : Form
    {
        ListaCircular lista = new ListaCircular();
        int suma = 0;
        NodoCircular punt_suma;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            lista.agregar(int.Parse(txt_dato.Text));
            MessageBox.Show("Dato agregado");
        }

        public void mostrar()
        {
            lst_lista.Items.Clear();
            NodoCircular punt = lista.getCabeza();
            do
            {
                lst_lista.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            } while (punt != lista.getCabeza());
        }
        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            mostrar();
            punt_suma = lista.getCabeza();
        }

        private void btn_sumar_Click(object sender, EventArgs e)
        {
            NodoCircular punt = lista.getCabeza();
            for(int i = 0; i<int.Parse(txt_suma.Text); i++)
            {
                punt = punt.getEnlace();
            }
            if(int.Parse(txt_suma.Text) != 0)
            {
                suma += punt.getNum();
                lst_sumas.Items.Add(punt.getNum());
            }

            lbl_suma.Text = suma.ToString();
        }
    }
}
