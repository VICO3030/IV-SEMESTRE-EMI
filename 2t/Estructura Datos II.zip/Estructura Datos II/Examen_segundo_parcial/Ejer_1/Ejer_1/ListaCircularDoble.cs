﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_1
{
    class ListaCircular
    {
        NodoCircular cabeza, ultimo, nuevo;
        public ListaCircular()
        {
            cabeza = null;
            ultimo = null;
            nuevo = null;
        }
        public NodoCircular getCabeza()
        {
            return cabeza;
        }
        public void newNode(int num)
        {
            nuevo = new NodoCircular();
            nuevo.setNum(num);
        }
        public void agregar(int num)
        {
            newNode(num);
            if (cabeza == null) cabeza = nuevo;
            else ultimo.setEnlace(nuevo);

            ultimo = nuevo;
            ultimo.setEnlace(cabeza);
        }
        public NodoCircular existe(int num)
        {
            NodoCircular punt = cabeza;
            do
            {
                if (punt.getNum() == num) return punt;
                punt = punt.getEnlace();
            } while (punt != cabeza);

            return null;
        }
        public void eliminar(int num)
        {
            if (cabeza != null)
            {
                NodoCircular actual = cabeza, anterior = null;
                bool encontrado = false;
                do
                {
                    if (actual.getNum() == num)
                    {
                        //primer caso eliminacion de la cabeza
                        if (actual == cabeza)
                        {
                            cabeza = cabeza.getEnlace();
                            ultimo.setEnlace(cabeza);
                        }
                        //segundo caso eliminacion del ultimo 
                        else if (actual == ultimo)
                        {
                            anterior.setEnlace(cabeza);
                            ultimo = anterior;
                        }
                        // tercer caso, en cualquier otra posicion
                        else
                        {
                            anterior.setEnlace(actual.getEnlace());
                        }

                        encontrado = true;
                    }
                    anterior = actual;
                    actual = actual.getEnlace();
                } while (actual != cabeza && encontrado == false);
            }
        }
        public void ordenar()
        {
            NodoCircular punt = cabeza, punt2;
            int aux;
            do
            {
                punt2 = punt.getEnlace();
                do
                {
                    if (punt.getNum() > punt2.getNum())
                    {
                        aux = punt.getNum();
                        punt.setNum(punt2.getNum());
                        punt2.setNum(aux);
                    }
                    punt2 = punt2.getEnlace();
                } while (punt2 != cabeza);
                punt = punt.getEnlace();
            } while (punt != ultimo);
        }
        public void insertar(int num)
        {
            ordenar();
            newNode(num);
            if (nuevo.getNum() < cabeza.getNum())
            {
                nuevo.setEnlace(cabeza);
                cabeza = nuevo;
                ultimo.setEnlace(cabeza);
            }
            else if (nuevo.getNum() > ultimo.getNum())
            {
                ultimo.setEnlace(nuevo);
                ultimo = nuevo;
                ultimo.setEnlace(cabeza);
            }
            else
            {
                NodoCircular ant = ultimo, actual = cabeza;
                while (actual.getNum() < nuevo.getNum())
                {
                    ant = actual;
                    actual = actual.getEnlace();
                }
                ant.setEnlace(nuevo);
                nuevo.setEnlace(actual);
            }
        }
    }

}

