﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_1
{
    class NodoCircular
    {
        int num;
        NodoCircular enlace;

        public NodoCircular()
        {
            num = 0;
            enlace = null;
        }
        public int getNum() { return num; }
        public void setNum(int num) { this.num = num; }
        public NodoCircular getEnlace() { return enlace; }
        public void setEnlace(NodoCircular enlace) { this.enlace = enlace; }
        
    }
}
