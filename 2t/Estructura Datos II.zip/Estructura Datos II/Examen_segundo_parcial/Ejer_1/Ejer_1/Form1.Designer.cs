﻿
namespace Ejer_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_dato = new System.Windows.Forms.TextBox();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.lst_sumas = new System.Windows.Forms.ListBox();
            this.btn_sumar = new System.Windows.Forms.Button();
            this.txt_suma = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_suma = new System.Windows.Forms.Label();
            this.lst_lista = new System.Windows.Forms.ListBox();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese dato";
            // 
            // txt_dato
            // 
            this.txt_dato.Location = new System.Drawing.Point(84, 6);
            this.txt_dato.Name = "txt_dato";
            this.txt_dato.Size = new System.Drawing.Size(100, 20);
            this.txt_dato.TabIndex = 1;
            // 
            // btn_insertar
            // 
            this.btn_insertar.Location = new System.Drawing.Point(109, 32);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(75, 23);
            this.btn_insertar.TabIndex = 2;
            this.btn_insertar.Text = "insertar";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // lst_sumas
            // 
            this.lst_sumas.FormattingEnabled = true;
            this.lst_sumas.Location = new System.Drawing.Point(331, 12);
            this.lst_sumas.Name = "lst_sumas";
            this.lst_sumas.Size = new System.Drawing.Size(120, 95);
            this.lst_sumas.TabIndex = 3;
            // 
            // btn_sumar
            // 
            this.btn_sumar.Location = new System.Drawing.Point(178, 159);
            this.btn_sumar.Name = "btn_sumar";
            this.btn_sumar.Size = new System.Drawing.Size(75, 23);
            this.btn_sumar.TabIndex = 4;
            this.btn_sumar.Text = "sumar";
            this.btn_sumar.UseVisualStyleBackColor = true;
            this.btn_sumar.Click += new System.EventHandler(this.btn_sumar_Click);
            // 
            // txt_suma
            // 
            this.txt_suma.Location = new System.Drawing.Point(153, 133);
            this.txt_suma.Name = "txt_suma";
            this.txt_suma.Size = new System.Drawing.Size(100, 20);
            this.txt_suma.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ingrese posicion a sumar";
            // 
            // lbl_suma
            // 
            this.lbl_suma.AutoSize = true;
            this.lbl_suma.Location = new System.Drawing.Point(34, 164);
            this.lbl_suma.Name = "lbl_suma";
            this.lbl_suma.Size = new System.Drawing.Size(16, 13);
            this.lbl_suma.TabIndex = 7;
            this.lbl_suma.Text = "...";
            // 
            // lst_lista
            // 
            this.lst_lista.FormattingEnabled = true;
            this.lst_lista.Location = new System.Drawing.Point(205, 12);
            this.lst_lista.Name = "lst_lista";
            this.lst_lista.Size = new System.Drawing.Size(120, 95);
            this.lst_lista.TabIndex = 8;
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(250, 113);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(75, 23);
            this.btn_mostrar.TabIndex = 9;
            this.btn_mostrar.Text = "mostrar";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.lst_lista);
            this.Controls.Add(this.lbl_suma);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_suma);
            this.Controls.Add(this.btn_sumar);
            this.Controls.Add(this.lst_sumas);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.txt_dato);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_dato;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.ListBox lst_sumas;
        private System.Windows.Forms.Button btn_sumar;
        private System.Windows.Forms.TextBox txt_suma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_suma;
        private System.Windows.Forms.ListBox lst_lista;
        private System.Windows.Forms.Button btn_mostrar;
    }
}

