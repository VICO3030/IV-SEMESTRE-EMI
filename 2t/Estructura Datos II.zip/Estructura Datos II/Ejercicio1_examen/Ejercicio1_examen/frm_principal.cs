﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1_examen
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            Estatica.lista_l.agregar(int.Parse(txt_numero.Text));
            MessageBox.Show("Agregado");
            txt_numero.Clear();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            frm_mostrar mostrar = new frm_mostrar();
            this.Hide();
            mostrar.Show();
        }
    }
}
