﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1_examen
{
    class Lista
    {
        Nodo cabeza;
        Nodo nuevo;

        public Lista()
        {
            cabeza = null;
            nuevo = null;
        }

        public Nodo getCabeza()
        {
            return cabeza;
        }
        private void crearNodo(int numero)
        {
            nuevo = new Nodo();
            nuevo.setNum(numero);
            nuevo.setEnlace(null);
        }

        public void agregar(int numero)
        {
            crearNodo(numero);
            if(cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                Nodo punt = cabeza;
                while(punt.getEnlace() != null)
                {
                    punt = punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }
        }
        public int repite(int x)
        {
            Nodo punt = cabeza;
            int c = 0;
            while(punt != null)
            {
                if (punt.getNum() == x) c ++;
                punt = punt.getEnlace();
            }
            return c;
        }
        public Nodo busca(int x)
        {
            Nodo punt = cabeza;
            while(punt != null)
            {
                if (punt.getNum() == x) return punt;
                punt = punt.getEnlace();
            }
            return null;
        }
        public void eliminarNodo(Nodo nodo)
        {
            if (nodo == cabeza) cabeza = cabeza.getEnlace();
            else
            {
                Nodo anterior = cabeza, actual = anterior.getEnlace();
                
                while(actual != null)
                {
                    if(nodo == actual)
                    {
                        anterior.setEnlace(actual.getEnlace());
                        actual.setEnlace(null);
                    }
                    anterior = anterior.getEnlace();
                    actual = actual.getEnlace();
                }
            }
        }
        public void eliminar_repetidos(int p)
        {
            if (busca(p) != null)
            {
                eliminarNodo(busca(p));
                eliminar_repetidos(p);
            }
        }
    }
}
