﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1_examen
{
    class Estatica
    {
        public static Lista lista_l = new Lista();
        public static Lista lista_r = new Lista();
    }
}
