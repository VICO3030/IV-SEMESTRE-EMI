﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1_examen
{
    public partial class frm_mostrar : Form
    {
        public frm_mostrar()
        {
            InitializeComponent();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_principal principal = new frm_principal();
            this.Close();
            principal.Show();
        }
        public void mostrarL()
        {
            lst_listaL.Items.Clear();
            Nodo punt = Estatica.lista_l.getCabeza();
            while(punt != null)
            {
                lst_listaL.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
        }
        public void mostrarR()
        {
            lst_listaR.Items.Clear();
            Nodo punt = Estatica.lista_r.getCabeza();
            while (punt != null)
            {
                lst_listaR.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
        }
        public void lista_repetidos()
        {
            
            Nodo punt = Estatica.lista_l.getCabeza();
            int rep;
            while (punt != null)
            {
                rep = Estatica.lista_l.repite(punt.getNum());
                if (rep > 1)
                {
                    Estatica.lista_r.agregar(punt.getNum());
                    Estatica.lista_l.eliminar_repetidos(punt.getNum());
                }
                punt = punt.getEnlace();
            }
            
        }
        private void frm_mostrar_Load(object sender, EventArgs e)
        {
            lista_repetidos();
            if(Estatica.lista_r.getCabeza() == null)
            {
                lst_listaR.Items.Clear();
                MessageBox.Show("Nos se repite ningun elemento");
                lst_listaR.Items.Add("LISTA VACIA");
            }
            else
            {
                mostrarR();
                
            }
            mostrarL();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
