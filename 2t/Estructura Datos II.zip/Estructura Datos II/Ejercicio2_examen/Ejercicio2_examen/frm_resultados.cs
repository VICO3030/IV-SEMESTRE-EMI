﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio2_examen
{
    public partial class frm_resultados : Form
    {
        public frm_resultados()
        {
            InitializeComponent();
        }

        private void frm_resultados_Load(object sender, EventArgs e)
        {
            Nodo punt = Estatica.lista1.getCabeza();
            while(punt != null)
            {
                lst_lista1.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
            punt = Estatica.lista2.getCabeza();
            while(punt != null)
            {
                lst_lista2.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
            juntar();
            punt = Estatica.lista3.getCabeza();
            while(punt != null)
            {
                lst_listacombinada.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
        }
        public void juntar()
        {
            Nodo punt1 = Estatica.lista1.getCabeza();
            Nodo punt2 = Estatica.lista2.getCabeza();
            while(punt1 != null && punt2 != null)
            {
                Estatica.lista3.agregar(punt1.getNum());
                Estatica.lista3.agregar(punt2.getNum());
                punt1 = punt1.getEnlace();
                punt2 = punt2.getEnlace();
            }

        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            frm_principal principal = new frm_principal();
            this.Close();
            principal.Show();
        }
    }
}
