﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_examen
{
    class Nodo
    {
        int numero;
        Nodo enlace;

        public Nodo()
        {
            numero = 0;
            enlace = null;
        }

        //getters
        public int getNum()
        {
            return numero;
        }
        public Nodo getEnlace()
        {
            return enlace;
        }
        //setters
        public void setNum(int numero)
        {
            this.numero = numero;
        }
        public void setEnlace(Nodo enlace)
        {
            this.enlace = enlace;
        }
    }
}
