﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio2_examen
{
    public partial class frm_llenar_listas : Form
    {
        public int c1 = 0;
        public int c2 = 0;
        public frm_llenar_listas()
        {
            InitializeComponent();
        }

        private void btn_agregar_l1_Click(object sender, EventArgs e)
        {
            if (c1 < Estatica.n)
            {
                Estatica.lista1.agregar(int.Parse(txt_numero_l1.Text));
                MessageBox.Show("agregado");
            }
            else
            {     
                MessageBox.Show("Limite alcanzado");
                btn_agregar_l1.Enabled = false;
                btn_agregar_l2.Enabled = true;
            }

            c1++;
        }

        private void btn_agregar_l2_Click(object sender, EventArgs e)
        {
            if (c2 < Estatica.n)
            {
                Estatica.lista2.agregar(int.Parse(txt_numero_l2.Text));
                MessageBox.Show("agregado");
            }
            else
            {
                MessageBox.Show("Limite alcanzado");
                btn_agregar_l2.Enabled = false;
            }

            c2++;
        }

        private void frm_llenar_listas_Load(object sender, EventArgs e)
        {

        }

        private void btn_terminar_Click(object sender, EventArgs e)
        {
            if(Estatica.lista1.getCabeza() != null && Estatica.lista2.getCabeza() != null)
            {
                frm_resultados resultados = new frm_resultados();
                this.Hide();
                resultados.Show();
            }
            else
            {
                MessageBox.Show("Lista vacia");
            }
            
        }
    }
}
