﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_examen
{
    class Estatica
    {
        public static Lista lista1 = new Lista();
        public static Lista lista2 = new Lista();
        public static Lista lista3 = new Lista();
        public static int n;
    }
}
