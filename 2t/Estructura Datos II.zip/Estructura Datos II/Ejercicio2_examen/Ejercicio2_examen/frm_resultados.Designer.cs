﻿
namespace Ejercicio2_examen
{
    partial class frm_resultados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_lista1 = new System.Windows.Forms.ListBox();
            this.lst_lista2 = new System.Windows.Forms.ListBox();
            this.lst_listacombinada = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lst_lista1
            // 
            this.lst_lista1.FormattingEnabled = true;
            this.lst_lista1.Location = new System.Drawing.Point(13, 19);
            this.lst_lista1.Name = "lst_lista1";
            this.lst_lista1.Size = new System.Drawing.Size(120, 95);
            this.lst_lista1.TabIndex = 0;
            // 
            // lst_lista2
            // 
            this.lst_lista2.FormattingEnabled = true;
            this.lst_lista2.Location = new System.Drawing.Point(139, 19);
            this.lst_lista2.Name = "lst_lista2";
            this.lst_lista2.Size = new System.Drawing.Size(120, 95);
            this.lst_lista2.TabIndex = 1;
            // 
            // lst_listacombinada
            // 
            this.lst_listacombinada.FormattingEnabled = true;
            this.lst_listacombinada.Location = new System.Drawing.Point(265, 19);
            this.lst_listacombinada.Name = "lst_listacombinada";
            this.lst_listacombinada.Size = new System.Drawing.Size(120, 95);
            this.lst_listacombinada.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lst_lista2);
            this.groupBox1.Controls.Add(this.lst_listacombinada);
            this.groupBox1.Controls.Add(this.lst_lista1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 158);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Location = new System.Drawing.Point(338, 176);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(75, 23);
            this.btn_cerrar.TabIndex = 4;
            this.btn_cerrar.Text = "Cerrar";
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // frm_resultados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 208);
            this.Controls.Add(this.btn_cerrar);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_resultados";
            this.Text = "frm_resultados";
            this.Load += new System.EventHandler(this.frm_resultados_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lst_lista1;
        private System.Windows.Forms.ListBox lst_lista2;
        private System.Windows.Forms.ListBox lst_listacombinada;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_cerrar;
    }
}