﻿
namespace Ejercicio2_examen
{
    partial class frm_llenar_listas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_numero_l1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_agregar_l1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_numero_l2 = new System.Windows.Forms.TextBox();
            this.btn_agregar_l2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_terminar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_numero_l1
            // 
            this.txt_numero_l1.Location = new System.Drawing.Point(147, 19);
            this.txt_numero_l1.Name = "txt_numero_l1";
            this.txt_numero_l1.Size = new System.Drawing.Size(100, 20);
            this.txt_numero_l1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese numero";
            // 
            // btn_agregar_l1
            // 
            this.btn_agregar_l1.Location = new System.Drawing.Point(172, 45);
            this.btn_agregar_l1.Name = "btn_agregar_l1";
            this.btn_agregar_l1.Size = new System.Drawing.Size(75, 23);
            this.btn_agregar_l1.TabIndex = 2;
            this.btn_agregar_l1.Text = "Agregar";
            this.btn_agregar_l1.UseVisualStyleBackColor = true;
            this.btn_agregar_l1.Click += new System.EventHandler(this.btn_agregar_l1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_numero_l1);
            this.groupBox1.Controls.Add(this.btn_agregar_l1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(255, 79);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lista 1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_numero_l2);
            this.groupBox2.Controls.Add(this.btn_agregar_l2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(273, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 79);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lista 2";
            // 
            // txt_numero_l2
            // 
            this.txt_numero_l2.Location = new System.Drawing.Point(147, 19);
            this.txt_numero_l2.Name = "txt_numero_l2";
            this.txt_numero_l2.Size = new System.Drawing.Size(100, 20);
            this.txt_numero_l2.TabIndex = 0;
            // 
            // btn_agregar_l2
            // 
            this.btn_agregar_l2.Enabled = false;
            this.btn_agregar_l2.Location = new System.Drawing.Point(172, 45);
            this.btn_agregar_l2.Name = "btn_agregar_l2";
            this.btn_agregar_l2.Size = new System.Drawing.Size(75, 23);
            this.btn_agregar_l2.TabIndex = 2;
            this.btn_agregar_l2.Text = "Agregar";
            this.btn_agregar_l2.UseVisualStyleBackColor = true;
            this.btn_agregar_l2.Click += new System.EventHandler(this.btn_agregar_l2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ingrese numero";
            // 
            // btn_terminar
            // 
            this.btn_terminar.Location = new System.Drawing.Point(453, 97);
            this.btn_terminar.Name = "btn_terminar";
            this.btn_terminar.Size = new System.Drawing.Size(75, 23);
            this.btn_terminar.TabIndex = 3;
            this.btn_terminar.Text = "Terminar";
            this.btn_terminar.UseVisualStyleBackColor = true;
            this.btn_terminar.Click += new System.EventHandler(this.btn_terminar_Click);
            // 
            // frm_llenar_listas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 129);
            this.Controls.Add(this.btn_terminar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_llenar_listas";
            this.Text = "frm_llenar_listas";
            this.Load += new System.EventHandler(this.frm_llenar_listas_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txt_numero_l1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_agregar_l1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_numero_l2;
        private System.Windows.Forms.Button btn_agregar_l2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_terminar;
    }
}