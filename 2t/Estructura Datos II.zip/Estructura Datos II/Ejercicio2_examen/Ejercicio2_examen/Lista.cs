﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_examen
{
    class Lista
    {
        int n = 0;
        Nodo cabeza, nuevo;
        //constructor
        public Lista()
        {
            cabeza = null;
            nuevo = null;
        }

        //getters
        public Nodo getCabeza()
        {
            return cabeza;
        }
        public int getN()
        {
            return n;
        }

        //setters
        public void setCabeza(Nodo cabeza)
        {
            this.cabeza = cabeza;
        }
        
        //metodos
        private void crearNodo(int numero)
        {
            nuevo = new Nodo();
            nuevo.setNum(numero);
            nuevo.setEnlace(null);
        }

        public void agregar(int numero)
        {
            crearNodo(numero);
            if(cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                Nodo punt = cabeza;
                while(punt.getEnlace() != null)
                {
                    punt = punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }
        }

    }
}
