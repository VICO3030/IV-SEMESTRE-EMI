﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepasoListas
{
    class NodoSimple
    {
        string nombre;
        int edad;
        NodoSimple enlace;

        //constructor
        public NodoSimple()
        {
            nombre = "";
            edad = 0;
            enlace = null;
        }

        //getters
        public string getNom()
        {
            return nombre;
        }
        public int getEd()
        {
            return edad;
        }
        public NodoSimple getEnlace()
        {
            return enlace;
        }

        //setters
        public void setNom(string nombre)
        {
            this.nombre = nombre;
        }
        public void setEd(int edad)
        {
            this.edad = edad;
        }
        public void setEnlace(NodoSimple enlace)
        {
            this.enlace = enlace;
        }
    }
}
