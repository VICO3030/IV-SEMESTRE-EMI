﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepasoListas
{
    class ListaSimple
    {
        NodoSimple cabeza, nuevo;

        //constructor
        public ListaSimple()
        {
            cabeza = null;
            nuevo = null;
        }

        //getters
        public NodoSimple getCabeza()
        {
            return cabeza;
        }

        //metodos
        private void crearNuevo(string nombre, int edad)
        {
            nuevo = new NodoSimple();
            nuevo.setNom(nombre);
            nuevo.setEd(edad);
            nuevo.setEnlace(null);
        }
        public void agregar(string nombre, int edad)
        {
            crearNuevo(nombre, edad);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                NodoSimple punt = cabeza;
                while (punt.getEnlace() != null)
                {
                    punt = punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }
        }
        public NodoSimple mayorEd()
        {
            NodoSimple punt = cabeza, aux = new NodoSimple();
            int menor = int.MaxValue;
            while (punt != null)
            {
                if (punt.getEd() < menor)
                {
                    menor = punt.getEd();
                    aux.setEd(punt.getEd());
                    aux.setNom(punt.getNom());
                }
                punt = punt.getEnlace();
            }
            return aux;
        }
        public NodoSimple menorEd()
        {
            NodoSimple punt = cabeza, aux = new NodoSimple();
            int menor = int.MinValue;
            while (punt != null)
            {
                if (punt.getEd() > menor)
                {
                    menor = punt.getEd();
                    aux.setEd(punt.getEd());
                    aux.setNom(punt.getNom());
                }
                punt = punt.getEnlace();
            }
            return aux;
        }
        public float ageAvrg()
        {
            NodoSimple punt = cabeza;
            float s = 0;
            int c = 0;
            while(punt != null)
            {
                s += punt.getEd(); 
                punt = punt.getEnlace();
                c++;
            }

            return s / c; 
        }
        //edicion
        public bool buscarNombre(string nombre)
        {
            NodoSimple punt = cabeza;
            while(punt != null)
            {
                if(punt.getNom() == nombre) return true;
                punt = punt.getEnlace();
            }
            return false;
        }
        public bool buscarEdad(int edad)
        {
            NodoSimple punt = cabeza;
            while(punt != null)
            {
                if (punt.getEd() == edad) return true;
                punt = punt.getEnlace();
            }
            return false;
        }
        public NodoSimple nodoNombre(string nombre)
        {
            NodoSimple punt = cabeza;
            while (punt != null)
            {
                if (punt.getNom() == nombre) return punt;
                punt = punt.getEnlace();
            }
            return null;
        }
        public NodoSimple nodoEdad(int edad)
        {
            NodoSimple punt = cabeza;
            while (punt != null)
            {
                if (punt.getEd() == edad) return punt;
                punt = punt.getEnlace();
            }
            return null;
        }
        public void eliminar(string nombre)
        {
            if(cabeza.getNom() == nombre)
            {
                NodoSimple aux = cabeza;
                cabeza = cabeza.getEnlace();
                aux.setEnlace(null);
            }
            else
            {
                NodoSimple actual = cabeza, anterior = null;
                while (actual != null && actual.getNom() != nombre)
                {
                    anterior = actual;
                    actual = actual.getEnlace();
                }
                if (actual != null)
                {
                    anterior.setEnlace(actual.getEnlace());
                    actual.setEnlace(null);
                }
            }
        }
        public void ordNombre()
        {
            NodoSimple punt = cabeza, punt2;
            int aux1;
            string aux2;
            while(punt != null)
            {
                punt2 = punt.getEnlace();
                while(punt2 != null)
                {
                    if(punt.getNom().CompareTo(punt2.getNom()) > 0)
                    {
                        aux1 = punt.getEd();
                        aux2 = punt.getNom();
                        punt.setEd(punt2.getEd());
                        punt.setNom(punt2.getNom());
                        punt2.setEd(aux1);
                        punt2.setNom(aux2);
                    }
                    punt2 = punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }
        }
    }
}
