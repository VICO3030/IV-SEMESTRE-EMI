﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepasoListas
{
    class Estatica
    {
        public static ListaSimple estudiantes = new ListaSimple();
    }
}
