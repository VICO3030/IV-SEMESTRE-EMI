﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RepasoListas
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        public void clearTxtBxs()
        {
            txt_ed.Clear();
            txt_nom.Clear();
        }
        public void mostrar()
        {
            lst_mostrar.Items.Clear();
            NodoSimple punt = Estatica.estudiantes.getCabeza();
            if(punt == null)
            {
                MessageBox.Show("Lista vacia");
                return;
            }
            while(punt!= null)
            {
                lst_mostrar.Items.Add("Nombre: " + punt.getNom());
                lst_mostrar.Items.Add("Edad: " + punt.getEd());
                lst_mostrar.Items.Add("==============================");
                punt = punt.getEnlace();
            }
        }
        private void btn_reg_Click(object sender, EventArgs e)
        {
            Estatica.estudiantes.agregar(txt_nom.Text, int.Parse(txt_ed.Text));
            clearTxtBxs();
            MessageBox.Show("Estudiante Registrado");
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            clearTxtBxs();
            lst_mostrar.Items.Clear();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            rdb_edad.Enabled = true;
            rdb_nombre.Enabled = true;
            mostrar();
        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            if(Estatica.estudiantes.getCabeza() != null)
            {
                frm_informacion info = new frm_informacion();
                info.Show();
            }
            else
            {
                MessageBox.Show("Lista Vacia");
            }
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            if(Estatica.estudiantes.getCabeza()!= null)
            {
                frm_editar editar = new frm_editar();
                editar.Show();
            }
            else
            {
                MessageBox.Show("Lista Vacia");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Estatica.estudiantes.ordNombre();
            mostrar();
            rdb_nombre.Enabled = false;
            rdb_edad.Enabled = false;
        }
    }
}
