﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RepasoListas
{
    public partial class frm_editar : Form
    {
        int opcionBusqueda = 0;
        int opcionCambio = 0;
        NodoSimple encontrado;
        public frm_editar()
        {
            InitializeComponent();
        }

        private void btn_buscar_nombre_Click(object sender, EventArgs e)
        {
            opcionBusqueda = 0;
            txt_abuscar.Enabled = true;
            btn_busqueda.Enabled = true;
        }

        private void btn_bucar_edad_Click(object sender, EventArgs e)
        {
            opcionBusqueda = 1;
            txt_abuscar.Enabled = true;
            btn_busqueda.Enabled = true;
        }

        private void btn_busqueda_Click(object sender, EventArgs e)
        {
            if(opcionBusqueda == 0)
            {
                if (Estatica.estudiantes.buscarNombre(txt_abuscar.Text))
                {
                    MessageBox.Show("Estudiante encontrado");
                    grp_editar.Visible = true;
                    encontrado = Estatica.estudiantes.nodoNombre(txt_abuscar.Text);
                    lbl_edad_busqueda.Text = encontrado.getNom();
                    lbl_nombre_busqueda.Text = encontrado.getEd().ToString();
                }
                else
                {
                    MessageBox.Show("No existe");
                }
            }
            if(opcionBusqueda == 1)
            {
                if (Estatica.estudiantes.buscarEdad(int.Parse(txt_abuscar.Text)))
                {
                    MessageBox.Show("Estudiante encontrado");
                    grp_editar.Visible = true;
                    encontrado = Estatica.estudiantes.nodoEdad(int.Parse(txt_abuscar.Text));
                    lbl_edad_busqueda.Text = encontrado.getNom();
                    lbl_nombre_busqueda.Text = encontrado.getEd().ToString();
                }
                else
                {
                    MessageBox.Show("No existe");
                }
            }
            txt_abuscar.Clear();
            txt_abuscar.Enabled = false;
            btn_busqueda.Enabled = false;
        }

        private void grp_editar_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            opcionCambio = 0;
            txt_cambio.Enabled = true;
            btn_cambiar.Enabled = true;
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_cambio_edad_Click(object sender, EventArgs e)
        {
            opcionCambio = 1;
            txt_cambio.Enabled = true;
            btn_cambiar.Enabled = true;
        }

        private void btn_cambiar_Click(object sender, EventArgs e)
        {
            if(opcionCambio == 0)
            {
                encontrado.setNom(txt_cambio.Text);
            }
            if(opcionCambio == 1)
            {
                encontrado.setEd(int.Parse(txt_cambio.Text));
            }
            if(opcionCambio == 2)
            {
                Estatica.estudiantes.eliminar(encontrado.getNom());
            }
            txt_cambio.Enabled = false;
            btn_cambiar.Enabled = false;
            MessageBox.Show("Cambio realizado");
            lbl_edad_busqueda.Text = encontrado.getNom();
            lbl_nombre_busqueda.Text = encontrado.getEd().ToString();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            opcionCambio = 2;
            btn_cambiar.Enabled = true;
        }
    }
}
