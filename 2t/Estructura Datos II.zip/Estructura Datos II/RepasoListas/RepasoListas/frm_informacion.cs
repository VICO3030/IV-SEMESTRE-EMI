﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RepasoListas
{
    public partial class frm_informacion : Form
    {
        public frm_informacion()
        {
            InitializeComponent();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            /*NodoSimple mayor = Estatica.estudiantes.mayorEd();
            NodoSimple menor = Estatica.estudiantes.menorEd();
            lbl_mayor_nombre.Text = mayor.getNom();
            lbl_mayor_edad.Text = mayor.getEd().ToString();
            lbl_menor_nombre.Text = menor.getNom();
            lbl_menor_edad.Text = menor.getEd().ToString();*/

        }

        private void frm_informacion_Load(object sender, EventArgs e)
        {
            NodoSimple mayor = Estatica.estudiantes.mayorEd();
            NodoSimple menor = Estatica.estudiantes.menorEd();
            lbl_mayor_nombre.Text = mayor.getNom();
            lbl_mayor_edad.Text = mayor.getEd().ToString();
            lbl_menor_nombre.Text = menor.getNom();
            lbl_menor_edad.Text = menor.getEd().ToString();
            lbl_prom.Text = Estatica.estudiantes.ageAvrg().ToString();
        }
    }
}
