﻿
namespace RepasoListas
{
    partial class frm_editar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_busqueda = new System.Windows.Forms.Button();
            this.txt_abuscar = new System.Windows.Forms.TextBox();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.grp_editar = new System.Windows.Forms.GroupBox();
            this.lbl_edad_busqueda = new System.Windows.Forms.Label();
            this.lbl_nombre_busqueda = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_cambiar = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.txt_cambio = new System.Windows.Forms.TextBox();
            this.btn_cambio_edad = new System.Windows.Forms.Button();
            this.btn_cambio_nombre = new System.Windows.Forms.Button();
            this.btn_bucar_edad = new System.Windows.Forms.Button();
            this.btn_buscar_nombre = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.grp_editar.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_busqueda);
            this.groupBox1.Controls.Add(this.txt_abuscar);
            this.groupBox1.Controls.Add(this.btn_cerrar);
            this.groupBox1.Controls.Add(this.grp_editar);
            this.groupBox1.Controls.Add(this.btn_bucar_edad);
            this.groupBox1.Controls.Add(this.btn_buscar_nombre);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(334, 260);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MENU DE EDICION";
            // 
            // btn_busqueda
            // 
            this.btn_busqueda.Enabled = false;
            this.btn_busqueda.Location = new System.Drawing.Point(253, 45);
            this.btn_busqueda.Name = "btn_busqueda";
            this.btn_busqueda.Size = new System.Drawing.Size(75, 23);
            this.btn_busqueda.TabIndex = 6;
            this.btn_busqueda.Text = "Buscar";
            this.btn_busqueda.UseVisualStyleBackColor = true;
            this.btn_busqueda.Click += new System.EventHandler(this.btn_busqueda_Click);
            // 
            // txt_abuscar
            // 
            this.txt_abuscar.Enabled = false;
            this.txt_abuscar.Location = new System.Drawing.Point(228, 19);
            this.txt_abuscar.Name = "txt_abuscar";
            this.txt_abuscar.Size = new System.Drawing.Size(100, 20);
            this.txt_abuscar.TabIndex = 5;
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Location = new System.Drawing.Point(253, 231);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(75, 23);
            this.btn_cerrar.TabIndex = 4;
            this.btn_cerrar.Text = "Cerrar";
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // grp_editar
            // 
            this.grp_editar.Controls.Add(this.lbl_edad_busqueda);
            this.grp_editar.Controls.Add(this.lbl_nombre_busqueda);
            this.grp_editar.Controls.Add(this.label2);
            this.grp_editar.Controls.Add(this.btn_cambiar);
            this.grp_editar.Controls.Add(this.btn_eliminar);
            this.grp_editar.Controls.Add(this.txt_cambio);
            this.grp_editar.Controls.Add(this.btn_cambio_edad);
            this.grp_editar.Controls.Add(this.btn_cambio_nombre);
            this.grp_editar.Location = new System.Drawing.Point(12, 70);
            this.grp_editar.Name = "grp_editar";
            this.grp_editar.Size = new System.Drawing.Size(316, 155);
            this.grp_editar.TabIndex = 3;
            this.grp_editar.TabStop = false;
            this.grp_editar.Text = "Editar Estudiante";
            this.grp_editar.Visible = false;
            this.grp_editar.Enter += new System.EventHandler(this.grp_editar_Enter);
            // 
            // lbl_edad_busqueda
            // 
            this.lbl_edad_busqueda.AutoSize = true;
            this.lbl_edad_busqueda.Location = new System.Drawing.Point(207, 42);
            this.lbl_edad_busqueda.Name = "lbl_edad_busqueda";
            this.lbl_edad_busqueda.Size = new System.Drawing.Size(0, 13);
            this.lbl_edad_busqueda.TabIndex = 11;
            // 
            // lbl_nombre_busqueda
            // 
            this.lbl_nombre_busqueda.AutoSize = true;
            this.lbl_nombre_busqueda.Location = new System.Drawing.Point(118, 42);
            this.lbl_nombre_busqueda.Name = "lbl_nombre_busqueda";
            this.lbl_nombre_busqueda.Size = new System.Drawing.Size(0, 13);
            this.lbl_nombre_busqueda.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Datos actuales";
            // 
            // btn_cambiar
            // 
            this.btn_cambiar.Enabled = false;
            this.btn_cambiar.Location = new System.Drawing.Point(175, 96);
            this.btn_cambiar.Name = "btn_cambiar";
            this.btn_cambiar.Size = new System.Drawing.Size(75, 23);
            this.btn_cambiar.TabIndex = 8;
            this.btn_cambiar.Text = "Cambiar";
            this.btn_cambiar.UseVisualStyleBackColor = true;
            this.btn_cambiar.Click += new System.EventHandler(this.btn_cambiar_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Location = new System.Drawing.Point(6, 103);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(75, 36);
            this.btn_eliminar.TabIndex = 4;
            this.btn_eliminar.Text = "Eliminar";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // txt_cambio
            // 
            this.txt_cambio.Enabled = false;
            this.txt_cambio.Location = new System.Drawing.Point(150, 70);
            this.txt_cambio.Name = "txt_cambio";
            this.txt_cambio.Size = new System.Drawing.Size(100, 20);
            this.txt_cambio.TabIndex = 7;
            // 
            // btn_cambio_edad
            // 
            this.btn_cambio_edad.Location = new System.Drawing.Point(6, 61);
            this.btn_cambio_edad.Name = "btn_cambio_edad";
            this.btn_cambio_edad.Size = new System.Drawing.Size(75, 36);
            this.btn_cambio_edad.TabIndex = 3;
            this.btn_cambio_edad.Text = "Cambiar Edad";
            this.btn_cambio_edad.UseVisualStyleBackColor = true;
            this.btn_cambio_edad.Click += new System.EventHandler(this.btn_cambio_edad_Click);
            // 
            // btn_cambio_nombre
            // 
            this.btn_cambio_nombre.Location = new System.Drawing.Point(6, 19);
            this.btn_cambio_nombre.Name = "btn_cambio_nombre";
            this.btn_cambio_nombre.Size = new System.Drawing.Size(75, 36);
            this.btn_cambio_nombre.TabIndex = 2;
            this.btn_cambio_nombre.Text = "Cambiar Nombre";
            this.btn_cambio_nombre.UseVisualStyleBackColor = true;
            this.btn_cambio_nombre.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_bucar_edad
            // 
            this.btn_bucar_edad.Location = new System.Drawing.Point(93, 19);
            this.btn_bucar_edad.Name = "btn_bucar_edad";
            this.btn_bucar_edad.Size = new System.Drawing.Size(75, 36);
            this.btn_bucar_edad.TabIndex = 2;
            this.btn_bucar_edad.Text = "Bucar por edad";
            this.btn_bucar_edad.UseVisualStyleBackColor = true;
            this.btn_bucar_edad.Click += new System.EventHandler(this.btn_bucar_edad_Click);
            // 
            // btn_buscar_nombre
            // 
            this.btn_buscar_nombre.Location = new System.Drawing.Point(12, 19);
            this.btn_buscar_nombre.Name = "btn_buscar_nombre";
            this.btn_buscar_nombre.Size = new System.Drawing.Size(75, 36);
            this.btn_buscar_nombre.TabIndex = 1;
            this.btn_buscar_nombre.Text = "Buscar por nombre";
            this.btn_buscar_nombre.UseVisualStyleBackColor = true;
            this.btn_buscar_nombre.Click += new System.EventHandler(this.btn_buscar_nombre_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // frm_editar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 283);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_editar";
            this.Text = "frm_editar";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grp_editar.ResumeLayout(false);
            this.grp_editar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.GroupBox grp_editar;
        private System.Windows.Forms.Button btn_bucar_edad;
        private System.Windows.Forms.Button btn_buscar_nombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_busqueda;
        private System.Windows.Forms.TextBox txt_abuscar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_cambio_edad;
        private System.Windows.Forms.Button btn_cambio_nombre;
        private System.Windows.Forms.Label lbl_edad_busqueda;
        private System.Windows.Forms.Label lbl_nombre_busqueda;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_cambiar;
        private System.Windows.Forms.TextBox txt_cambio;
    }
}