﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMENP2EJER3
{
    class Nodo
    {
        int num;
        Nodo sig;

        public Nodo()
        {
            this.num = 0;
            this.sig = null;
        }

        public int Num { get => num; set => num = value; }
        public Nodo Sig { get => sig; set => sig = value; }
    }
}
