﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EXAMENP2EJER3
{
    public partial class Form1 : Form
    {
        Cola c, c2;
        public Form1()
        {
            c = new Cola();
            c2 = new Cola();
            InitializeComponent();
            cmb_dias.Items.Add("LUNES");
            cmb_dias.Items.Add("MARTES");
            cmb_dias.Items.Add("MIERCOLES");
            cmb_dias.Items.Add("JUEVES");
            cmb_dias.Items.Add("VIERNES");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_rand_Click(object sender, EventArgs e)
        {
            int cant = int.Parse(txt_cant.Text);
            int carnet;
            for(int i=0;i<cant;i++){
                carnet = generarRamd();
                c.encolar(carnet);
                lst_lista1.Items.Add(carnet);
            }
        }
        public int generarRamd()
        {
            Random random = new Random();
            int num = random.Next(7000000, 8000000);
            MessageBox.Show(num.ToString());
            return num;

        }
        public void mostrar()
        {
            Nodo xd = c.getFrente();
            lst_lista1.Items.Clear();
            while (xd != null)
            {
                lst_lista1.Items.Add(xd.Num);
                xd = xd.Sig;
            }

        }

        private void btn_atender_Click(object sender, EventArgs e)
        {
            if (c.getFrente() == null)
            {
                return;
            }
            if (cmb_dias.Text != "")
            {
                if (cmb_dias.Text == "LUNES")
                {
                    atender(0, 1);
                    mostrar2();
                }
                else if (cmb_dias.Text == "MARTES")
                {
                    atender(2, 3);
                    mostrar2();
                }
                else if (cmb_dias.Text == "MIERCOLES")
                {
                    atender(4, 5);
                    mostrar2();
                }
                else if (cmb_dias.Text == "JUEVES")
                {
                    atender(6, 7);
                    mostrar2();
                }
                else if (cmb_dias.Text == "VIERNES")
                {
                    atender(8, 9);
                    mostrar2();
                }
                else
                {
                    MessageBox.Show("INGRESO MAL EL DIA");
                }
                mostrar();
            }
            else
            {
                MessageBox.Show("NO COLOCO EL DIA!!!!!!!!!!!!!!!");
            }
        }
        public void atender(int n, int n2)
        {
            int cont = 0;
            Nodo xd = c.getFrente();
            while (xd != null)
            {
                if (xd.Num % 10 == n || xd.Num % 10 == n2)
                {
                    c2.encolar(xd.Num);
                    cont++;
                }
                xd = xd.Sig;
            }
            xd = c2.getFrente();
            while (xd != null)
            {
                c.eliminar(xd.Num);
                xd = xd.Sig;
            }
            MessageBox.Show("SE ATENDERAN A: " + cont + " PERSONAS");
        }

        public void mostrar2()
        {
            Nodo xd = c2.getFrente();
            lst_lista2.Items.Clear();
            while (xd != null)
            {
                lst_lista2.Items.Add(xd.Num);
                xd = xd.Sig;
            }

        }
    }
}
