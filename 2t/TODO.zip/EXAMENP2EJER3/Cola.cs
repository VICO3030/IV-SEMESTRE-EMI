﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMENP2EJER3
{
    class Cola
    {
        Nodo frente, final, nuevo;
        public Cola()
        {
            frente = null;
            nuevo = null;
            final = null;
        }
        public void crearNodo(int n)
        {
            nuevo = new Nodo();
            nuevo.Num = n;
            nuevo.Sig = null;

        }
        public string encolar(int n)
        {
            crearNodo(n);
            if (frente == null)
            {

                frente = nuevo;
                final = nuevo;
            }
            else
            {
                final.Sig = nuevo;
                final = nuevo;
            }

            return ("SE ENCOLO CON EXITO");
        }
        public Nodo desencolar()
        {
            Nodo aux = frente;
            frente = frente.Sig;
            aux.Sig = null;
            if (frente == null)
            {
                final = null;
            }
            return (aux);
        }
        public Nodo getFrente()
        {
            return frente;
        }
        public Nodo getFinal()
        {
            return final;
        }
        public bool estaVacio()
        {
            return frente == null;//si esta vacio devuelve verdadero
        }
        public string buscar(int n)
        {
            Nodo punt = getFrente();
            while (punt != null)
            {
                if (punt.Num == n)
                {
                    return "EL NUMERO " + punt.Num + " SE ENCUANTRA EN LA COLA";
                }
                punt = punt.Sig;
            }
            return "ERROR, NO SE ENCONTRO NADAAA";
        }
        public string eliminar(int n)
        {
            Nodo actual = frente;
            Nodo anterior = null;
            while (actual != null)
            {
                if (frente.Num == n)
                {
                    desencolar();
                    return ("SE ELIMINO A " + actual.Num);
                }
                else
                {
                    if (actual.Num == n)
                    {
                        anterior.Sig = actual.Sig;
                        actual.Sig = null;
                        return ("SE ELIMINO A " + actual.Num);
                    }
                    anterior = actual;
                    actual = actual.Sig;
                }
            }
            return "NO EXISTE";
        }
    }
}
