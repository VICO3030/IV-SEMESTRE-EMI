﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cola_ejercicio4
{
    class NodoCola
    {
        int num;
        string nom;
        string cal;
        string col;
        float tiempo;
        NodoCola sig;//Direccion del nodo con el que se enlasa
        public NodoCola()
        {
            num = 0;
            nom = "  ";
            cal = "  "; 
            col = "  ";
            tiempo = 0;
            sig = null;
        }

        public void setNum(int n)
        {
            this.num = n;
        }
        public void setNom(string no)
        {
            nom = no;
        }
        public void setTiempo(float ti)
        {
            tiempo = ti;
        }
        public void setCol(string co)
        {
            col = co;
        }
        public void setCal(string ca)
        {
            cal = ca;
        }
        public void setSig(NodoCola punt)
        {
            sig = punt;
        }

        public int getNum()
        {
            return num;
        }
        public string getNom()
        {
            return nom;
        }
        public string getCol()
        {
            return col;
        }
        public string getCal()
        {
            return cal;
        }
        public float getTiempo()
        {
            return tiempo;
        }
        public NodoCola getSig()
        {
            return sig;
        }
    }
}
