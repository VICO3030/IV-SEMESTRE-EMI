﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cola_ejercicio4
{
    class Cola
    {
        NodoCola frente, final, nuevo;
        public Cola()
        {
            frente = null;
            nuevo = null;
            final = null;
        }
        public void crearNodo(string no,int n,string ca,string co,float tiempo)
        {
            nuevo = new NodoCola();
            nuevo.setNum(n);
            nuevo.setNom(no);
            nuevo.setCal(ca);
            nuevo.setCol(co);
            nuevo.setTiempo(tiempo);
            nuevo.setSig(null);

        }
        public string encolar(string no, int n, string ca, string co, float tiempo)
        {
            crearNodo(no,n,ca,co,tiempo);
            if (frente == null)
            {

                frente = nuevo;
                final = nuevo;
            }
            else
            {
                final.setSig(nuevo);
                final = nuevo;
            }

            return ("SE ENCOLO CON EXITO");
        }
        public NodoCola desencolar()
        {
            NodoCola aux = frente;
            frente = frente.getSig();
            aux.setSig(null);
            if (frente == null)
            {
                final = null;
            }
            return (aux);
        }
        public NodoCola getFrente()
        {
            return frente;
        }
        public NodoCola getFinal()
        {
            return final;
        }
        public bool estaVacio()
        {
            return frente == null;//si esta vacio devuelve verdadero
        }
        public string buscar(int n)
        {
            NodoCola punt = getFrente();
            while (punt != null)
            {
                if (punt.getNum() == n)
                {
                    return "EL NUMERO " + punt.getNum() + " SE ENCUANTRA EN LA COLA";
                }
                punt = punt.getSig();
            }
            return "ERROR, NO SE ENCONTRO NADAAA";
        }
        public string eliminar(int n)
        {
            NodoCola actual = frente;
            NodoCola anterior = null;
            while (actual != null)
            {
                if (frente.getNum() == n)
                {
                    desencolar();
                    return ("SE ELIMINO A " + actual.getNum());
                }
                else
                {
                    if (actual.getNum() == n)
                    {
                        anterior.setSig(actual.getSig());
                        actual.setSig(null);
                        return ("SE ELIMINO A " + actual.getNum());
                    }
                    anterior = actual;
                    actual = actual.getSig();
                }
            }
            return "NO EXISTE";
        }
    }
}
