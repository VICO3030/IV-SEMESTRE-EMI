﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cola_ejercicio4
{
    public partial class Form1 : Form
    {
        Cola c;
        int cont = 0;
        public Form1()
        {
            InitializeComponent();
            c = new Cola()
;        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            NodoCola punt;
            if (c.estaVacio()==false)
            {
                
                
                punt =c.desencolar();
                tmr_ja.Stop();
                mostrar();
                dgv_imprimido.Rows.Add(punt.getNom(),punt.getTiempo()* punt.getNum());
                if (c.getFrente() != null)
                {
                    float jaja = c.getFrente().getNum() * c.getFrente().getTiempo() * 1000;
                    tmr_ja.Interval = (int)jaja;
                    tmr_bar.Interval = (int)jaja / 10;
                    pgb_a.Value = 0;
                    tmr_ja.Start();
                    tmr_bar.Start();
                }
            }
            else
            {
                tmr_bar.Stop();
                tmr_ja.Stop();
            }
        }
        private void mostrar()
        {
            NodoCola punt = c.getFrente();
            dgv_registro.Rows.Clear();
            float col=0;
            while (punt != null)
            {

                dgv_registro.Rows.Add(punt.getNom(),punt.getNum(),punt.getCal(),punt.getCol(),punt.getTiempo(),col);
                col = col + punt.getTiempo() * punt.getNum();
                punt = punt.getSig();
            }
        }
        private void btn_encolar_Click(object sender, EventArgs e)
        {
            string nom=txt_nom.Text;
            int n = int.Parse(txt_numero.Text);
            string ca=" ";
            if (rdb_a.Checked == true) ca = "ALTO";
            if (rdb_e.Checked == true) ca = "ESTANDAR";
            if (rdb_b.Checked == true) ca = "BORRADOR";
            string co=" ";
            if (rdb_co.Checked == true) co = "COLOR";
            if (rdb_ne.Checked == true) co = "NEGRO GRIS";
            float ti=0;
            if (rdb_co.Checked == true)
            {
                if (rdb_a.Checked == true) ti = 0.30f;
                if (rdb_e.Checked == true) ti= 0.2f;
                if (rdb_b.Checked == true) ti= 0.15f;
            }else
            {
                if (rdb_a.Checked == true) ti = 0.25f;
                if (rdb_e.Checked == true) ti = 0.18f;
                if (rdb_b.Checked == true) ti = 0.5f;
            }   
            c.encolar(nom,n,ca,co,ti);
            mostrar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_imprimir_Click(object sender, EventArgs e)
        {
            float jaja =c.getFrente().getNum() * c.getFrente().getTiempo() * 1000;
            tmr_ja.Interval = (int)jaja;
            tmr_bar.Interval = (int)jaja / 10;
            MessageBox.Show(jaja.ToString());
            tmr_bar.Start();
            tmr_ja.Start();
        }

        private void pgb_a_Click(object sender, EventArgs e)
        {

        }

        private void tmr_bar_Tick(object sender, EventArgs e)
        {
            if (pgb_a.Value<= 100)
            {
                pgb_a.Increment(10);
            }
            else
            {
                pgb_a.Value = 0;
                tmr_bar.Stop();
            }
        }
    }
}
