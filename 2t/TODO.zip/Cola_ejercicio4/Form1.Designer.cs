﻿namespace Cola_ejercicio4
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_encolar = new System.Windows.Forms.Button();
            this.txt_numero = new System.Windows.Forms.TextBox();
            this.lbl_numero = new System.Windows.Forms.Label();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_registroo = new System.Windows.Forms.Label();
            this.dgv_registro = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rdb_b = new System.Windows.Forms.RadioButton();
            this.rdb_e = new System.Windows.Forms.RadioButton();
            this.rdb_a = new System.Windows.Forms.RadioButton();
            this.rdb_ne = new System.Windows.Forms.RadioButton();
            this.rdb_co = new System.Windows.Forms.RadioButton();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.lbl_doc = new System.Windows.Forms.Label();
            this.tmr_ja = new System.Windows.Forms.Timer(this.components);
            this.pgb_a = new System.Windows.Forms.ProgressBar();
            this.dgv_imprimido = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_imprimir = new System.Windows.Forms.Button();
            this.tmr_bar = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_registro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_imprimido)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_encolar
            // 
            this.btn_encolar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_encolar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_encolar.Location = new System.Drawing.Point(604, 209);
            this.btn_encolar.Name = "btn_encolar";
            this.btn_encolar.Size = new System.Drawing.Size(131, 46);
            this.btn_encolar.TabIndex = 30;
            this.btn_encolar.Text = "ENCOLAR";
            this.btn_encolar.UseVisualStyleBackColor = false;
            this.btn_encolar.Click += new System.EventHandler(this.btn_encolar_Click);
            // 
            // txt_numero
            // 
            this.txt_numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numero.Location = new System.Drawing.Point(382, 157);
            this.txt_numero.Name = "txt_numero";
            this.txt_numero.Size = new System.Drawing.Size(113, 28);
            this.txt_numero.TabIndex = 29;
            // 
            // lbl_numero
            // 
            this.lbl_numero.AutoSize = true;
            this.lbl_numero.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numero.Location = new System.Drawing.Point(12, 163);
            this.lbl_numero.Name = "lbl_numero";
            this.lbl_numero.Size = new System.Drawing.Size(332, 22);
            this.lbl_numero.TabIndex = 28;
            this.lbl_numero.Text = "INGRESE LA CANTIDAD DE HOJAS:";
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(500, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(479, 51);
            this.lbl_titulo.TabIndex = 31;
            this.lbl_titulo.Text = "IMPRESIONES PEPITO ";
            // 
            // lbl_registroo
            // 
            this.lbl_registroo.AutoSize = true;
            this.lbl_registroo.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_registroo.Location = new System.Drawing.Point(222, 368);
            this.lbl_registroo.Name = "lbl_registroo";
            this.lbl_registroo.Size = new System.Drawing.Size(103, 22);
            this.lbl_registroo.TabIndex = 46;
            this.lbl_registroo.Text = "REGISTRO";
            // 
            // dgv_registro
            // 
            this.dgv_registro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_registro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgv_registro.Location = new System.Drawing.Point(28, 406);
            this.dgv_registro.Name = "dgv_registro";
            this.dgv_registro.RowHeadersWidth = 51;
            this.dgv_registro.RowTemplate.Height = 24;
            this.dgv_registro.Size = new System.Drawing.Size(972, 310);
            this.dgv_registro.TabIndex = 45;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "NOMBRE";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "CANTIDAD";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "CALIDAD";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "COLOR";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 125;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "TIEMPO";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 125;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "ESPERA";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            this.Column6.Width = 125;
            // 
            // rdb_b
            // 
            this.rdb_b.AutoSize = true;
            this.rdb_b.Location = new System.Drawing.Point(73, 215);
            this.rdb_b.Name = "rdb_b";
            this.rdb_b.Size = new System.Drawing.Size(106, 20);
            this.rdb_b.TabIndex = 49;
            this.rdb_b.TabStop = true;
            this.rdb_b.Text = "BORRADOR";
            this.rdb_b.UseVisualStyleBackColor = true;
            // 
            // rdb_e
            // 
            this.rdb_e.AutoSize = true;
            this.rdb_e.Location = new System.Drawing.Point(73, 255);
            this.rdb_e.Name = "rdb_e";
            this.rdb_e.Size = new System.Drawing.Size(103, 20);
            this.rdb_e.TabIndex = 50;
            this.rdb_e.TabStop = true;
            this.rdb_e.Text = "ESTANDAR";
            this.rdb_e.UseVisualStyleBackColor = true;
            // 
            // rdb_a
            // 
            this.rdb_a.AutoSize = true;
            this.rdb_a.Location = new System.Drawing.Point(73, 295);
            this.rdb_a.Name = "rdb_a";
            this.rdb_a.Size = new System.Drawing.Size(63, 20);
            this.rdb_a.TabIndex = 51;
            this.rdb_a.TabStop = true;
            this.rdb_a.Text = "ALTO";
            this.rdb_a.UseVisualStyleBackColor = true;
            // 
            // rdb_ne
            // 
            this.rdb_ne.AutoSize = true;
            this.rdb_ne.Location = new System.Drawing.Point(17, 60);
            this.rdb_ne.Name = "rdb_ne";
            this.rdb_ne.Size = new System.Drawing.Size(112, 20);
            this.rdb_ne.TabIndex = 53;
            this.rdb_ne.TabStop = true;
            this.rdb_ne.Text = "NEGRO GRIS";
            this.rdb_ne.UseVisualStyleBackColor = true;
            // 
            // rdb_co
            // 
            this.rdb_co.AutoSize = true;
            this.rdb_co.Location = new System.Drawing.Point(17, 20);
            this.rdb_co.Name = "rdb_co";
            this.rdb_co.Size = new System.Drawing.Size(74, 20);
            this.rdb_co.TabIndex = 52;
            this.rdb_co.TabStop = true;
            this.rdb_co.Text = "COLOR";
            this.rdb_co.UseVisualStyleBackColor = true;
            // 
            // txt_nom
            // 
            this.txt_nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nom.Location = new System.Drawing.Point(247, 117);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(113, 28);
            this.txt_nom.TabIndex = 55;
            // 
            // lbl_doc
            // 
            this.lbl_doc.AutoSize = true;
            this.lbl_doc.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_doc.Location = new System.Drawing.Point(12, 117);
            this.lbl_doc.Name = "lbl_doc";
            this.lbl_doc.Size = new System.Drawing.Size(212, 22);
            this.lbl_doc.TabIndex = 54;
            this.lbl_doc.Text = "INGRESE EL NOMBRE:";
            // 
            // tmr_ja
            // 
            this.tmr_ja.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pgb_a
            // 
            this.pgb_a.Location = new System.Drawing.Point(1061, 344);
            this.pgb_a.Name = "pgb_a";
            this.pgb_a.Size = new System.Drawing.Size(406, 46);
            this.pgb_a.TabIndex = 56;
            this.pgb_a.Click += new System.EventHandler(this.pgb_a_Click);
            // 
            // dgv_imprimido
            // 
            this.dgv_imprimido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_imprimido.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn5});
            this.dgv_imprimido.Location = new System.Drawing.Point(1040, 406);
            this.dgv_imprimido.Name = "dgv_imprimido";
            this.dgv_imprimido.RowHeadersWidth = 51;
            this.dgv_imprimido.RowTemplate.Height = 24;
            this.dgv_imprimido.Size = new System.Drawing.Size(438, 310);
            this.dgv_imprimido.TabIndex = 57;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "NOMBRE";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "TIEMPO";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdb_ne);
            this.groupBox1.Controls.Add(this.rdb_co);
            this.groupBox1.Location = new System.Drawing.Point(209, 215);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "grb_color";
            // 
            // btn_imprimir
            // 
            this.btn_imprimir.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_imprimir.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_imprimir.Location = new System.Drawing.Point(604, 280);
            this.btn_imprimir.Name = "btn_imprimir";
            this.btn_imprimir.Size = new System.Drawing.Size(131, 46);
            this.btn_imprimir.TabIndex = 59;
            this.btn_imprimir.Text = "IMPRIMIR";
            this.btn_imprimir.UseVisualStyleBackColor = false;
            this.btn_imprimir.Click += new System.EventHandler(this.btn_imprimir_Click);
            // 
            // tmr_bar
            // 
            this.tmr_bar.Tick += new System.EventHandler(this.tmr_bar_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 728);
            this.Controls.Add(this.btn_imprimir);
            this.Controls.Add(this.dgv_imprimido);
            this.Controls.Add(this.pgb_a);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.lbl_doc);
            this.Controls.Add(this.rdb_a);
            this.Controls.Add(this.rdb_e);
            this.Controls.Add(this.rdb_b);
            this.Controls.Add(this.lbl_registroo);
            this.Controls.Add(this.dgv_registro);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_encolar);
            this.Controls.Add(this.txt_numero);
            this.Controls.Add(this.lbl_numero);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_registro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_imprimido)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_encolar;
        private System.Windows.Forms.TextBox txt_numero;
        private System.Windows.Forms.Label lbl_numero;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_registroo;
        private System.Windows.Forms.DataGridView dgv_registro;
        private System.Windows.Forms.RadioButton rdb_b;
        private System.Windows.Forms.RadioButton rdb_e;
        private System.Windows.Forms.RadioButton rdb_a;
        private System.Windows.Forms.RadioButton rdb_ne;
        private System.Windows.Forms.RadioButton rdb_co;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.Label lbl_doc;
        private System.Windows.Forms.Timer tmr_ja;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.ProgressBar pgb_a;
        private System.Windows.Forms.DataGridView dgv_imprimido;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_imprimir;
        private System.Windows.Forms.Timer tmr_bar;
    }
}

