﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACHO01
{
    class Lista_Jugadores
    {
        Nodo_Jugador cabeza, nuevo, ultimo;

        public Lista_Jugadores()
        {
            cabeza = null;
            nuevo = null;
            ultimo = null;
        }

        public void crear_nodo(String name, int num)
        {
            nuevo = new Nodo_Jugador(name, num);
        }

        public void crear_lista_circular(String name, int num)
        {
            crear_nodo(name, num);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                ultimo.Enlace = nuevo;
            }
            ultimo = nuevo;
            ultimo.Enlace = cabeza;
        }

        public Nodo_Jugador getCabeza()
        {
            return cabeza;
        }

        public Nodo_Jugador getUltimo()
        {
            return ultimo;
        }
    }
}
