﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CACHO01
{
    class Nodo_Jugador
    {
        String nombre;
        int [] puntaje;
        int numero_jugador;

        Nodo_Jugador enlace;

        public Nodo_Jugador(String name, int num)
        {
            this.nombre = name;
            puntaje = new int [12];
            this.numero_jugador = num;
            enlace = null;
        }

        public string Nombre { get => nombre; set => nombre = value; }
        public int[] Puntaje { get => puntaje; set => puntaje = value; }
        public int Numero_jugador { get => numero_jugador; set => numero_jugador = value; }
        internal Nodo_Jugador Enlace { get => enlace; set => enlace = value; }
    }
}
