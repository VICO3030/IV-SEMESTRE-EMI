﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CACHO01
{
    public partial class frmRegistroJugadores : Form
    {
        int num_jug;
        int numero_max;

        public frmRegistroJugadores()
        {
            InitializeComponent();
            num_jug = 0;
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if(num_jug < numero_max)
            {
                if (txtNombreJugador.Text != "")
                {
                    num_jug++;
                    Estatica.jugadores.crear_lista_circular(txtNombreJugador.Text, num_jug);
                    dgvJugadores.Rows.Add(txtNombreJugador.Text, num_jug.ToString());
                    MessageBox.Show("JUGADOR " + num_jug + " REGISTRADO");
                    txtNombreJugador.Text = "";

                }
                else MessageBox.Show("INGRESE EL NOMBRE DEL JUGADOR");
            }
            else
            {
                MessageBox.Show("NUMERO MAXIMO DE JUGADORES ALCANZADO");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmRegistroJugadores_Load(object sender, EventArgs e)
        {

        }

        private void btnNumJugadores_Click(object sender, EventArgs e)
        {
            
            if(cbxNumeroDeJugadores.Text != "")
            {
                numero_max = int.Parse(cbxNumeroDeJugadores.Text);
                btnNumJugadores.Visible = false;
                cbxNumeroDeJugadores.Enabled = false;
                gpbRegristro.Visible = true;
                btnSiguiente.Visible = true;
                imgIniciar.Visible = true;

            }
            else
            {
                MessageBox.Show("INGRESE LA CANTIDAD DE JUGADORES");
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmMain fr1 = new frmMain();
            this.Close();
            fr1.Show();
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            if(numero_max == num_jug)
            {
                frmJuego fr1 = new frmJuego();
                this.Close();
                fr1.Show();
            }
            else{
                MessageBox.Show("TERMINE DE INGRESAR LOS JUGADORES");
            }
        }
    }
}
