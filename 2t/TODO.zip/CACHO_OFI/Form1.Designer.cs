﻿namespace CACHO01
{
    partial class frmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnJuego = new System.Windows.Forms.Button();
            this.btnReglas = new System.Windows.Forms.Button();
            this.imgRelas = new System.Windows.Forms.PictureBox();
            this.imgComenzar = new System.Windows.Forms.PictureBox();
            this.imgElgame = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imgTitulo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgRelas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgComenzar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgElgame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTitulo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnJuego
            // 
            this.btnJuego.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnJuego.BackColor = System.Drawing.Color.Gray;
            this.btnJuego.BackgroundImage = global::CACHO01.Properties.Resources.BTNINICIAROFI;
            this.btnJuego.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnJuego.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnJuego.FlatAppearance.BorderSize = 0;
            this.btnJuego.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnJuego.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnJuego.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJuego.Location = new System.Drawing.Point(195, 494);
            this.btnJuego.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnJuego.Name = "btnJuego";
            this.btnJuego.Size = new System.Drawing.Size(201, 127);
            this.btnJuego.TabIndex = 4;
            this.btnJuego.UseVisualStyleBackColor = false;
            this.btnJuego.Click += new System.EventHandler(this.btnJuego_Click);
            // 
            // btnReglas
            // 
            this.btnReglas.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnReglas.BackColor = System.Drawing.Color.Gray;
            this.btnReglas.BackgroundImage = global::CACHO01.Properties.Resources.BTNINICIAROFI;
            this.btnReglas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReglas.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnReglas.FlatAppearance.BorderSize = 0;
            this.btnReglas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnReglas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnReglas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReglas.Location = new System.Drawing.Point(195, 658);
            this.btnReglas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReglas.Name = "btnReglas";
            this.btnReglas.Size = new System.Drawing.Size(201, 127);
            this.btnReglas.TabIndex = 5;
            this.btnReglas.UseVisualStyleBackColor = false;
            this.btnReglas.Click += new System.EventHandler(this.btnReglas_Click);
            // 
            // imgRelas
            // 
            this.imgRelas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.imgRelas.Image = global::CACHO01.Properties.Resources.ImgReglas;
            this.imgRelas.Location = new System.Drawing.Point(342, 664);
            this.imgRelas.Margin = new System.Windows.Forms.Padding(4);
            this.imgRelas.Name = "imgRelas";
            this.imgRelas.Size = new System.Drawing.Size(319, 121);
            this.imgRelas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgRelas.TabIndex = 7;
            this.imgRelas.TabStop = false;
            // 
            // imgComenzar
            // 
            this.imgComenzar.Image = global::CACHO01.Properties.Resources.imgComenzar;
            this.imgComenzar.Location = new System.Drawing.Point(372, 500);
            this.imgComenzar.Margin = new System.Windows.Forms.Padding(4);
            this.imgComenzar.Name = "imgComenzar";
            this.imgComenzar.Size = new System.Drawing.Size(319, 121);
            this.imgComenzar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgComenzar.TabIndex = 6;
            this.imgComenzar.TabStop = false;
            // 
            // imgElgame
            // 
            this.imgElgame.Image = global::CACHO01.Properties.Resources.TITULO_EL_JUEGO;
            this.imgElgame.Location = new System.Drawing.Point(825, 273);
            this.imgElgame.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.imgElgame.Name = "imgElgame";
            this.imgElgame.Size = new System.Drawing.Size(641, 174);
            this.imgElgame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgElgame.TabIndex = 2;
            this.imgElgame.TabStop = false;
            this.imgElgame.Click += new System.EventHandler(this.imgElgame_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CACHO01.Properties.Resources.LOGO;
            this.pictureBox1.Location = new System.Drawing.Point(1657, 848);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(264, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // imgTitulo
            // 
            this.imgTitulo.Image = global::CACHO01.Properties.Resources.TITULO_CACHO;
            this.imgTitulo.Location = new System.Drawing.Point(-11, -49);
            this.imgTitulo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.imgTitulo.Name = "imgTitulo";
            this.imgTitulo.Size = new System.Drawing.Size(1515, 418);
            this.imgTitulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgTitulo.TabIndex = 0;
            this.imgTitulo.TabStop = false;
            this.imgTitulo.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1901, 1003);
            this.Controls.Add(this.btnJuego);
            this.Controls.Add(this.btnReglas);
            this.Controls.Add(this.imgRelas);
            this.Controls.Add(this.imgComenzar);
            this.Controls.Add(this.imgElgame);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.imgTitulo);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "frmMain";
            ((System.ComponentModel.ISupportInitialize)(this.imgRelas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgComenzar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgElgame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTitulo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox imgTitulo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox imgElgame;
        private System.Windows.Forms.Button btnJuego;
        private System.Windows.Forms.Button btnReglas;
        private System.Windows.Forms.PictureBox imgComenzar;
        private System.Windows.Forms.PictureBox imgRelas;
    }
}

