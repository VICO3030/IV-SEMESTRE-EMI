﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CACHO01
{
    public partial class frmJuego : Form
    {
        ListaDados tiroHdp;
        public frmJuego()
        {
            tiroHdp=new ListaDados();
            InitializeComponent();
            
        }

        private void frmRegistroJugadores_Load(object sender, EventArgs e)
        {
            
        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void lbl2_Click(object sender, EventArgs e)
        {
            imgDado1.Image = DadoImg(4);
            imgDado2.Image = DadoImg(6);
            imgDado3.Image = DadoImg(2);
            imgDado4.Image = DadoImg(1);
            imgDado5.Image = DadoImg(2);

        }
        private System.Drawing.Bitmap DadoImg(int n)
        {
            if (n == 1) return Properties.Resources.Dado1;
            if (n == 2) return Properties.Resources.Dado2;
            if (n == 3) return Properties.Resources.Dado3;
            if (n == 4) return Properties.Resources.Dado4;
            if (n == 5) return Properties.Resources.Dado5;
            if (n == 6) return Properties.Resources.Dado6;

            return null;
        }

        private void btnLanzar_Click(object sender, EventArgs e)
        {
            tiroHdp = new ListaDados();
            tiroHdp.tiroCubilete();
            imgDado1.Image = DadoImg(tiroHdp.buscarDado(0).Num);
            imgDado2.Image = DadoImg(tiroHdp.buscarDado(1).Num);
            imgDado3.Image = DadoImg(tiroHdp.buscarDado(2).Num);
            imgDado4.Image = DadoImg(tiroHdp.buscarDado(3).Num);
            imgDado5.Image = DadoImg(tiroHdp.buscarDado(4).Num);
        }
    }
}
