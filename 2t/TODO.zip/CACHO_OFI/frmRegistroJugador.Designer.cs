﻿namespace CACHO01
{
    partial class frmRegistroJugadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNombreJugador = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblIngreseNombre = new System.Windows.Forms.Label();
            this.dgvJugadores = new System.Windows.Forms.DataGridView();
            this.ColumnaJugador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnaNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblNumeroJugadores = new System.Windows.Forms.Label();
            this.cbxNumeroDeJugadores = new System.Windows.Forms.ComboBox();
            this.gpbRegristro = new System.Windows.Forms.GroupBox();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.imgSalir = new System.Windows.Forms.PictureBox();
            this.imgIniciar = new System.Windows.Forms.PictureBox();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnNumJugadores = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJugadores)).BeginInit();
            this.gpbRegristro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSalir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgIniciar)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNombreJugador
            // 
            this.txtNombreJugador.Font = new System.Drawing.Font("Cascadia Mono", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreJugador.Location = new System.Drawing.Point(493, 34);
            this.txtNombreJugador.Name = "txtNombreJugador";
            this.txtNombreJugador.Size = new System.Drawing.Size(339, 32);
            this.txtNombreJugador.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Mono", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(36, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(835, 85);
            this.label1.TabIndex = 13;
            this.label1.Text = "REGISTRO DE JUGADORES";
            // 
            // lblIngreseNombre
            // 
            this.lblIngreseNombre.AutoSize = true;
            this.lblIngreseNombre.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngreseNombre.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblIngreseNombre.Location = new System.Drawing.Point(6, 31);
            this.lblIngreseNombre.Name = "lblIngreseNombre";
            this.lblIngreseNombre.Size = new System.Drawing.Size(495, 35);
            this.lblIngreseNombre.TabIndex = 12;
            this.lblIngreseNombre.Text = "INGRESE EL NOMBRE DEL JUGADOR:";
            // 
            // dgvJugadores
            // 
            this.dgvJugadores.AllowUserToDeleteRows = false;
            this.dgvJugadores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvJugadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvJugadores.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnaJugador,
            this.ColumnaNum});
            this.dgvJugadores.Location = new System.Drawing.Point(284, 107);
            this.dgvJugadores.Name = "dgvJugadores";
            this.dgvJugadores.Size = new System.Drawing.Size(624, 150);
            this.dgvJugadores.TabIndex = 18;
            this.dgvJugadores.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ColumnaJugador
            // 
            this.ColumnaJugador.HeaderText = "JUGADOR";
            this.ColumnaJugador.Name = "ColumnaJugador";
            // 
            // ColumnaNum
            // 
            this.ColumnaNum.HeaderText = "NUMERO DE JUGADOR";
            this.ColumnaNum.Name = "ColumnaNum";
            // 
            // lblNumeroJugadores
            // 
            this.lblNumeroJugadores.AutoSize = true;
            this.lblNumeroJugadores.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroJugadores.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNumeroJugadores.Location = new System.Drawing.Point(54, 160);
            this.lblNumeroJugadores.Name = "lblNumeroJugadores";
            this.lblNumeroJugadores.Size = new System.Drawing.Size(559, 35);
            this.lblNumeroJugadores.TabIndex = 19;
            this.lblNumeroJugadores.Text = "SELECCIONE EL NUMERO DE JUGADORES:";
            // 
            // cbxNumeroDeJugadores
            // 
            this.cbxNumeroDeJugadores.Font = new System.Drawing.Font("Cascadia Mono", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxNumeroDeJugadores.FormattingEnabled = true;
            this.cbxNumeroDeJugadores.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5"});
            this.cbxNumeroDeJugadores.Location = new System.Drawing.Point(619, 163);
            this.cbxNumeroDeJugadores.Name = "cbxNumeroDeJugadores";
            this.cbxNumeroDeJugadores.Size = new System.Drawing.Size(50, 40);
            this.cbxNumeroDeJugadores.TabIndex = 20;
            // 
            // gpbRegristro
            // 
            this.gpbRegristro.Controls.Add(this.dgvJugadores);
            this.gpbRegristro.Controls.Add(this.btnRegistrar);
            this.gpbRegristro.Controls.Add(this.txtNombreJugador);
            this.gpbRegristro.Controls.Add(this.lblIngreseNombre);
            this.gpbRegristro.Location = new System.Drawing.Point(135, 265);
            this.gpbRegristro.Name = "gpbRegristro";
            this.gpbRegristro.Size = new System.Drawing.Size(1063, 352);
            this.gpbRegristro.TabIndex = 22;
            this.gpbRegristro.TabStop = false;
            this.gpbRegristro.Visible = false;
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.BackgroundImage = global::CACHO01.Properties.Resources.flecha_derecha;
            this.btnSiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSiguiente.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSiguiente.Location = new System.Drawing.Point(1281, 692);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(94, 98);
            this.btnSiguiente.TabIndex = 19;
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Visible = false;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // imgSalir
            // 
            this.imgSalir.Image = global::CACHO01.Properties.Resources.FTsalir;
            this.imgSalir.Location = new System.Drawing.Point(-7, 692);
            this.imgSalir.Name = "imgSalir";
            this.imgSalir.Size = new System.Drawing.Size(490, 111);
            this.imgSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgSalir.TabIndex = 25;
            this.imgSalir.TabStop = false;
            // 
            // imgIniciar
            // 
            this.imgIniciar.Image = global::CACHO01.Properties.Resources.FTiniciar;
            this.imgIniciar.Location = new System.Drawing.Point(955, 692);
            this.imgIniciar.Name = "imgIniciar";
            this.imgIniciar.Size = new System.Drawing.Size(377, 114);
            this.imgIniciar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgIniciar.TabIndex = 24;
            this.imgIniciar.TabStop = false;
            this.imgIniciar.Visible = false;
            // 
            // btnVolver
            // 
            this.btnVolver.BackgroundImage = global::CACHO01.Properties.Resources.flecha_izquierda;
            this.btnVolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnVolver.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnVolver.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnVolver.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolver.Location = new System.Drawing.Point(71, 692);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(99, 98);
            this.btnVolver.TabIndex = 23;
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackgroundImage = global::CACHO01.Properties.Resources.registro;
            this.btnRegistrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRegistrar.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnRegistrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnRegistrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrar.Location = new System.Drawing.Point(852, 31);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(72, 47);
            this.btnRegistrar.TabIndex = 17;
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnNumJugadores
            // 
            this.btnNumJugadores.BackColor = System.Drawing.Color.Transparent;
            this.btnNumJugadores.BackgroundImage = global::CACHO01.Properties.Resources.registro;
            this.btnNumJugadores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNumJugadores.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNumJugadores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnNumJugadores.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnNumJugadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNumJugadores.Location = new System.Drawing.Point(691, 161);
            this.btnNumJugadores.Name = "btnNumJugadores";
            this.btnNumJugadores.Size = new System.Drawing.Size(65, 47);
            this.btnNumJugadores.TabIndex = 21;
            this.btnNumJugadores.UseVisualStyleBackColor = false;
            this.btnNumJugadores.Click += new System.EventHandler(this.btnNumJugadores_Click);
            // 
            // frmRegistroJugadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1426, 815);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.imgSalir);
            this.Controls.Add(this.imgIniciar);
            this.Controls.Add(this.gpbRegristro);
            this.Controls.Add(this.btnNumJugadores);
            this.Controls.Add(this.cbxNumeroDeJugadores);
            this.Controls.Add(this.lblNumeroJugadores);
            this.Controls.Add(this.label1);
            this.Name = "frmRegistroJugadores";
            this.Text = "REGISTRO";
            this.Load += new System.EventHandler(this.frmRegistroJugadores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJugadores)).EndInit();
            this.gpbRegristro.ResumeLayout(false);
            this.gpbRegristro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSalir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgIniciar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtNombreJugador;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblIngreseNombre;
        private System.Windows.Forms.DataGridView dgvJugadores;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnaJugador;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnaNum;
        private System.Windows.Forms.Label lblNumeroJugadores;
        private System.Windows.Forms.ComboBox cbxNumeroDeJugadores;
        private System.Windows.Forms.Button btnNumJugadores;
        private System.Windows.Forms.GroupBox gpbRegristro;
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.PictureBox imgIniciar;
        private System.Windows.Forms.PictureBox imgSalir;
    }
}