﻿namespace CACHO01
{
    partial class frmJuego
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.imgDado5 = new System.Windows.Forms.PictureBox();
            this.imgDado4 = new System.Windows.Forms.PictureBox();
            this.imgDado3 = new System.Windows.Forms.PictureBox();
            this.imgDado2 = new System.Windows.Forms.PictureBox();
            this.imgDado1 = new System.Windows.Forms.PictureBox();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.imgTresenraya = new System.Windows.Forms.PictureBox();
            this.btnLanzar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTresenraya)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Cascadia Mono", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(510, 32);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(664, 79);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "NOMBRE DEL JUGADOR";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(1662, 205);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(44, 49);
            this.lbl4.TabIndex = 22;
            this.lbl4.Text = "4";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(1351, 494);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(44, 49);
            this.lbl3.TabIndex = 24;
            this.lbl3.Text = "3";
            this.lbl3.Click += new System.EventHandler(this.lbl3_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(1351, 346);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(44, 49);
            this.lbl2.TabIndex = 25;
            this.lbl2.Text = "2";
            this.lbl2.Click += new System.EventHandler(this.lbl2_Click);
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(1511, 205);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(44, 49);
            this.lbl7.TabIndex = 26;
            this.lbl7.Text = "7";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(1662, 494);
            this.lbl6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(44, 49);
            this.lbl6.TabIndex = 27;
            this.lbl6.Text = "6";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(1662, 346);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(44, 49);
            this.lbl5.TabIndex = 28;
            this.lbl5.Text = "5";
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(1457, 592);
            this.lbl10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(66, 49);
            this.lbl10.TabIndex = 29;
            this.lbl10.Text = "10";
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(1511, 494);
            this.lbl9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(44, 49);
            this.lbl9.TabIndex = 30;
            this.lbl9.Text = "9";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(1511, 346);
            this.lbl8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(44, 49);
            this.lbl8.TabIndex = 31;
            this.lbl8.Text = "8";
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.Location = new System.Drawing.Point(1554, 657);
            this.lbl11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(66, 49);
            this.lbl11.TabIndex = 32;
            this.lbl11.Text = "11";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Cascadia Mono", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(1351, 205);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(44, 49);
            this.lbl1.TabIndex = 21;
            this.lbl1.Text = "1";
            // 
            // imgDado5
            // 
            this.imgDado5.Location = new System.Drawing.Point(954, 157);
            this.imgDado5.Name = "imgDado5";
            this.imgDado5.Size = new System.Drawing.Size(123, 121);
            this.imgDado5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDado5.TabIndex = 38;
            this.imgDado5.TabStop = false;
            // 
            // imgDado4
            // 
            this.imgDado4.Location = new System.Drawing.Point(746, 157);
            this.imgDado4.Name = "imgDado4";
            this.imgDado4.Size = new System.Drawing.Size(123, 121);
            this.imgDado4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDado4.TabIndex = 37;
            this.imgDado4.TabStop = false;
            // 
            // imgDado3
            // 
            this.imgDado3.Location = new System.Drawing.Point(555, 157);
            this.imgDado3.Name = "imgDado3";
            this.imgDado3.Size = new System.Drawing.Size(123, 121);
            this.imgDado3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDado3.TabIndex = 36;
            this.imgDado3.TabStop = false;
            // 
            // imgDado2
            // 
            this.imgDado2.Location = new System.Drawing.Point(345, 157);
            this.imgDado2.Name = "imgDado2";
            this.imgDado2.Size = new System.Drawing.Size(123, 121);
            this.imgDado2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDado2.TabIndex = 35;
            this.imgDado2.TabStop = false;
            // 
            // imgDado1
            // 
            this.imgDado1.Location = new System.Drawing.Point(137, 157);
            this.imgDado1.Name = "imgDado1";
            this.imgDado1.Size = new System.Drawing.Size(123, 121);
            this.imgDado1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDado1.TabIndex = 34;
            this.imgDado1.TabStop = false;
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.BackgroundImage = global::CACHO01.Properties.Resources.flecha_derecha;
            this.btnSiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSiguiente.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnSiguiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSiguiente.Location = new System.Drawing.Point(1730, 846);
            this.btnSiguiente.Margin = new System.Windows.Forms.Padding(4);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(125, 121);
            this.btnSiguiente.TabIndex = 20;
            this.btnSiguiente.UseVisualStyleBackColor = true;
            // 
            // imgTresenraya
            // 
            this.imgTresenraya.Image = global::CACHO01.Properties.Resources.TricaCacho;
            this.imgTresenraya.Location = new System.Drawing.Point(1203, 157);
            this.imgTresenraya.Name = "imgTresenraya";
            this.imgTresenraya.Size = new System.Drawing.Size(652, 549);
            this.imgTresenraya.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgTresenraya.TabIndex = 33;
            this.imgTresenraya.TabStop = false;
            // 
            // btnLanzar
            // 
            this.btnLanzar.BackgroundImage = global::CACHO01.Properties.Resources.flecha_derecha;
            this.btnLanzar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLanzar.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnLanzar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnLanzar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnLanzar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLanzar.Location = new System.Drawing.Point(555, 321);
            this.btnLanzar.Margin = new System.Windows.Forms.Padding(4);
            this.btnLanzar.Name = "btnLanzar";
            this.btnLanzar.Size = new System.Drawing.Size(125, 121);
            this.btnLanzar.TabIndex = 39;
            this.btnLanzar.UseVisualStyleBackColor = true;
            this.btnLanzar.Click += new System.EventHandler(this.btnLanzar_Click);
            // 
            // frmJuego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1901, 1003);
            this.Controls.Add(this.btnLanzar);
            this.Controls.Add(this.imgDado5);
            this.Controls.Add(this.imgDado4);
            this.Controls.Add(this.imgDado3);
            this.Controls.Add(this.imgDado2);
            this.Controls.Add(this.imgDado1);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.imgTresenraya);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmJuego";
            this.Text = "JUEGO";
            this.Load += new System.EventHandler(this.frmRegistroJugadores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgDado5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDado1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTresenraya)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.PictureBox imgTresenraya;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.PictureBox imgDado1;
        private System.Windows.Forms.PictureBox imgDado2;
        private System.Windows.Forms.PictureBox imgDado3;
        private System.Windows.Forms.PictureBox imgDado4;
        private System.Windows.Forms.PictureBox imgDado5;
        private System.Windows.Forms.Button btnLanzar;
    }
}