﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2Ejer2
{
    class Nodo
    {
        int num;
        Nodo enlace;

        public Nodo()
        {
            this.num = 0;
            this.enlace = null;
        }

        public int Num { get => num; set => num = value; }
        public Nodo Enlace { get => enlace; set => enlace = value; }
    }
}
