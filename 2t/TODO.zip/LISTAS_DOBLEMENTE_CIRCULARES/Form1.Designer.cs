﻿namespace LISTAS_DOBLEMENTE_CIRCULARES
{
    partial class frm_listadoblecircular
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.lst_lista = new System.Windows.Forms.ListBox();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lbl_texto = new System.Windows.Forms.Label();
            this.btn_Mostrar = new System.Windows.Forms.Button();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lbl_listasdoble = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackColor = System.Drawing.Color.Navy;
            this.btn_eliminar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_eliminar.Location = new System.Drawing.Point(731, 363);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(131, 46);
            this.btn_eliminar.TabIndex = 39;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = false;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // lst_lista
            // 
            this.lst_lista.FormattingEnabled = true;
            this.lst_lista.ItemHeight = 16;
            this.lst_lista.Location = new System.Drawing.Point(144, 206);
            this.lst_lista.Name = "lst_lista";
            this.lst_lista.Size = new System.Drawing.Size(435, 228);
            this.lst_lista.TabIndex = 38;
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(405, 147);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(113, 28);
            this.txt_num.TabIndex = 37;
            // 
            // lbl_texto
            // 
            this.lbl_texto.AutoSize = true;
            this.lbl_texto.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_texto.Location = new System.Drawing.Point(185, 150);
            this.lbl_texto.Name = "lbl_texto";
            this.lbl_texto.Size = new System.Drawing.Size(214, 22);
            this.lbl_texto.TabIndex = 36;
            this.lbl_texto.Text = "INGRESE EL NUMERO:";
            // 
            // btn_Mostrar
            // 
            this.btn_Mostrar.BackColor = System.Drawing.Color.Navy;
            this.btn_Mostrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mostrar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Mostrar.Location = new System.Drawing.Point(207, 461);
            this.btn_Mostrar.Name = "btn_Mostrar";
            this.btn_Mostrar.Size = new System.Drawing.Size(131, 62);
            this.btn_Mostrar.TabIndex = 35;
            this.btn_Mostrar.Text = "MOSTRAR INICIO";
            this.btn_Mostrar.UseVisualStyleBackColor = false;
            this.btn_Mostrar.Click += new System.EventHandler(this.btn_Mostrar_Click);
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Navy;
            this.btn_registrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_registrar.Location = new System.Drawing.Point(731, 229);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(131, 46);
            this.btn_registrar.TabIndex = 34;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // btn_insertar
            // 
            this.btn_insertar.BackColor = System.Drawing.Color.Navy;
            this.btn_insertar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insertar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_insertar.Location = new System.Drawing.Point(731, 296);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(131, 46);
            this.btn_insertar.TabIndex = 40;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = false;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(373, 461);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(131, 62);
            this.button2.TabIndex = 41;
            this.button2.Text = "MOSTRAR ULTIMO";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_listasdoble
            // 
            this.lbl_listasdoble.AutoSize = true;
            this.lbl_listasdoble.Font = new System.Drawing.Font("Maiandra GD", 28.2F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_listasdoble.Location = new System.Drawing.Point(105, 36);
            this.lbl_listasdoble.Name = "lbl_listasdoble";
            this.lbl_listasdoble.Size = new System.Drawing.Size(757, 56);
            this.lbl_listasdoble.TabIndex = 42;
            this.lbl_listasdoble.Text = "LISTA DOBLEMENTE ENLAZADAS";
            // 
            // frm_listadoblecircular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(949, 566);
            this.Controls.Add(this.lbl_listasdoble);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lst_lista);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lbl_texto);
            this.Controls.Add(this.btn_Mostrar);
            this.Controls.Add(this.btn_registrar);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "frm_listadoblecircular";
            this.Text = "HIOOOOLLA";
            this.Load += new System.EventHandler(this.frm_listadoblecircular_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.ListBox lst_lista;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label lbl_texto;
        private System.Windows.Forms.Button btn_Mostrar;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lbl_listasdoble;
    }
}

