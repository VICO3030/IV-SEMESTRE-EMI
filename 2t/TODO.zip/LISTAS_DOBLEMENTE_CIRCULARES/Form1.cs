﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_DOBLEMENTE_CIRCULARES
{
    public partial class frm_listadoblecircular : Form
    {
        LISTA_DOBLE_CIRCULAR ld=new LISTA_DOBLE_CIRCULAR();
        public frm_listadoblecircular()
        {
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            ld.crearLista(int.Parse(txt_num.Text)); 
            MessageBox.Show("SE AÑADIO CORRECTAMENTE");
        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            NODO_DOBLE_CIRCULAR punt = ld.getCabeza();
            do
            {
                if (punt == null)
                {
                    return;
                }
                lst_lista.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
            while (punt != ld.getCabeza());
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            ld.eliminar(int.Parse(txt_num.Text));
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            if (ld.getCabeza ()!= null)
            {
                ld.ordenar();
                ld.insertar(int.Parse(txt_num.Text));
            }
            else
            {
                ld.crearLista(int.Parse(txt_num.Text));
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            NODO_DOBLE_CIRCULAR punt = ld.getUltimo();
            do
            {
                if (punt == null)
                {
                    return;
                }
                lst_lista.Items.Add(punt.getNum());
                punt = punt.getAnt();
            }
            while (punt != ld.getUltimo());
        }

        private void frm_listadoblecircular_Load(object sender, EventArgs e)
        {

        }
    }
}
