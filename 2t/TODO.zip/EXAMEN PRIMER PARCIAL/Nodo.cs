﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMEN_PRIMER_PARCIAL
{
     class Nodo
    {
        int num;
        Nodo enlace;//Direccion del nodo con el que se enlasa
        public Nodo()
        {
            num = 0;
            enlace = null;
        }

        public void setNum(int n)
        {
            this.num = n;
        }
        public void setEnlace(Nodo punt)
        {
            enlace = punt;
        }

        public int getNum()
        {
            return num;
        }
        public Nodo getEnlace()
        {
            return enlace;
        }
    }
}
