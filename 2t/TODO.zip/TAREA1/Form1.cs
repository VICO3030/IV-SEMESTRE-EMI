﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TAREA1
{


    public partial class Frm_DatosP : Form
    {
        //Creamos una variable global
        string genero;
        float mayor = 0;
        float menor=10;
        public Frm_DatosP()
        {
            InitializeComponent();
            genero = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            genero = "Masculino";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Text_edad_TextChanged(object sender, EventArgs e)
        {

        }

        private void CBO_CARRERA_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Rdb_f_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Btn_SaliR_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_limpiar_Click(object sender, EventArgs e)
        {
            rdb_femenino.Checked = false;
            Rdb_M.Checked = false;
            CBO_CARRERA.Text = "";
            Text_nombrecompleto.Clear();
            Text_edad.Clear();
            text_cod.Clear();
            genero = "";
            txt_nota1.Clear();
            txt_nota2.Clear();
            text_nota3.Clear();
            btn_calcularn.Visible = false;
            Btn_limpiar.Enabled=false;
        }

        private void rdb_CheckedChanged(object sender, EventArgs e)
        {
            genero = "Femenino";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_registrar_Click(object sender, EventArgs e)
        {
            //Adicionamos datos a nuestra lista(Empieza en 0)
            lst_alumnos.Items.Add(Text_nombrecompleto.Text + " - " + text_cod.Text);
            lst_alumnos.Items.Add("Genero: " + genero);
            lst_alumnos.Items.Add("Edad: " + Text_edad.Text);
            lst_alumnos.Items.Add("Carrera: " + CBO_CARRERA.Text);
            lst_alumnos.Items.Add("----------------------------------");
            MessageBox.Show("SE REGISTRO CORRECTAMENTE");
            //Cambiamos la condicion del Visible
            btn_calcularn.Visible= true;
        }

        private void lst_alumnos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void text_cod_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_cod_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btn_calcularn_Click(object sender, EventArgs e)
        {
            float promedio, n1, n2, n3;
            Btn_limpiar.Enabled = true;
            n1 = float.Parse(txt_nota1.Text);
            n2 = float.Parse(txt_nota2.Text);
            n3 = float.Parse(text_nota3.Text);
            promedio = (n1 + n2 + n3) / 3;
            if (promedio>mayor)
            {
                mayor= promedio;
            }
            if (promedio<menor)
            {
                menor= promedio;
            }
            if (promedio>=5.1)
            {
                lst_aprobados.Items.Add(Text_nombrecompleto.Text + " - " + promedio);
            }
            else
            {
                lst_reprobados.Items.Add(Text_nombrecompleto.Text + " - " + promedio);
            }
                
        }

        private void text_nota3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_promedio_Click(object sender, EventArgs e)
        {|
            lbl_promedio.Text("MAYOR: "+mayor);
            lbl_promedio.Text("fdsj");
        }

        private void lbl_promedio_Click(object sender, EventArgs e)
        {

        }
    }
}
