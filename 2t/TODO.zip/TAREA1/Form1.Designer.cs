﻿namespace TAREA1
{
    partial class Frm_DatosP
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl_nombre = new System.Windows.Forms.Label();
            this.Lbl_carrera = new System.Windows.Forms.Label();
            this.Lb_genero = new System.Windows.Forms.Label();
            this.Lbl_edad = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Rdb_M = new System.Windows.Forms.RadioButton();
            this.Text_nombrecompleto = new System.Windows.Forms.TextBox();
            this.Text_edad = new System.Windows.Forms.TextBox();
            this.CBO_CARRERA = new System.Windows.Forms.ComboBox();
            this.Btn_registrar = new System.Windows.Forms.Button();
            this.Btn_limpiar = new System.Windows.Forms.Button();
            this.rdb_femenino = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.lst_alumnos = new System.Windows.Forms.ListBox();
            this.lbl_cod = new System.Windows.Forms.Label();
            this.text_cod = new System.Windows.Forms.TextBox();
            this.txt_nota1 = new System.Windows.Forms.TextBox();
            this.lb_nota1 = new System.Windows.Forms.Label();
            this.txt_nota2 = new System.Windows.Forms.TextBox();
            this.lbl_nota2 = new System.Windows.Forms.Label();
            this.text_nota3 = new System.Windows.Forms.TextBox();
            this.lb_nota3 = new System.Windows.Forms.Label();
            this.lst_aprobados = new System.Windows.Forms.ListBox();
            this.lst_reprobados = new System.Windows.Forms.ListBox();
            this.btn_calcularn = new System.Windows.Forms.Button();
            this.lbl_apro = new System.Windows.Forms.Label();
            this.lb_repro = new System.Windows.Forms.Label();
            this.btn_promedio = new System.Windows.Forms.Button();
            this.lbl_promedio = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Lbl_nombre
            // 
            this.Lbl_nombre.AutoSize = true;
            this.Lbl_nombre.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_nombre.Font = new System.Drawing.Font("Stencil", 14F);
            this.Lbl_nombre.Location = new System.Drawing.Point(116, 143);
            this.Lbl_nombre.Name = "Lbl_nombre";
            this.Lbl_nombre.Size = new System.Drawing.Size(261, 29);
            this.Lbl_nombre.TabIndex = 0;
            this.Lbl_nombre.Text = "NOMBRE Y APELLIDO: ";
            this.Lbl_nombre.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lbl_carrera
            // 
            this.Lbl_carrera.AutoSize = true;
            this.Lbl_carrera.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_carrera.Font = new System.Drawing.Font("Stencil", 14F);
            this.Lbl_carrera.Location = new System.Drawing.Point(116, 268);
            this.Lbl_carrera.Name = "Lbl_carrera";
            this.Lbl_carrera.Size = new System.Drawing.Size(130, 29);
            this.Lbl_carrera.TabIndex = 1;
            this.Lbl_carrera.Text = "CARRERA:";
            this.Lbl_carrera.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Lb_genero
            // 
            this.Lb_genero.AutoSize = true;
            this.Lb_genero.BackColor = System.Drawing.Color.Transparent;
            this.Lb_genero.Font = new System.Drawing.Font("Stencil", 14F);
            this.Lb_genero.Location = new System.Drawing.Point(116, 227);
            this.Lb_genero.Name = "Lb_genero";
            this.Lb_genero.Size = new System.Drawing.Size(118, 29);
            this.Lb_genero.TabIndex = 2;
            this.Lb_genero.Text = "GENERO: ";
            this.Lb_genero.Click += new System.EventHandler(this.label2_Click);
            // 
            // Lbl_edad
            // 
            this.Lbl_edad.AutoSize = true;
            this.Lbl_edad.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_edad.Font = new System.Drawing.Font("Stencil", 14F);
            this.Lbl_edad.Location = new System.Drawing.Point(116, 181);
            this.Lbl_edad.Name = "Lbl_edad";
            this.Lbl_edad.Size = new System.Drawing.Size(88, 29);
            this.Lbl_edad.TabIndex = 3;
            this.Lbl_edad.Text = "EDAD: ";
            this.Lbl_edad.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Stencil", 20F);
            this.label1.Location = new System.Drawing.Point(277, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(547, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "INGRESE LOS SIGUIENTES DATOS ";
            this.label1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Rdb_M
            // 
            this.Rdb_M.AutoSize = true;
            this.Rdb_M.BackColor = System.Drawing.Color.Transparent;
            this.Rdb_M.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Rdb_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rdb_M.Location = new System.Drawing.Point(251, 233);
            this.Rdb_M.Name = "Rdb_M";
            this.Rdb_M.Size = new System.Drawing.Size(131, 29);
            this.Rdb_M.TabIndex = 5;
            this.Rdb_M.TabStop = true;
            this.Rdb_M.Text = "Masculino";
            this.Rdb_M.UseVisualStyleBackColor = false;
            this.Rdb_M.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Text_nombrecompleto
            // 
            this.Text_nombrecompleto.BackColor = System.Drawing.Color.SlateGray;
            this.Text_nombrecompleto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Text_nombrecompleto.ForeColor = System.Drawing.Color.Black;
            this.Text_nombrecompleto.Location = new System.Drawing.Point(373, 143);
            this.Text_nombrecompleto.Name = "Text_nombrecompleto";
            this.Text_nombrecompleto.Size = new System.Drawing.Size(317, 30);
            this.Text_nombrecompleto.TabIndex = 7;
            this.Text_nombrecompleto.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Text_edad
            // 
            this.Text_edad.BackColor = System.Drawing.Color.SlateGray;
            this.Text_edad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Text_edad.Location = new System.Drawing.Point(251, 181);
            this.Text_edad.Name = "Text_edad";
            this.Text_edad.Size = new System.Drawing.Size(43, 30);
            this.Text_edad.TabIndex = 9;
            this.Text_edad.TextChanged += new System.EventHandler(this.Text_edad_TextChanged);
            // 
            // CBO_CARRERA
            // 
            this.CBO_CARRERA.BackColor = System.Drawing.Color.SlateGray;
            this.CBO_CARRERA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBO_CARRERA.FormattingEnabled = true;
            this.CBO_CARRERA.Items.AddRange(new object[] {
            "Ing. de Sistemas",
            "Ing. Comercial",
            "Ing. Agroindustrial",
            "Ing. Petrolera",
            "Ing. en Sistemas electronicos",
            "Ing. Civil"});
            this.CBO_CARRERA.Location = new System.Drawing.Point(252, 266);
            this.CBO_CARRERA.Name = "CBO_CARRERA";
            this.CBO_CARRERA.Size = new System.Drawing.Size(204, 33);
            this.CBO_CARRERA.TabIndex = 10;
            this.CBO_CARRERA.SelectedIndexChanged += new System.EventHandler(this.CBO_CARRERA_SelectedIndexChanged);
            // 
            // Btn_registrar
            // 
            this.Btn_registrar.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Btn_registrar.Location = new System.Drawing.Point(251, 371);
            this.Btn_registrar.Name = "Btn_registrar";
            this.Btn_registrar.Size = new System.Drawing.Size(115, 23);
            this.Btn_registrar.TabIndex = 13;
            this.Btn_registrar.Text = "REGISTRAR";
            this.Btn_registrar.UseVisualStyleBackColor = false;
            this.Btn_registrar.Click += new System.EventHandler(this.Btn_registrar_Click);
            // 
            // Btn_limpiar
            // 
            this.Btn_limpiar.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Btn_limpiar.Enabled = false;
            this.Btn_limpiar.Location = new System.Drawing.Point(403, 371);
            this.Btn_limpiar.Name = "Btn_limpiar";
            this.Btn_limpiar.Size = new System.Drawing.Size(75, 23);
            this.Btn_limpiar.TabIndex = 11;
            this.Btn_limpiar.Text = "LIMPIAR";
            this.Btn_limpiar.UseVisualStyleBackColor = false;
            this.Btn_limpiar.Click += new System.EventHandler(this.Btn_limpiar_Click);
            // 
            // rdb_femenino
            // 
            this.rdb_femenino.AutoSize = true;
            this.rdb_femenino.BackColor = System.Drawing.Color.Transparent;
            this.rdb_femenino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.rdb_femenino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_femenino.Location = new System.Drawing.Point(458, 233);
            this.rdb_femenino.Name = "rdb_femenino";
            this.rdb_femenino.Size = new System.Drawing.Size(128, 29);
            this.rdb_femenino.TabIndex = 14;
            this.rdb_femenino.TabStop = true;
            this.rdb_femenino.Text = "Femenino";
            this.rdb_femenino.UseVisualStyleBackColor = false;
            this.rdb_femenino.CheckedChanged += new System.EventHandler(this.rdb_CheckedChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button1.Location = new System.Drawing.Point(995, 639);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lst_alumnos
            // 
            this.lst_alumnos.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lst_alumnos.FormattingEnabled = true;
            this.lst_alumnos.ItemHeight = 16;
            this.lst_alumnos.Location = new System.Drawing.Point(758, 117);
            this.lst_alumnos.Name = "lst_alumnos";
            this.lst_alumnos.Size = new System.Drawing.Size(300, 148);
            this.lst_alumnos.TabIndex = 16;
            this.lst_alumnos.SelectedIndexChanged += new System.EventHandler(this.lst_alumnos_SelectedIndexChanged);
            // 
            // lbl_cod
            // 
            this.lbl_cod.AutoSize = true;
            this.lbl_cod.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cod.Font = new System.Drawing.Font("Stencil", 14F);
            this.lbl_cod.Location = new System.Drawing.Point(121, 311);
            this.lbl_cod.Name = "lbl_cod";
            this.lbl_cod.Size = new System.Drawing.Size(106, 29);
            this.lbl_cod.TabIndex = 18;
            this.lbl_cod.Text = "CODIGO:";
            this.lbl_cod.Click += new System.EventHandler(this.lbl_cod_Click);
            // 
            // text_cod
            // 
            this.text_cod.BackColor = System.Drawing.Color.SlateGray;
            this.text_cod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_cod.ForeColor = System.Drawing.Color.Black;
            this.text_cod.Location = new System.Drawing.Point(251, 311);
            this.text_cod.Name = "text_cod";
            this.text_cod.Size = new System.Drawing.Size(144, 30);
            this.text_cod.TabIndex = 19;
            this.text_cod.TextChanged += new System.EventHandler(this.text_cod_TextChanged);
            // 
            // txt_nota1
            // 
            this.txt_nota1.BackColor = System.Drawing.Color.SlateGray;
            this.txt_nota1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nota1.Location = new System.Drawing.Point(233, 449);
            this.txt_nota1.Name = "txt_nota1";
            this.txt_nota1.Size = new System.Drawing.Size(43, 30);
            this.txt_nota1.TabIndex = 21;
            // 
            // lb_nota1
            // 
            this.lb_nota1.AutoSize = true;
            this.lb_nota1.BackColor = System.Drawing.Color.Transparent;
            this.lb_nota1.Font = new System.Drawing.Font("Stencil", 14F);
            this.lb_nota1.Location = new System.Drawing.Point(139, 451);
            this.lb_nota1.Name = "lb_nota1";
            this.lb_nota1.Size = new System.Drawing.Size(101, 29);
            this.lb_nota1.TabIndex = 20;
            this.lb_nota1.Text = "NOTA 1:";
            // 
            // txt_nota2
            // 
            this.txt_nota2.BackColor = System.Drawing.Color.SlateGray;
            this.txt_nota2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nota2.Location = new System.Drawing.Point(233, 506);
            this.txt_nota2.Name = "txt_nota2";
            this.txt_nota2.Size = new System.Drawing.Size(43, 30);
            this.txt_nota2.TabIndex = 23;
            // 
            // lbl_nota2
            // 
            this.lbl_nota2.AutoSize = true;
            this.lbl_nota2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_nota2.Font = new System.Drawing.Font("Stencil", 14F);
            this.lbl_nota2.Location = new System.Drawing.Point(139, 508);
            this.lbl_nota2.Name = "lbl_nota2";
            this.lbl_nota2.Size = new System.Drawing.Size(101, 29);
            this.lbl_nota2.TabIndex = 22;
            this.lbl_nota2.Text = "NOTA 2:";
            // 
            // text_nota3
            // 
            this.text_nota3.BackColor = System.Drawing.Color.SlateGray;
            this.text_nota3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_nota3.Location = new System.Drawing.Point(233, 565);
            this.text_nota3.Name = "text_nota3";
            this.text_nota3.Size = new System.Drawing.Size(43, 30);
            this.text_nota3.TabIndex = 25;
            this.text_nota3.TextChanged += new System.EventHandler(this.text_nota3_TextChanged);
            // 
            // lb_nota3
            // 
            this.lb_nota3.AutoSize = true;
            this.lb_nota3.BackColor = System.Drawing.Color.Transparent;
            this.lb_nota3.Font = new System.Drawing.Font("Stencil", 14F);
            this.lb_nota3.Location = new System.Drawing.Point(139, 567);
            this.lb_nota3.Name = "lb_nota3";
            this.lb_nota3.Size = new System.Drawing.Size(107, 29);
            this.lb_nota3.TabIndex = 24;
            this.lb_nota3.Text = "NOTA 3: ";
            // 
            // lst_aprobados
            // 
            this.lst_aprobados.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lst_aprobados.FormattingEnabled = true;
            this.lst_aprobados.ItemHeight = 16;
            this.lst_aprobados.Location = new System.Drawing.Point(458, 477);
            this.lst_aprobados.Name = "lst_aprobados";
            this.lst_aprobados.Size = new System.Drawing.Size(197, 148);
            this.lst_aprobados.TabIndex = 26;
            // 
            // lst_reprobados
            // 
            this.lst_reprobados.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lst_reprobados.FormattingEnabled = true;
            this.lst_reprobados.ItemHeight = 16;
            this.lst_reprobados.Location = new System.Drawing.Point(679, 477);
            this.lst_reprobados.Name = "lst_reprobados";
            this.lst_reprobados.Size = new System.Drawing.Size(197, 148);
            this.lst_reprobados.TabIndex = 27;
            // 
            // btn_calcularn
            // 
            this.btn_calcularn.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btn_calcularn.Location = new System.Drawing.Point(318, 506);
            this.btn_calcularn.Name = "btn_calcularn";
            this.btn_calcularn.Size = new System.Drawing.Size(100, 33);
            this.btn_calcularn.TabIndex = 28;
            this.btn_calcularn.Text = "CALCULAR";
            this.btn_calcularn.UseVisualStyleBackColor = false;
            this.btn_calcularn.Visible = false;
            this.btn_calcularn.Click += new System.EventHandler(this.btn_calcularn_Click);
            // 
            // lbl_apro
            // 
            this.lbl_apro.AutoSize = true;
            this.lbl_apro.BackColor = System.Drawing.Color.Transparent;
            this.lbl_apro.Font = new System.Drawing.Font("Stencil", 14F);
            this.lbl_apro.Location = new System.Drawing.Point(478, 445);
            this.lbl_apro.Name = "lbl_apro";
            this.lbl_apro.Size = new System.Drawing.Size(150, 29);
            this.lbl_apro.TabIndex = 29;
            this.lbl_apro.Text = "APROBADOS";
            // 
            // lb_repro
            // 
            this.lb_repro.AutoSize = true;
            this.lb_repro.BackColor = System.Drawing.Color.Transparent;
            this.lb_repro.Font = new System.Drawing.Font("Stencil", 14F);
            this.lb_repro.Location = new System.Drawing.Point(690, 445);
            this.lb_repro.Name = "lb_repro";
            this.lb_repro.Size = new System.Drawing.Size(166, 29);
            this.lb_repro.TabIndex = 30;
            this.lb_repro.Text = "REPROBADOS";
            // 
            // btn_promedio
            // 
            this.btn_promedio.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btn_promedio.Location = new System.Drawing.Point(947, 451);
            this.btn_promedio.Name = "btn_promedio";
            this.btn_promedio.Size = new System.Drawing.Size(111, 64);
            this.btn_promedio.TabIndex = 31;
            this.btn_promedio.Text = "MAYOR Y MENOR PROMEDIO";
            this.btn_promedio.UseVisualStyleBackColor = false;
            this.btn_promedio.Visible = false;
            this.btn_promedio.Click += new System.EventHandler(this.btn_promedio_Click);
            // 
            // lbl_promedio
            // 
            this.lbl_promedio.AutoSize = true;
            this.lbl_promedio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_promedio.Font = new System.Drawing.Font("Stencil", 14F);
            this.lbl_promedio.Location = new System.Drawing.Point(954, 552);
            this.lbl_promedio.Name = "lbl_promedio";
            this.lbl_promedio.Size = new System.Drawing.Size(21, 29);
            this.lbl_promedio.TabIndex = 32;
            this.lbl_promedio.Text = ":";
            this.lbl_promedio.Click += new System.EventHandler(this.lbl_promedio_Click);
            // 
            // Frm_DatosP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TAREA1.Properties.Resources.backiee_39470;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1082, 674);
            this.Controls.Add(this.lbl_promedio);
            this.Controls.Add(this.btn_promedio);
            this.Controls.Add(this.lb_repro);
            this.Controls.Add(this.lbl_apro);
            this.Controls.Add(this.btn_calcularn);
            this.Controls.Add(this.lst_reprobados);
            this.Controls.Add(this.lst_aprobados);
            this.Controls.Add(this.text_nota3);
            this.Controls.Add(this.lb_nota3);
            this.Controls.Add(this.txt_nota2);
            this.Controls.Add(this.lbl_nota2);
            this.Controls.Add(this.txt_nota1);
            this.Controls.Add(this.lb_nota1);
            this.Controls.Add(this.text_cod);
            this.Controls.Add(this.lbl_cod);
            this.Controls.Add(this.lst_alumnos);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rdb_femenino);
            this.Controls.Add(this.Btn_registrar);
            this.Controls.Add(this.Btn_limpiar);
            this.Controls.Add(this.CBO_CARRERA);
            this.Controls.Add(this.Text_edad);
            this.Controls.Add(this.Text_nombrecompleto);
            this.Controls.Add(this.Rdb_M);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Lbl_edad);
            this.Controls.Add(this.Lb_genero);
            this.Controls.Add(this.Lbl_carrera);
            this.Controls.Add(this.Lbl_nombre);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_DatosP";
            this.Text = "DATOS";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_nombre;
        private System.Windows.Forms.Label Lbl_carrera;
        private System.Windows.Forms.Label Lb_genero;
        private System.Windows.Forms.Label Lbl_edad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton Rdb_M;
        private System.Windows.Forms.TextBox Text_nombrecompleto;
        private System.Windows.Forms.TextBox Text_edad;
        private System.Windows.Forms.ComboBox CBO_CARRERA;
        private System.Windows.Forms.Button Btn_registrar;
        private System.Windows.Forms.Button Btn_limpiar;
        private System.Windows.Forms.RadioButton rdb_femenino;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox lst_alumnos;
        private System.Windows.Forms.Label lbl_cod;
        private System.Windows.Forms.TextBox text_cod;
        private System.Windows.Forms.TextBox txt_nota1;
        private System.Windows.Forms.Label lb_nota1;
        private System.Windows.Forms.TextBox txt_nota2;
        private System.Windows.Forms.Label lbl_nota2;
        private System.Windows.Forms.TextBox text_nota3;
        private System.Windows.Forms.Label lb_nota3;
        private System.Windows.Forms.ListBox lst_aprobados;
        private System.Windows.Forms.ListBox lst_reprobados;
        private System.Windows.Forms.Button btn_calcularn;
        private System.Windows.Forms.Label lbl_apro;
        private System.Windows.Forms.Label lb_repro;
        private System.Windows.Forms.Button btn_promedio;
        private System.Windows.Forms.Label lbl_promedio;
    }
}

