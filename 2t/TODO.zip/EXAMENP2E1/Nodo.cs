﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMENP2E1
{
    class Nodo
    {
        int num;
        Nodo sig;//Direccion del nodo con el que se enlasa
        public Nodo()
        {
            num = 0;
            sig = null;
        }
        public void setNum(int n)
        {
            this.num = n;
        }
        public void setSig(Nodo punt)
        {
            sig = punt;
        }

        public int getNum()
        {
            return num;
        }
        public Nodo getSig()
        {
            return sig;
        }
    }
}
