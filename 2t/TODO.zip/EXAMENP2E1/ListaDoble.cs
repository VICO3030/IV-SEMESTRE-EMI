﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAMENP2E1
{
    class ListaDoble
    {

        Nodo cabeza, nuevo, ultimo;
        public ListaDoble()
        {
            cabeza = null;
            nuevo = null;
        }
        public Nodo getCabeza()
        {
            return cabeza;
        }
        public Nodo getUltimo()
        {
            return ultimo;
        }
        public void crearNodo(int n)
        {
            nuevo = new Nodo();
            nuevo.setNum(n);
            nuevo.setSig(null);
        }
        public void crearLista(int n)
        {
            Nodo punt;
            crearNodo(n);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                ultimo.setSig(nuevo);
            }
            ultimo = nuevo;
            ultimo.setSig(cabeza);

        }
        public string eliminar(int n)
        {
            Nodo actual = cabeza;
            Nodo anterior = ultimo;
            do
            {
                if (cabeza.getNum() == n)
                {
                    if (cabeza == ultimo)
                    {
                        cabeza = null;
                        ultimo = null;
                        return ("SE ELIMINO A " + actual.getNum());
                    }
                    anterior.setSig(cabeza.getSig());
                    cabeza = cabeza.getSig();
                    actual.setSig(null);
                    return ("SE ELIMINO A " + actual.getNum());
                }
                else
                {
                    if (actual.getNum() == n)
                    {
                        anterior.setSig(actual.getSig());
                        actual.setSig(null);
                        return ("SE ELIMINO A " + actual.getSig());
                    }
                    anterior = actual;
                    actual = actual.getSig();
                }
            } while (actual != cabeza);
            return "NO EXISTE";
        }
        public void ordenar()
        {
            int aux;
            Nodo punt = cabeza;
            do
            {
                Nodo punt2 = punt.getSig();
                while (punt2 != cabeza)
                {
                    if (punt2.getNum() < punt.getNum())
                    {
                        aux = punt.getNum();
                        punt.setNum(punt2.getNum());
                        punt2.setNum(aux);
                    }
                    punt2 = punt2.getSig();
                }
                punt = punt.getSig();
            } while (punt != cabeza);
        }
    }
}
