﻿namespace EXAMENP2E1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_num = new System.Windows.Forms.Label();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lst_lista1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_pos = new System.Windows.Forms.TextBox();
            this.lst_lista2 = new System.Windows.Forms.ListBox();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.lbl_suma = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(263, 24);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(327, 51);
            this.lbl_titulo.TabIndex = 35;
            this.lbl_titulo.Text = "LISTAS DOBLES";
            // 
            // lbl_num
            // 
            this.lbl_num.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(44, 109);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(298, 37);
            this.lbl_num.TabIndex = 32;
            this.lbl_num.Text = "INGRESE EL NUMERO:";
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(348, 109);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(100, 36);
            this.txt_num.TabIndex = 33;
            // 
            // lst_lista1
            // 
            this.lst_lista1.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista1.ItemHeight = 27;
            this.lst_lista1.Location = new System.Drawing.Point(111, 253);
            this.lst_lista1.Name = "lst_lista1";
            this.lst_lista1.Size = new System.Drawing.Size(245, 139);
            this.lst_lista1.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 37);
            this.label1.TabIndex = 36;
            this.label1.Text = "INGRESE LA POSICION:";
            // 
            // txt_pos
            // 
            this.txt_pos.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pos.Location = new System.Drawing.Point(348, 183);
            this.txt_pos.Name = "txt_pos";
            this.txt_pos.Size = new System.Drawing.Size(100, 36);
            this.txt_pos.TabIndex = 37;
            // 
            // lst_lista2
            // 
            this.lst_lista2.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista2.ItemHeight = 27;
            this.lst_lista2.Location = new System.Drawing.Point(533, 253);
            this.lst_lista2.Name = "lst_lista2";
            this.lst_lista2.Size = new System.Drawing.Size(245, 139);
            this.lst_lista2.TabIndex = 38;
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_registrar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(496, 98);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(149, 55);
            this.btn_registrar.TabIndex = 39;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // btn_insertar
            // 
            this.btn_insertar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_insertar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insertar.Location = new System.Drawing.Point(496, 170);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(149, 55);
            this.btn_insertar.TabIndex = 40;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = false;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // lbl_suma
            // 
            this.lbl_suma.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_suma.Location = new System.Drawing.Point(238, 466);
            this.lbl_suma.Name = "lbl_suma";
            this.lbl_suma.Size = new System.Drawing.Size(407, 37);
            this.lbl_suma.TabIndex = 41;
            this.lbl_suma.Text = "LA SUMATORIA DE LOS NUMEROS ES:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 549);
            this.Controls.Add(this.lbl_suma);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.lst_lista2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_pos);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lst_lista1);
            this.Name = "Form1";
            this.Text = "frm_main";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.ListBox lst_lista1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_pos;
        private System.Windows.Forms.ListBox lst_lista2;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.Label lbl_suma;
    }
}

