﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EXAMENP2E1
{
    public partial class Form1 : Form
    {
        ListaDoble l,l2;
        Nodo posi;
        public Form1()
        {
            l = new ListaDoble();
            l2 = new ListaDoble();
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            l.crearLista(int.Parse(txt_num.Text));
            MessageBox.Show("SE REGISTRO CON EXISTO");
            mostrar1();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            int pos=int.Parse(txt_pos.Text);
            if(pos==0)
            {
                int sumatoria = 0;
                Nodo aux = l2.getCabeza();
                if (aux==null)
                {
                    MessageBox.Show("NO HAY DATOS EN LA LISTA");    
                }
                else
                {
                    do
                    {
                        sumatoria = sumatoria + aux.getNum();
                        aux = aux.getSig();
                    } while (aux!=l2.getCabeza());
                }
                lbl_suma.Text = "LA SUMATORIA DE LOS NUMEROS ES: " + sumatoria;
            }
            else
            {
                if (l2.getCabeza()==null)
                {
                    posi = l.getCabeza();
                }
                agregar(int.Parse(txt_pos.Text));
                mostrar2();
            }
        }
        public void agregar(int p)
        {
            int aux = 1;
            while(aux!=p){
                posi = posi.getSig();
                aux++;
            }
            l2.crearLista(posi.getNum());
        }
        public void mostrar1()
        {
            lst_lista1.Items.Clear();
            Nodo punt = l.getCabeza();
            do
            {
                if (punt == null)
                {
                    return;
                }
                lst_lista1.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
            while (punt != l.getCabeza());

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void mostrar2()
        {
            lst_lista2.Items.Clear();
            Nodo punt = l2.getCabeza();
            do
            {
                if (punt == null)
                {
                    return;
                }
                lst_lista2.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
            while (punt != l2.getCabeza());

        }
    }
}
