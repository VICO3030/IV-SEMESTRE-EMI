﻿namespace Listas_Simples
{
    partial class frm_insertar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_insertar = new System.Windows.Forms.Button();
            this.txt_edad = new System.Windows.Forms.TextBox();
            this.lbl_edad = new System.Windows.Forms.Label();
            this.txt_newname = new System.Windows.Forms.TextBox();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.brn_volver = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_insertar
            // 
            this.btn_insertar.Location = new System.Drawing.Point(294, 219);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(89, 36);
            this.btn_insertar.TabIndex = 27;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // txt_edad
            // 
            this.txt_edad.Location = new System.Drawing.Point(275, 148);
            this.txt_edad.Name = "txt_edad";
            this.txt_edad.Size = new System.Drawing.Size(87, 22);
            this.txt_edad.TabIndex = 26;
            // 
            // lbl_edad
            // 
            this.lbl_edad.AutoSize = true;
            this.lbl_edad.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_edad.Location = new System.Drawing.Point(40, 148);
            this.lbl_edad.Name = "lbl_edad";
            this.lbl_edad.Size = new System.Drawing.Size(220, 26);
            this.lbl_edad.TabIndex = 25;
            this.lbl_edad.Text = "INGRESE LA EDAD:";
            // 
            // txt_newname
            // 
            this.txt_newname.Location = new System.Drawing.Point(294, 95);
            this.txt_newname.Name = "txt_newname";
            this.txt_newname.Size = new System.Drawing.Size(295, 22);
            this.txt_newname.TabIndex = 22;
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.Location = new System.Drawing.Point(40, 92);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(247, 26);
            this.lbl_nombre.TabIndex = 20;
            this.lbl_nombre.Text = "INGRESE EL NOMBRE:";
            // 
            // brn_volver
            // 
            this.brn_volver.Location = new System.Drawing.Point(427, 219);
            this.brn_volver.Name = "brn_volver";
            this.brn_volver.Size = new System.Drawing.Size(89, 36);
            this.brn_volver.TabIndex = 28;
            this.brn_volver.Text = "VOLVER";
            this.brn_volver.UseVisualStyleBackColor = true;
            this.brn_volver.Click += new System.EventHandler(this.brn_volver_Click);
            // 
            // frm_insertar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.brn_volver);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.txt_edad);
            this.Controls.Add(this.lbl_edad);
            this.Controls.Add(this.txt_newname);
            this.Controls.Add(this.lbl_nombre);
            this.Name = "frm_insertar";
            this.Text = "INSERTA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.TextBox txt_edad;
        private System.Windows.Forms.Label lbl_edad;
        private System.Windows.Forms.TextBox txt_newname;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Button brn_volver;
    }
}