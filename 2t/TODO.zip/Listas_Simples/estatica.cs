﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas_Simples
{
    class estatica
    {
        public static lista_simple lista =new lista_simple();
    }
}
