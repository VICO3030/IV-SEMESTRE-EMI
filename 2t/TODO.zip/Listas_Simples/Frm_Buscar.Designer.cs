﻿namespace Listas_Simples
{
    partial class Frm_Buscar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_volver = new System.Windows.Forms.Button();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.btn_busca = new System.Windows.Forms.Button();
            this.gpb_modificar = new System.Windows.Forms.GroupBox();
            this.txt_newedad = new System.Windows.Forms.TextBox();
            this.btn_actiualizar = new System.Windows.Forms.Button();
            this.lbl_newedad = new System.Windows.Forms.Label();
            this.lbl_puntito = new System.Windows.Forms.Label();
            this.txt_newname = new System.Windows.Forms.TextBox();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.lbl_menoresdeedad = new System.Windows.Forms.Label();
            this.txt_menores = new System.Windows.Forms.TextBox();
            this.btn_menores = new System.Windows.Forms.Button();
            this.gpb_modificar.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_volver
            // 
            this.btn_volver.Location = new System.Drawing.Point(336, 403);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(105, 39);
            this.btn_volver.TabIndex = 9;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = true;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscar.Location = new System.Drawing.Point(10, 60);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(247, 26);
            this.lbl_buscar.TabIndex = 10;
            this.lbl_buscar.Text = "INGRESE EL NOMBRE:";
            // 
            // btn_busca
            // 
            this.btn_busca.Location = new System.Drawing.Point(120, 119);
            this.btn_busca.Name = "btn_busca";
            this.btn_busca.Size = new System.Drawing.Size(105, 39);
            this.btn_busca.TabIndex = 11;
            this.btn_busca.Text = "BUSCAR";
            this.btn_busca.UseVisualStyleBackColor = true;
            this.btn_busca.Click += new System.EventHandler(this.btn_busca_Click);
            // 
            // gpb_modificar
            // 
            this.gpb_modificar.Controls.Add(this.txt_newedad);
            this.gpb_modificar.Controls.Add(this.btn_actiualizar);
            this.gpb_modificar.Controls.Add(this.lbl_newedad);
            this.gpb_modificar.Controls.Add(this.lbl_puntito);
            this.gpb_modificar.Location = new System.Drawing.Point(61, 204);
            this.gpb_modificar.Name = "gpb_modificar";
            this.gpb_modificar.Size = new System.Drawing.Size(487, 179);
            this.gpb_modificar.TabIndex = 13;
            this.gpb_modificar.TabStop = false;
            this.gpb_modificar.Text = "EDAD A MODIFICAR";
            this.gpb_modificar.Visible = false;
            this.gpb_modificar.Enter += new System.EventHandler(this.gbx_modificar_Enter);
            // 
            // txt_newedad
            // 
            this.txt_newedad.Location = new System.Drawing.Point(78, 125);
            this.txt_newedad.Name = "txt_newedad";
            this.txt_newedad.Size = new System.Drawing.Size(100, 22);
            this.txt_newedad.TabIndex = 15;
            this.txt_newedad.TextChanged += new System.EventHandler(this.txt_newedad_TextChanged);
            // 
            // btn_actiualizar
            // 
            this.btn_actiualizar.Location = new System.Drawing.Point(319, 87);
            this.btn_actiualizar.Name = "btn_actiualizar";
            this.btn_actiualizar.Size = new System.Drawing.Size(109, 51);
            this.btn_actiualizar.TabIndex = 14;
            this.btn_actiualizar.Text = "ACTUALIZAR EDAD";
            this.btn_actiualizar.UseVisualStyleBackColor = true;
            this.btn_actiualizar.Click += new System.EventHandler(this.btn_actiualizar_Click);
            // 
            // lbl_newedad
            // 
            this.lbl_newedad.AutoSize = true;
            this.lbl_newedad.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newedad.Location = new System.Drawing.Point(6, 102);
            this.lbl_newedad.Name = "lbl_newedad";
            this.lbl_newedad.Size = new System.Drawing.Size(244, 20);
            this.lbl_newedad.TabIndex = 12;
            this.lbl_newedad.Text = "INGRESE LA NUEVA EDAD";
            this.lbl_newedad.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_newedad.Click += new System.EventHandler(this.lbl_newedad_Click);
            // 
            // lbl_puntito
            // 
            this.lbl_puntito.AutoSize = true;
            this.lbl_puntito.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puntito.Location = new System.Drawing.Point(6, 55);
            this.lbl_puntito.Name = "lbl_puntito";
            this.lbl_puntito.Size = new System.Drawing.Size(19, 26);
            this.lbl_puntito.TabIndex = 11;
            this.lbl_puntito.Text = ".";
            this.lbl_puntito.Click += new System.EventHandler(this.lbl_puntito_Click);
            // 
            // txt_newname
            // 
            this.txt_newname.Location = new System.Drawing.Point(264, 63);
            this.txt_newname.Name = "txt_newname";
            this.txt_newname.Size = new System.Drawing.Size(295, 22);
            this.txt_newname.TabIndex = 14;
            // 
            // btn_modificar
            // 
            this.btn_modificar.Enabled = false;
            this.btn_modificar.Location = new System.Drawing.Point(264, 119);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(109, 51);
            this.btn_modificar.TabIndex = 15;
            this.btn_modificar.Text = "ACTUALIZAR";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Enabled = false;
            this.btn_eliminar.Location = new System.Drawing.Point(411, 119);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(109, 51);
            this.btn_eliminar.TabIndex = 16;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // lbl_menoresdeedad
            // 
            this.lbl_menoresdeedad.AutoSize = true;
            this.lbl_menoresdeedad.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_menoresdeedad.Location = new System.Drawing.Point(12, 22);
            this.lbl_menoresdeedad.Name = "lbl_menoresdeedad";
            this.lbl_menoresdeedad.Size = new System.Drawing.Size(456, 26);
            this.lbl_menoresdeedad.TabIndex = 17;
            this.lbl_menoresdeedad.Text = "ELIMINAR LOS QUE TIENEN LA EDAD DE:";
            // 
            // txt_menores
            // 
            this.txt_menores.Location = new System.Drawing.Point(485, 22);
            this.txt_menores.Name = "txt_menores";
            this.txt_menores.Size = new System.Drawing.Size(87, 22);
            this.txt_menores.TabIndex = 18;
            // 
            // btn_menores
            // 
            this.btn_menores.Location = new System.Drawing.Point(598, 15);
            this.btn_menores.Name = "btn_menores";
            this.btn_menores.Size = new System.Drawing.Size(89, 36);
            this.btn_menores.TabIndex = 19;
            this.btn_menores.Text = "ELIMINAR";
            this.btn_menores.UseVisualStyleBackColor = true;
            this.btn_menores.Click += new System.EventHandler(this.btn_menores_Click);
            // 
            // Frm_Buscar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(891, 547);
            this.Controls.Add(this.btn_menores);
            this.Controls.Add(this.txt_menores);
            this.Controls.Add(this.lbl_menoresdeedad);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.txt_newname);
            this.Controls.Add(this.gpb_modificar);
            this.Controls.Add(this.btn_busca);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.btn_volver);
            this.Name = "Frm_Buscar";
            this.Text = "Frm_Buscar";
            this.Load += new System.EventHandler(this.Frm_Buscar_Load);
            this.gpb_modificar.ResumeLayout(false);
            this.gpb_modificar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Button btn_busca;
        private System.Windows.Forms.GroupBox gpb_modificar;
        private System.Windows.Forms.Label lbl_newedad;
        private System.Windows.Forms.Label lbl_puntito;
        private System.Windows.Forms.TextBox txt_newedad;
        private System.Windows.Forms.Button btn_actiualizar;
        private System.Windows.Forms.TextBox txt_newname;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Label lbl_menoresdeedad;
        private System.Windows.Forms.TextBox txt_menores;
        private System.Windows.Forms.Button btn_menores;
    }
}