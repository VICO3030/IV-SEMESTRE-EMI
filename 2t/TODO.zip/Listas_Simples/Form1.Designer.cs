﻿namespace Listas_Simples
{
    partial class frm_listas
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.LBL_EDAD = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_edad = new System.Windows.Forms.TextBox();
            this.lst_lista = new System.Windows.Forms.ListBox();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.btn_msalir = new System.Windows.Forms.Button();
            this.btn_edadp = new System.Windows.Forms.Button();
            this.lbl_edadp = new System.Windows.Forms.Label();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.btn_mayormenor = new System.Windows.Forms.Button();
            this.lbl_mayormenor = new System.Windows.Forms.Label();
            this.rdb_nombres = new System.Windows.Forms.RadioButton();
            this.rdb_edades = new System.Windows.Forms.RadioButton();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.Location = new System.Drawing.Point(102, 186);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(114, 26);
            this.lbl_nombre.TabIndex = 0;
            this.lbl_nombre.Text = "NOMBRE:";
            this.lbl_nombre.Click += new System.EventHandler(this.lbl_nombre_Click);
            // 
            // LBL_EDAD
            // 
            this.LBL_EDAD.AutoSize = true;
            this.LBL_EDAD.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_EDAD.Location = new System.Drawing.Point(102, 229);
            this.LBL_EDAD.Name = "LBL_EDAD";
            this.LBL_EDAD.Size = new System.Drawing.Size(82, 26);
            this.LBL_EDAD.TabIndex = 1;
            this.LBL_EDAD.Text = "EDAD:";
            this.LBL_EDAD.Click += new System.EventHandler(this.LBL_EDAD_Click);
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(231, 182);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(196, 30);
            this.txt_nombre.TabIndex = 2;
            this.txt_nombre.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_edad
            // 
            this.txt_edad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_edad.Location = new System.Drawing.Point(199, 225);
            this.txt_edad.Name = "txt_edad";
            this.txt_edad.Size = new System.Drawing.Size(196, 30);
            this.txt_edad.TabIndex = 3;
            this.txt_edad.TextChanged += new System.EventHandler(this.txt_edad_TextChanged);
            // 
            // lst_lista
            // 
            this.lst_lista.FormattingEnabled = true;
            this.lst_lista.ItemHeight = 16;
            this.lst_lista.Location = new System.Drawing.Point(107, 325);
            this.lst_lista.Name = "lst_lista";
            this.lst_lista.Size = new System.Drawing.Size(232, 148);
            this.lst_lista.TabIndex = 4;
            this.lst_lista.SelectedIndexChanged += new System.EventHandler(this.lst_lista_SelectedIndexChanged);
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(756, 372);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(144, 56);
            this.btn_salir.TabIndex = 5;
            this.btn_salir.Text = "REGISTRAR ESTUDIANTE";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(795, 434);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(105, 39);
            this.btn_mostrar.TabIndex = 6;
            this.btn_mostrar.Text = "MOSTRAR";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.Location = new System.Drawing.Point(795, 479);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(105, 39);
            this.btn_limpiar.TabIndex = 7;
            this.btn_limpiar.Text = "LIMPIAR";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // btn_msalir
            // 
            this.btn_msalir.Location = new System.Drawing.Point(795, 524);
            this.btn_msalir.Name = "btn_msalir";
            this.btn_msalir.Size = new System.Drawing.Size(105, 39);
            this.btn_msalir.TabIndex = 8;
            this.btn_msalir.Text = "SALIR";
            this.btn_msalir.UseVisualStyleBackColor = true;
            this.btn_msalir.Click += new System.EventHandler(this.btn_msalir_Click);
            // 
            // btn_edadp
            // 
            this.btn_edadp.Location = new System.Drawing.Point(100, 527);
            this.btn_edadp.Name = "btn_edadp";
            this.btn_edadp.Size = new System.Drawing.Size(116, 54);
            this.btn_edadp.TabIndex = 9;
            this.btn_edadp.Text = "EDAD PROMEDIO";
            this.btn_edadp.UseVisualStyleBackColor = true;
            this.btn_edadp.Visible = false;
            this.btn_edadp.Click += new System.EventHandler(this.btn_edadp_Click);
            // 
            // lbl_edadp
            // 
            this.lbl_edadp.AutoSize = true;
            this.lbl_edadp.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_edadp.Location = new System.Drawing.Point(190, 484);
            this.lbl_edadp.Name = "lbl_edadp";
            this.lbl_edadp.Size = new System.Drawing.Size(0, 24);
            this.lbl_edadp.TabIndex = 10;
            this.lbl_edadp.Click += new System.EventHandler(this.lbl_edadp_Click);
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(320, 34);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(317, 43);
            this.lbl_titulo.TabIndex = 11;
            this.lbl_titulo.Text = "LISTAS SIMPLES";
            // 
            // btn_mayormenor
            // 
            this.btn_mayormenor.Location = new System.Drawing.Point(231, 524);
            this.btn_mayormenor.Name = "btn_mayormenor";
            this.btn_mayormenor.Size = new System.Drawing.Size(120, 57);
            this.btn_mayormenor.TabIndex = 12;
            this.btn_mayormenor.Text = "EDAD MAYOR Y MENOR";
            this.btn_mayormenor.UseVisualStyleBackColor = true;
            this.btn_mayormenor.Visible = false;
            this.btn_mayormenor.Click += new System.EventHandler(this.btn_mayormenor_Click);
            // 
            // lbl_mayormenor
            // 
            this.lbl_mayormenor.AutoSize = true;
            this.lbl_mayormenor.Font = new System.Drawing.Font("Stencil", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mayormenor.Location = new System.Drawing.Point(373, 524);
            this.lbl_mayormenor.Name = "lbl_mayormenor";
            this.lbl_mayormenor.Size = new System.Drawing.Size(0, 20);
            this.lbl_mayormenor.TabIndex = 13;
            // 
            // rdb_nombres
            // 
            this.rdb_nombres.AutoSize = true;
            this.rdb_nombres.Location = new System.Drawing.Point(388, 372);
            this.rdb_nombres.Name = "rdb_nombres";
            this.rdb_nombres.Size = new System.Drawing.Size(96, 20);
            this.rdb_nombres.TabIndex = 15;
            this.rdb_nombres.TabStop = true;
            this.rdb_nombres.Text = "NOMBRES";
            this.rdb_nombres.UseVisualStyleBackColor = true;
            this.rdb_nombres.Visible = false;
            this.rdb_nombres.CheckedChanged += new System.EventHandler(this.rdb_nombres_CheckedChanged);
            // 
            // rdb_edades
            // 
            this.rdb_edades.AutoSize = true;
            this.rdb_edades.Location = new System.Drawing.Point(388, 408);
            this.rdb_edades.Name = "rdb_edades";
            this.rdb_edades.Size = new System.Drawing.Size(84, 20);
            this.rdb_edades.TabIndex = 16;
            this.rdb_edades.TabStop = true;
            this.rdb_edades.Text = "EDADES";
            this.rdb_edades.UseVisualStyleBackColor = true;
            this.rdb_edades.Visible = false;
            this.rdb_edades.CheckedChanged += new System.EventHandler(this.rdb_edades_CheckedChanged);
            // 
            // btn_buscar
            // 
            this.btn_buscar.Location = new System.Drawing.Point(756, 312);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(144, 54);
            this.btn_buscar.TabIndex = 17;
            this.btn_buscar.Text = "BUSCAR Y ELIMINAR";
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_insertar
            // 
            this.btn_insertar.Location = new System.Drawing.Point(756, 252);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(144, 54);
            this.btn_insertar.TabIndex = 18;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // frm_listas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(912, 593);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.rdb_edades);
            this.Controls.Add(this.rdb_nombres);
            this.Controls.Add(this.lbl_mayormenor);
            this.Controls.Add(this.btn_mayormenor);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.lbl_edadp);
            this.Controls.Add(this.btn_edadp);
            this.Controls.Add(this.btn_msalir);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.lst_lista);
            this.Controls.Add(this.txt_edad);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.LBL_EDAD);
            this.Controls.Add(this.lbl_nombre);
            this.Name = "frm_listas";
            this.Text = "LISTAS SIMPLES";
            this.Load += new System.EventHandler(this.frm_listas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label LBL_EDAD;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_edad;
        private System.Windows.Forms.ListBox lst_lista;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Button btn_msalir;
        private System.Windows.Forms.Button btn_edadp;
        private System.Windows.Forms.Label lbl_edadp;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Button btn_mayormenor;
        private System.Windows.Forms.Label lbl_mayormenor;
        private System.Windows.Forms.RadioButton rdb_nombres;
        private System.Windows.Forms.RadioButton rdb_edades;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_insertar;
    }
}

