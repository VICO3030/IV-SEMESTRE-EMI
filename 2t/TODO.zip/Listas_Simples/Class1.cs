﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas_Simples
{
    class Nodo
    {
        //Los atributos de las clases por defecto son privados
        //Los structs por defecto son publicos
        string nombre;
        int edad;
        Nodo enlace;//Direccion del nodo con el que se enlasa
        public Nodo()
        {
            nombre = "";
            edad = 0;
            enlace = null;
        }
        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }
        public void setEdad(int edad)
        {
            this.edad = edad;
        }
        public void setEnlace(Nodo punt)
        {
            enlace= punt;
        }
        public string getNombre()
        {
            return nombre;
        }
        public int getEdad()
        {
            return edad;  
        }
        public Nodo getEnlace()
        {
            return enlace;
        }
    }
    
}
