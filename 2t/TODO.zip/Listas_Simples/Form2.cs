﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas_Simples
{
    public partial class frm_insertar : Form
    {
        public frm_insertar()
        {
            InitializeComponent();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            int edad= int.Parse(txt_edad.Text);
            MessageBox.Show(estatica.lista.insertar(txt_newname.Text,edad));
        }

        private void brn_volver_Click(object sender, EventArgs e)
        {
            frm_listas principal = new frm_listas();
            this.Hide();
            principal.Show();
        }
    }
}
