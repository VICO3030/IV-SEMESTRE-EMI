﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas_Simples
{
    public partial class frm_listas : Form
    {
        //lista_simple lista;
        public frm_listas()
        {
            InitializeComponent();
            //lista = new lista_simple();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {

            string nombre = txt_nombre.Text;
            int edad = int.Parse(txt_edad.Text);
            btn_edadp.Visible = true;
            btn_mayormenor.Visible = true;
            rdb_edades.Visible = true;
            rdb_nombres.Visible = true;
            estatica.lista.crearLista(nombre, edad);
            MessageBox.Show("Alumno REGITRADO!");
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            mostrar();
        }

        private void lst_lista_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_edad_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_nombre_Click(object sender, EventArgs e)
        {

        }

        private void LBL_EDAD_Click(object sender, EventArgs e)
        {

        }

        private void btn_msalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            txt_nombre.Clear();
            txt_edad.Clear();
            lbl_edadp.Text = "";
            lbl_edadp.Text = "";
            lst_lista.Items.Clear();
        }
        public void mostrar()
        {
            Nodo punt;
            punt = estatica.lista.getCabeza();
            while( punt != null )
            {
                lst_lista.Items.Add("NOMBRE: "+punt.getNombre());
                lst_lista.Items.Add("EDAD: " + punt.getEdad());
                lst_lista.Items.Add("_________________________");
                punt = punt.getEnlace();
            }
        }

        private void btn_edadp_Click(object sender, EventArgs e)
        {

            lbl_edadp.Text= "El promedio es:"+ estatica.lista.edadPromedio().ToString();

        }

        private void lbl_edadp_Click(object sender, EventArgs e)
        {

        }

        private void frm_listas_Load(object sender, EventArgs e)
        {

        }

        private void btn_mayormenor_Click(object sender, EventArgs e)
        {
            lbl_mayormenor.Text= estatica.lista.mayormenor().ToString();  
        }

        private void btn_ORDENAR_Click(object sender, EventArgs e)
        {
            
        }
        
        private void rdb_edades_CheckedChanged(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            estatica.lista.ordenar();
            mostrar();
        }

        private void rdb_nombres_CheckedChanged(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            estatica.lista.ordenar2();
            mostrar();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            Frm_Buscar Buscar = new Frm_Buscar();
            this.Hide();//para ocultar
            Buscar.Show();//muestra el otro formulario cxdxddxdxdxdxd
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            frm_insertar Insertar=new frm_insertar();
            this.Hide();
            Insertar.Show();
        }
    }
}
