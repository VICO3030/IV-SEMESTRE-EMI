﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas_Simples
{
    class lista_simple
    {
        Nodo cabeza, nuevo;
        public lista_simple()
        {
            cabeza = null;
            nuevo = null;
        }
        public void crearNodo(string nom,int edad)
        {
            nuevo=new Nodo();
            nuevo.setNombre(nom);
            nuevo.setEdad(edad);
            nuevo.setEnlace(null);
        }
        public void crearLista(string nom, int edad)
        {
            Nodo punt;
            crearNodo(nom, edad);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                punt=cabeza;
                while(punt.getEnlace()!=null)
                {
                    punt=punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }

        }
        public Nodo getCabeza()
        {
            return cabeza;
        }
        public int edadPromedio()
        {
            int pedad = 0;
            int acu = 0,cont = 0;
            Nodo punt=cabeza;
            while (punt != null)
            {
                acu = punt.getEdad() + acu;
                cont++;
                punt = punt.getEnlace();
            }
            if (cont!=0)
            {
                pedad =  (acu) / cont;
            }
            return pedad;
        }
        public string mayormenor()
        {
            int mayor = 0, menor = 100;
            string nmayor="", nmenor="";
            Nodo punt = cabeza;
            while (punt != null)
            {
                if(mayor<punt.getEdad())
                {
                    mayor=punt.getEdad();
                    nmayor=punt.getNombre();
                }
                if (menor > punt.getEdad())
                {
                    menor = punt.getEdad();
                    nmenor = punt.getNombre();
                }
                punt = punt.getEnlace();
            }


            return ("LA MAYOR EDAD ES DE " + nmayor + " CON " + mayor + " AÑOS\n"+
                "LA MENOR EDAD ES DE " + nmenor + " CON " + menor + " AÑOS" );
        }
        public void ordenar()
        {
            int aux;
            string aux2;
            Nodo punt = cabeza;
            while (punt != null)
            {
                Nodo punt2=punt.getEnlace();
                while (punt2 != null)
                {

                    if (punt2.getEdad() < punt.getEdad())
                    {
                        aux = punt.getEdad();
                        punt.setEdad(punt2.getEdad()) ;
                        punt2.setEdad(aux);

                        aux2 = punt.getNombre();
                        punt.setNombre(punt2.getNombre());
                        punt2.setNombre(aux2);
                    }
                    punt2 = punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }
        }
        public void ordenar2()
        {
            int aux;
            string aux2;
            Nodo punt = cabeza;
            while (punt != null)
            {
                Nodo punt2 = punt.getEnlace();
                while (punt2 != null)
                {

                    if (punt.getNombre().CompareTo(punt2.getNombre())>0)
                    {
                        aux = punt.getEdad();
                        punt.setEdad(punt2.getEdad());
                        punt2.setEdad(aux);

                        aux2 = punt.getNombre();
                        punt.setNombre(punt2.getNombre());
                        punt2.setNombre(aux2);
                    }
                    punt2 = punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }
        }
        public bool buscar(string nombre)
        {
            Nodo punt = cabeza;
            while (punt != null)
            {
                if (punt.getNombre()==nombre)
                {
                    return true;
                }
                punt = punt.getEnlace();
            }
            return false;
        }
        public Nodo modificar(string nombre)
        {
            Nodo punt = cabeza;
            while (punt != null)
            {
                if (punt.getNombre() == nombre)
                {
                    return punt;
                }
                punt = punt.getEnlace();
            }
            return punt;
        }
        public string eliminar(string nombre)
        {
            Nodo actual = cabeza;
            Nodo anterior= null;
            while (actual != null)
            {
                if(cabeza.getNombre()==nombre)
                {
                    cabeza = cabeza.getEnlace();
                    actual.setEnlace(null);
                    return ("SE ELIMINO A " + actual.getNombre());
                }
                else
                {
                    if (actual.getNombre() == nombre)
                    {
                        anterior.setEnlace(actual.getEnlace());
                        actual.setEnlace(null);
                        return ("SE ELIMINO A " + actual.getNombre());
                    }
                    anterior = actual;
                    actual = actual.getEnlace();
                }
            }
            return "NO EXISTE";
        }
        public string eliminaredad(int edad)
        {
            Nodo actual = cabeza;
            Nodo anterior = null;
            Nodo AUX = null;
            int cont=0;
            while (actual != null)
            {
                AUX=actual;
                if (cabeza.getEdad()==edad && actual==cabeza)
                {
                    cabeza = cabeza.getEnlace();
                    anterior = actual;
                    actual = actual.getEnlace();
                    AUX.setEnlace(null);
                    cont++;
                }
                else
                {
                    if (actual.getEdad() == edad)
                    {
                        anterior.setEnlace(actual.getEnlace());
                        actual = actual.getEnlace();
                        AUX.setEnlace(null);
                        cont++;
                    }
                    else
                    {
                        anterior = actual;
                        actual = actual.getEnlace();
                    }
                }
                
            }
            return "SE ELIMINARON A LOS MENORES DE "+edad+" Y SON: "+cont;
        }
            
        public string insertar(string nombre, int edad)
        {
            Nodo actual = cabeza;
            Nodo anterior=null;
            crearNodo(nombre,edad);

            while (actual != null)
            {
                if (cabeza.getEdad() >edad)
                {
                    nuevo.setEnlace(cabeza);
                    cabeza=nuevo;
                    
                    return ("SE INSERTO CON EXITO");
                }
                else
                {
                    if (actual.getEdad() > edad)
                    {
                        nuevo.setEnlace(actual);
                        anterior.setEnlace(nuevo);
                        return "SE INSERTO CON EXITO";
                    }
                    else
                    {
                        anterior = actual;
                        actual = actual.getEnlace();
                        
                    }
                }
            }
            anterior.setEnlace(nuevo);
            return "SE INSERTO CON EXITO";
        }
    }
}
