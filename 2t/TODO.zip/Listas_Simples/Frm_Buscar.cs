﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas_Simples
{
    public partial class Frm_Buscar : Form
    {
        public Frm_Buscar()
        {
            InitializeComponent();
        }

        private void Frm_Buscar_Load(object sender, EventArgs e)
        {

        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_listas principal=new frm_listas();
            this.Hide();
            principal.Show();
        }

        private void lbl_newedad_Click(object sender, EventArgs e)
        {

        }

        private void gbx_modificar_Enter(object sender, EventArgs e)
        {

        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            gpb_modificar.Visible = true;

            Nodo punt = estatica.lista.modificar(txt_newname.Text);
            lbl_puntito.Text = " LA EDAD ACTUAL ES: " + punt.getEdad();
        }

        private void btn_actiualizar_Click(object sender, EventArgs e)
        {
            gpb_modificar.Visible = false;
            Nodo punt = estatica.lista.modificar(txt_newname.Text);
            punt.setEdad(int.Parse(txt_newedad.Text));
        }

        private void btn_busca_Click(object sender, EventArgs e)
        {
            bool existe;
            existe = estatica.lista.buscar(txt_newname.Text);
            if (existe)
            {
                MessageBox.Show(txt_newname.Text + " EXISTEEEEEEE!");
                btn_modificar.Enabled = true;
                btn_eliminar.Enabled=true;
            }
            else
            {
                MessageBox.Show(txt_newname.Text + " NO EXISTEEEEEEE!");

            }
        }

        private void txt_newedad_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(estatica.lista.eliminar(txt_newname.Text));
        }

        private void btn_menores_Click(object sender, EventArgs e)
        {

            MessageBox.Show(estatica.lista.eliminaredad(int.Parse(txt_menores.Text)));
        }

        private void lbl_puntito_Click(object sender, EventArgs e)
        {

        }
    }
}
