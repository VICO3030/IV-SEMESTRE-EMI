﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2Primerparcial
{
     class LISTA
    {
        Nodo cabeza, nuevo;
        public LISTA()
        {
            cabeza = null;
            nuevo = null;
        }
        public void crearNodo(int num)
        {
            nuevo = new Nodo();
            nuevo.setNum(num);
            nuevo.setEnlace(null);
        }
        public void crearLista(int num)
        {
            Nodo punt;
            crearNodo(num);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                punt = cabeza;
                while (punt.getEnlace() != null)
                {
                    punt = punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }

        }
        public Nodo getCabeza()
        {
            return cabeza;
        }
        public Nodo buscar(int num)
        {
            Nodo punt = cabeza;
            while (punt != null)
            {
                if (punt.getNum() == num)
                {
                    return punt;
                }
                punt = punt.getEnlace();
            }
            return punt;
        }

        public string eliminarNum(int n)
        {
            Nodo actual = cabeza;
            Nodo anterior = null;
            Nodo AUX = null;
            int cont = 0;
            while (actual != null)
            {
                AUX = actual;
                if (cabeza.getNum() == n && actual == cabeza)
                {
                    cabeza = cabeza.getEnlace();
                    anterior = actual;
                    actual = actual.getEnlace();
                    AUX.setEnlace(null);
                    cont++;
                }
                else
                {
                    if (actual.getNum() == n)
                    {
                        anterior.setEnlace(actual.getEnlace());
                        actual = actual.getEnlace();
                        AUX.setEnlace(null);
                        cont++;
                    }
                    else
                    {
                        anterior = actual;
                        actual = actual.getEnlace();
                    }
                }

            }
            return "SE ELIMINARON A" + n + " Y SON: " + cont;
        }
    }
}
