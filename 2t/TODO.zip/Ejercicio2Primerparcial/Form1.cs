﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio2Primerparcial
{
    public partial class Form1 : Form
    {
        LISTA li1=new LISTA();
        LISTA li2 = new LISTA();
        LISTA li3 = new LISTA();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            li1.crearLista(int.Parse(txt_l1.Text));
            MessageBox.Show("REGITRADO!");
            lst_lista.Items.Clear();
            Nodo punt;

            punt = li1.getCabeza();
            while (punt != null)
            {
                lst_lista.Items.Add(punt.getNum());

                punt = punt.getEnlace();
            }
        }

        private void lst_lista2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_registrar2_Click(object sender, EventArgs e)
        {
            li2.crearLista(int.Parse(txt_l2.Text));
            MessageBox.Show("REGITRADO!");
            lst_lista2.Items.Clear();
            Nodo punt;

            punt = li2.getCabeza();
            while (punt != null)
            {
                lst_lista2.Items.Add(punt.getNum());

                punt = punt.getEnlace();
            }
        }

        private void btn_Unir_Click(object sender, EventArgs e)
        {
            lst_lista3.Items.Clear();
            Nodo punt;
            Nodo punt2;
            punt = li1.getCabeza();
            punt2 = li2.getCabeza();
            while (punt != null || punt2 != null)
            {
                if(punt != null)
                {
                    li3.crearLista(punt.getNum());
                    punt = punt.getEnlace();

                }
                if (punt2 != null)
                {
                    li3.crearLista(punt2.getNum());
                    punt2 = punt2.getEnlace();
                }
            }
            lst_lista3.Items.Clear();
            Nodo punt3;

            punt3 = li3.getCabeza();
            while (punt3 != null)
            {
                lst_lista3.Items.Add(punt3.getNum());

                punt3 = punt3.getEnlace();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
