﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EJERCICIO_1_PRIMER_PARCIAL
{
    public partial class frm_ejer1 : Form
    {
        LISTA l =new LISTA();
        LISTA aux = new LISTA();
        LISTA r = new LISTA();
        public frm_ejer1()
        {
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            l.crearLista(int.Parse(txt_numero.Text));
            MessageBox.Show("REGITRADO!");
        }

        private void lst_l_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_mostrarl_Click(object sender, EventArgs e)
        {
            Nodo punt;
            Nodo punt2;
            punt = l.getCabeza();
            punt2 = punt;
            while (punt != null)
            {
                punt2 = punt.getEnlace();
                while (punt2 != null)
                {
                    
                    if (punt.getNum()==punt2.getNum() && (r.buscar(punt.getNum()) != true))
                    {
                        r.crearLista(punt.getNum());
                    }
                    punt2=punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }


            punt = l.getCabeza();
            lst_l.Items.Clear();
            while (punt != null)
            {
                lst_l.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }
        }

        private void btn_mostrarr_Click(object sender, EventArgs e)
        {
            Nodo punt = r.getCabeza();
            lst_r.Items.Clear();
            while (punt != null)
            {
                lst_r.Items.Add(punt.getNum());
                punt = punt.getEnlace();
            }

            punt = r.getCabeza();
            while (punt != null)
            {
                if (r.buscar(punt.getNum()))
                {
                    l.eliminarNum(punt.getNum());
                }
                punt = punt.getEnlace();
            }
        }

        private void frm_ejer1_Load(object sender, EventArgs e)
        {

        }
    }
}
