﻿namespace EJERCICIO_1_PRIMER_PARCIAL
{
    partial class frm_ejer1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_numero = new System.Windows.Forms.TextBox();
            this.lbl_numero = new System.Windows.Forms.Label();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.lst_l = new System.Windows.Forms.ListBox();
            this.btn_mostrarl = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_mostrarr = new System.Windows.Forms.Button();
            this.lst_r = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txt_numero
            // 
            this.txt_numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numero.Location = new System.Drawing.Point(391, 69);
            this.txt_numero.Name = "txt_numero";
            this.txt_numero.Size = new System.Drawing.Size(113, 28);
            this.txt_numero.TabIndex = 10;
            // 
            // lbl_numero
            // 
            this.lbl_numero.AutoSize = true;
            this.lbl_numero.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numero.Location = new System.Drawing.Point(87, 72);
            this.lbl_numero.Name = "lbl_numero";
            this.lbl_numero.Size = new System.Drawing.Size(288, 22);
            this.lbl_numero.TabIndex = 9;
            this.lbl_numero.Text = "INGRESE EL NUMERO PARA L:";
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_registrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(548, 60);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(131, 46);
            this.btn_registrar.TabIndex = 14;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // lst_l
            // 
            this.lst_l.FormattingEnabled = true;
            this.lst_l.ItemHeight = 16;
            this.lst_l.Location = new System.Drawing.Point(54, 193);
            this.lst_l.Name = "lst_l";
            this.lst_l.Size = new System.Drawing.Size(358, 148);
            this.lst_l.TabIndex = 15;
            this.lst_l.SelectedIndexChanged += new System.EventHandler(this.lst_l_SelectedIndexChanged);
            // 
            // btn_mostrarl
            // 
            this.btn_mostrarl.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_mostrarl.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarl.Location = new System.Drawing.Point(165, 347);
            this.btn_mostrarl.Name = "btn_mostrarl";
            this.btn_mostrarl.Size = new System.Drawing.Size(131, 46);
            this.btn_mostrarl.TabIndex = 16;
            this.btn_mostrarl.Text = "MOSTRAR";
            this.btn_mostrarl.UseVisualStyleBackColor = false;
            this.btn_mostrarl.Click += new System.EventHandler(this.btn_mostrarl_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "LISTA L:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(669, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 22);
            this.label2.TabIndex = 20;
            this.label2.Text = "LISTA L:";
            // 
            // btn_mostrarr
            // 
            this.btn_mostrarr.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_mostrarr.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarr.Location = new System.Drawing.Point(649, 347);
            this.btn_mostrarr.Name = "btn_mostrarr";
            this.btn_mostrarr.Size = new System.Drawing.Size(131, 46);
            this.btn_mostrarr.TabIndex = 19;
            this.btn_mostrarr.Text = "MOSTRAR";
            this.btn_mostrarr.UseVisualStyleBackColor = false;
            this.btn_mostrarr.Click += new System.EventHandler(this.btn_mostrarr_Click);
            // 
            // lst_r
            // 
            this.lst_r.FormattingEnabled = true;
            this.lst_r.ItemHeight = 16;
            this.lst_r.Location = new System.Drawing.Point(538, 193);
            this.lst_r.Name = "lst_r";
            this.lst_r.Size = new System.Drawing.Size(358, 148);
            this.lst_r.TabIndex = 18;
            // 
            // frm_ejer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(985, 552);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_mostrarr);
            this.Controls.Add(this.lst_r);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_mostrarl);
            this.Controls.Add(this.lst_l);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.txt_numero);
            this.Controls.Add(this.lbl_numero);
            this.Name = "frm_ejer1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frm_ejer1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_numero;
        private System.Windows.Forms.Label lbl_numero;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.ListBox lst_l;
        private System.Windows.Forms.Button btn_mostrarl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_mostrarr;
        private System.Windows.Forms.ListBox lst_r;
    }
}

