﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArbolesBinarios
{
    public partial class frm_grafico : Form
    {
        public frm_grafico()
        {
            
            InitializeComponent();
            Graphics nodo;
            nodo = CreateGraphics();

            nodo.FillEllipse(Brushes.Aqua, 320, 30, 250, 250);
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_graficar_Click(object sender, EventArgs e)
        {
            frm_main princ = new frm_main();
            this.Hide();
            princ.Show();
        }
        private void graficar()
        {
            Graphics nodo;
            nodo = CreateGraphics();
            int posx = 450;
            int posy = 30;
            int tam = 50;
            nodo.FillEllipse(Brushes.Peru, posx, posy, tam, tam);
            nodo.DrawString("N", Font, Brushes.Black, posx+18,posy+18);
            Pen lapiz;
            lapiz = new Pen(Brushes.Black, 2);
            nodo.DrawEllipse(lapiz, posx, posy, 50, 50);

            //resto 150 a x and sumo 60 a y
             posx = 300;
             posy = 90;
            nodo.FillEllipse(Brushes.Peru, posx, posy, 50, 50);
            nodo.DrawString("N", Font, Brushes.Black, posx + 18, posy + 18);
            lapiz = new Pen(Brushes.Black, 2);
            nodo.DrawEllipse(lapiz, posx, posy, 50, 50);
            //alrevez
            posx = 600;
            posy = 90;

            nodo.FillEllipse(Brushes.Peru, posx, posy, 50, 50);
            nodo.DrawString("N", Font, Brushes.Black, posx + 18, posy + 18);
            lapiz = new Pen(Brushes.Black, 2);
            nodo.DrawEllipse(lapiz, posx, posy, 50, 50);
            //LINEAS PARA UNIR
            nodo.DrawLine(lapiz, 450+tam/2, 30+tam/2,posx+tam/2, posy+tam/2) ;
            nodo.DrawLine(lapiz, 450 + tam / 2, 30 + tam / 2, 300 + tam / 2, 90 + tam / 2);


        }
        private void crearL(int posx, int posy,int posx2,int posy2,int tam)
        {
            Graphics nodo;
            nodo = CreateGraphics();
            Pen lapiz;
            lapiz = new Pen(Brushes.Black, 2);
            nodo.DrawLine(lapiz, posx + tam / 2, posy + tam / 2, posx2 + tam / 2, posy2 + tam / 2);
        }
        private void crearE(int posx, int posy, int tam, int num)
        {
            Graphics nodo;
            nodo = CreateGraphics();
            Pen lapiz;
            lapiz = new Pen(Brushes.Black, 2);

            nodo.FillEllipse(Brushes.Peru, posx, posy, tam, tam);
            nodo.DrawString(num.ToString(), Font, Brushes.Black, posx + 18, posy + 18);
            nodo.DrawEllipse(lapiz, posx, posy, tam, tam);
        }
        private void graficarA(int posx, int posy, int tam,Nodo r)
        {

            crearE(posx, posy, tam, r.Dato);
            if (r.Izq != null)
            {
                graficarA(posx-150, posy+60, tam, r.Izq);
            }
            if (r.Der != null)
            {
                graficarA(posx + 150, posy + 60, tam, r.Der);
            }
        }
        private void graficarL(int posx, int posy, int tam, Nodo r)
        {

            if (r.Izq != null)
            {
                crearL(posx, posy, posx - 150, posy+60, tam);
                graficarL(posx - 150, posy + 60, tam, r.Izq);
            }
            if (r.Der != null)
            {
                crearL(posx, posy, posx + 150, posy+60, tam);
                graficarL(posx + 150, posy + 60, tam, r.Der);
            }
        }
        private void graficarL2(int posx, int posy, int tam, Nodo r,int nivel)
        {

            if (r.Izq != null)
            {
                crearL(posx, posy, posx - 150+40*nivel, posy + 60, tam);
                graficarL2(posx - 150 + 40 * nivel, posy + 60, tam, r.Izq,nivel+1);
            }
            if (r.Der != null)
            {
                crearL(posx, posy, posx + 150 - 40 * nivel, posy + 60, tam);
                graficarL2(posx + 150- 40 * nivel, posy + 60, tam, r.Der,nivel+1);
            }
        }
        private void graficarA2(int posx, int posy, int tam, Nodo r, int nivel)
        {
            crearE(posx, posy, tam, r.Dato);
            if (r.Izq != null)
            {
                graficarA2(posx - 150 + 40 * nivel, posy + 60, tam, r.Izq,nivel+1);
            }
            if (r.Der != null)
            {
                graficarA2(posx + 150 - 40 * nivel, posy + 60, tam, r.Der,nivel+1);
            }
        }
        private void graficar2()
        {
            int posx = 450;
            int posy = 30;
            int tam = 50;
            graficarL2(posx, posy, tam, Estatica.a.getRaiz(),0);
            graficarA2(posx, posy, tam, Estatica.a.getRaiz(),0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Estatica.a.getRaiz() != null)
            {
                graficar2();
            }
            else MessageBox.Show("NO HAY NINGUN DATO EN EL ARBOL");
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_recorrido_Click(object sender, EventArgs e)
        {
            lbl_recorrido.Text = "EL RECORRIDO ES: " + Estatica.a.recorrido(int.Parse(txt_num.Text));
            lbl_nivel.Text= "EL NIVEL ES: "+Estatica.a.nivel(int.Parse(txt_num.Text));
            lblAltura.Text = "EL ALTURA ES: " + Estatica.a.altura(int.Parse(txt_num.Text));
        }
    }
}
