﻿namespace ArbolesBinarios
{
    partial class frm_grafico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_graficar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_recorrido = new System.Windows.Forms.Button();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lbl_num = new System.Windows.Forms.Label();
            this.lbl_recorrido = new System.Windows.Forms.Label();
            this.lbl_nivel = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_graficar
            // 
            this.btn_graficar.BackColor = System.Drawing.Color.Peru;
            this.btn_graficar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_graficar.Location = new System.Drawing.Point(526, 637);
            this.btn_graficar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_graficar.Name = "btn_graficar";
            this.btn_graficar.Size = new System.Drawing.Size(144, 54);
            this.btn_graficar.TabIndex = 24;
            this.btn_graficar.Text = "SALIR";
            this.btn_graficar.UseVisualStyleBackColor = false;
            this.btn_graficar.Click += new System.EventHandler(this.btn_graficar_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Peru;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(354, 637);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 54);
            this.button1.TabIndex = 25;
            this.button1.Text = "MOSTRAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_recorrido
            // 
            this.btn_recorrido.BackColor = System.Drawing.Color.Peru;
            this.btn_recorrido.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_recorrido.Location = new System.Drawing.Point(551, 524);
            this.btn_recorrido.Name = "btn_recorrido";
            this.btn_recorrido.Size = new System.Drawing.Size(144, 54);
            this.btn_recorrido.TabIndex = 28;
            this.btn_recorrido.Text = "RECORRIDO";
            this.btn_recorrido.UseVisualStyleBackColor = false;
            this.btn_recorrido.Click += new System.EventHandler(this.btn_recorrido_Click);
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(302, 534);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(196, 30);
            this.txt_num.TabIndex = 27;
            // 
            // lbl_num
            // 
            this.lbl_num.AutoSize = true;
            this.lbl_num.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(23, 538);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(246, 26);
            this.lbl_num.TabIndex = 26;
            this.lbl_num.Text = "INGRESE UN NUMERO";
            // 
            // lbl_recorrido
            // 
            this.lbl_recorrido.AutoSize = true;
            this.lbl_recorrido.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_recorrido.Location = new System.Drawing.Point(23, 579);
            this.lbl_recorrido.Name = "lbl_recorrido";
            this.lbl_recorrido.Size = new System.Drawing.Size(219, 26);
            this.lbl_recorrido.TabIndex = 29;
            this.lbl_recorrido.Text = "EL RECORRIDO ES: ";
            // 
            // lbl_nivel
            // 
            this.lbl_nivel.AutoSize = true;
            this.lbl_nivel.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nivel.Location = new System.Drawing.Point(23, 615);
            this.lbl_nivel.Name = "lbl_nivel";
            this.lbl_nivel.Size = new System.Drawing.Size(149, 26);
            this.lbl_nivel.TabIndex = 30;
            this.lbl_nivel.Text = "EL NIVEL ES:";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(316, 615);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(182, 26);
            this.lblAltura.TabIndex = 31;
            this.lblAltura.Text = "LA ALTURA ES:";
            // 
            // frm_grafico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(1025, 710);
            this.Controls.Add(this.lbl_nivel);
            this.Controls.Add(this.lbl_recorrido);
            this.Controls.Add(this.btn_recorrido);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_graficar);
            this.Controls.Add(this.lblAltura);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_grafico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "GRAFICO";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_graficar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_recorrido;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.Label lbl_recorrido;
        private System.Windows.Forms.Label lbl_nivel;
        private System.Windows.Forms.Label lblAltura;
    }
}