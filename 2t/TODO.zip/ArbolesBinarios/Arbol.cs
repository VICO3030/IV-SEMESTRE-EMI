﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
namespace ArbolesBinarios
{
    class Arbol
    {
        Nodo raiz, nuevo;
        public Arbol()
        {
            raiz = null;
            nuevo = null;
        }
        public void crearNodo(int d)
        {
            this.nuevo = new Nodo();
            nuevo.Dato = d;//set
            nuevo.Der = null;
            nuevo.Izq = null;
        }
        public void crearArbol(int d)
        {
            crearNodo(d);
            if (raiz == null)
            {
                raiz = nuevo;
            }
            else
            {
                /*
                Nodo aux = raiz;
                bool loop = true;
                while (loop)
                {
                    if (aux.Dato > d)
                    {
                        if (aux.Der == null)
                        {
                            aux.Der = nuevo;
                           
                            loop=false;
                        }
                        else
                        {
                            aux = aux.Der;
                        }

                    }
                    else
                    {
                        if (aux.Izq == null)
                        {
                            aux.Izq = nuevo;
                            loop = false;
                        }
                        else
                        {
                            aux = aux.Izq;
                        }
                    }
                }*/
                ingresar(raiz, d);
            }


        }

        public void ingresar(Nodo r, int dato)
        {

            if (r.Dato > dato)
            {
                if (r.Izq == null)
                {
                    crearNodo(dato);
                    r.Izq = nuevo;
                }
                else
                {
                    ingresar(r.Izq, dato);
                }

            }
            else
            {
                if (r.Der == null)
                {
                    crearNodo(dato);
                    r.Der = nuevo;
                }
                else
                {
                    ingresar(r.Der, dato);
                }

            }
        }
       

        public Nodo getRaiz()
        {
            return raiz;
        }
        public Nodo buscar(Nodo r, int num)
        {
            if (num == r.Dato)
            {

                return r;
            }
            if (r.Izq != null)
            {
                Nodo aux = buscar(r.Izq, num);
                if (aux != null) return aux;
            }
            if (r.Der != null)
            {
                Nodo aux = buscar(r.Der, num);
                if (aux != null) return aux;
            }
            return null;

        }
        public Nodo buscarAnt(Nodo r, int num, Nodo Ant)
        {
            if (num == r.Dato)
            {
                return Ant;
            }
            if (r.Izq != null)
            {
                Nodo aux = buscarAnt(r.Izq, num, r);
                if (aux != null) return aux;
            }
            if (r.Der != null)
            {
                Nodo aux = buscarAnt(r.Der, num, r);
                if (aux != null) return aux;
            }
            return null;

        }
        public void eliminar(int num)
        {
            Nodo act = buscar(getRaiz(), num);
            Nodo ant = buscarAnt(getRaiz(), num, null);
            if (act.Izq == null && act.Der == null)
            {
                eliminarHoja(act, ant);
            }
            else
            {
                if (act.Izq != null && act.Der != null)
                {
                    eliminar2Hijos(act,ant);
                    return;
                }
                
                if (act.Izq == null || act.Der == null)
                {
                    eliminarHijo(act,ant);
                }
                
            }
            
        }
        public void eliminarHoja(Nodo act,Nodo ant)
        {
            if (ant.Der == act)
            {
                ant.Der = null;
            }
            if (ant.Izq == act)
            {
                ant.Izq = null;
            }
        }
        public void eliminarHijo(Nodo act, Nodo ant)
        {
            if (ant.Der == act)
            {
                if (act.Izq != null)
                {
                    ant.Der = act.Izq;
                }
                else ant.Der = act.Der;
            }
            if (ant.Izq == act)
            {
                if (act.Izq != null)
                {
                    ant.Izq = act.Izq;
                }
                else ant.Izq = act.Der;
            }
            act.Izq = null;
            act.Der = null;
        }
        public Nodo buscarMenor(Nodo m)
        {
            if(m.Izq==null)
            {
                return m;
            }
            return buscarMenor(m.Izq);
        }
        public void eliminar2Hijos(Nodo act, Nodo ant)
        {
            Nodo aux = buscarMenor(act.Der);
            eliminar(aux.Dato);
            act.Dato = aux.Dato;

        }
        public string recorrido(int num)
        {
            Nodo r = raiz;
            string a = "   ";
            while(true)
            {
                if (num == r.Dato)
                {
                    a = a + r.Dato;
                    return a;
                }
                if (r.Dato > num)
                {
                    a=a +"   " +r.Dato;
                    r = r.Izq;
                }
                if (r.Dato < num)
                {
                    a = a +"   " + r.Dato;
                    r = r.Der;
                }

            }
        }
        public void nivelmax(Nodo r, int num,ref int a)
        {

            if (r.Izq != null)
            {
                nivelmax(r.Izq, num+1, ref a);
            }
            if (r.Der != null)
            {
                nivelmax(r.Der, num + 1,ref a);
            }
            if(num>a) a=num;
        }
        public int nivel(int num)
        {
            Nodo r = raiz;
            int cont=0;
            while (true)
            {
                if (num == r.Dato)
                {
                  
                    return cont;
                }
                if (r.Dato > num)
                {
                    
                    r = r.Izq;
                    cont++;
                }
                if (r.Dato < num)
                {
                   
                    r = r.Der;
                    cont++;
                }
                

            }
            return 123456;
        }
        public int altura(int num)
        {
            int nMax = 0;
            nivelmax(raiz, 0,ref nMax);
            MessageBox.Show("MAXIMO"+nMax);
            return nMax-nivel(num);
        }

    }
}
