﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolesBinarios
{
    class Dibujar
    {
        int px, py,tam;

    }//TODO TITULO EMPIEZA CON SISTEMA
}
