﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArbolesBinarios
{
    public partial class frm_main : Form
    {
        public frm_main()
        {

            InitializeComponent();

        }
        //raiz, izq, der
        private void mpreorden(Nodo r)
        {
            lst_pre.Items.Add(r.Dato);
            if (r.Izq!=null)
            {
                mpreorden(r.Izq);
            }
            if (r.Der != null)
            {
                mpreorden(r.Der);
            }
            
        }
        private Nodo buscarNum(Nodo r,int num)
        {
            if (num == r.Dato)
            {
                
                return r;
            }
            if (r.Izq != null)
            {
                Nodo aux= buscarNum(r.Izq,num);
                if (aux!=null) return aux;
            }
            if (r.Der != null)
            {
                Nodo aux = buscarNum(r.Der, num);
                if (aux != null) return aux;
            }
            return null;

        }
        private void mpostorden(Nodo r)
        {
            
            if (r.Izq != null)
            {
                mpostorden(r.Izq);
            }
            if (r.Der != null)
            {
                mpostorden(r.Der);
            }
            lst_post.Items.Add(r.Dato);
        }
        private void minorden(Nodo r)
        {

            
            if (r.Izq != null)
            {
                minorden(r.Izq);
            }
            lst_in.Items.Add(r.Dato);
            if (r.Der != null)
            {
                minorden(r.Der);
            }
        }
        private int hojas(Nodo r,int h)
        {
            if (r.Izq == null && r.Der == null) h++;

            if (r.Izq != null)
            {
                h=h+hojas(r.Izq,0);
            }
            if (r.Der != null)
            {
                h=h+hojas(r.Der,0);
            }
            return h;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txt_num_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            Estatica.a.crearArbol(int.Parse(txt_num.Text));
        }

        private void btn_pre_Click(object sender, EventArgs e)
        {
            lst_pre.Items.Clear();
            mpreorden(Estatica.a.getRaiz());
        }

        private void btn_in_Click(object sender, EventArgs e)
        {
            lst_in.Items.Clear();
            minorden(Estatica.a.getRaiz());
        }

        private void btn_post_Click(object sender, EventArgs e)
        {
            lst_post.Items.Clear();
            mpostorden(Estatica.a.getRaiz());
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            if (buscarNum(Estatica.a.getRaiz(), int.Parse(txt_num.Text)) != null)
            {
                MessageBox.Show("SE ENCONTRO");
                btn_eliminar.Visible = true;
            }
            
        }

        private void btn_graficar_Click(object sender, EventArgs e)
        {
            frm_grafico xd = new frm_grafico();
            this.Hide();

            xd.Show();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            int h = hojas(Estatica.a.getRaiz(),0);
            lbl_hojas.Text = "EL ARBOL TIENE "+h+" HOJAS";
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            lst_in.Items.Clear();
            lst_post.Items.Clear();
            lst_pre.Items.Clear();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            Estatica.a.eliminar(int.Parse(txt_num.Text));
            btn_eliminar.Visible = false;
        }
    }
}//PILAS COLAS Y LISTAS CIRCULARES
