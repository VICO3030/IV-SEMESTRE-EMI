﻿namespace ArbolesBinarios
{
    partial class frm_main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lbl_num = new System.Windows.Forms.Label();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_graficar = new System.Windows.Forms.Button();
            this.btn_pre = new System.Windows.Forms.Button();
            this.btn_in = new System.Windows.Forms.Button();
            this.btn_post = new System.Windows.Forms.Button();
            this.lst_pre = new System.Windows.Forms.ListBox();
            this.lst_in = new System.Windows.Forms.ListBox();
            this.lst_post = new System.Windows.Forms.ListBox();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.lbl_hojas = new System.Windows.Forms.Label();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(469, 30);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(389, 43);
            this.lbl_titulo.TabIndex = 12;
            this.lbl_titulo.Text = "ARBOLES BINARIOS";
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(291, 137);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(196, 30);
            this.txt_num.TabIndex = 14;
            this.txt_num.TextChanged += new System.EventHandler(this.txt_num_TextChanged);
            // 
            // lbl_num
            // 
            this.lbl_num.AutoSize = true;
            this.lbl_num.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(12, 141);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(246, 26);
            this.lbl_num.TabIndex = 13;
            this.lbl_num.Text = "INGRESE UN NUMERO";
            // 
            // btn_insertar
            // 
            this.btn_insertar.BackColor = System.Drawing.Color.Peru;
            this.btn_insertar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insertar.Location = new System.Drawing.Point(530, 128);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(144, 54);
            this.btn_insertar.TabIndex = 20;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = false;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.Peru;
            this.btn_buscar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Location = new System.Drawing.Point(728, 128);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(144, 54);
            this.btn_buscar.TabIndex = 21;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_graficar
            // 
            this.btn_graficar.BackColor = System.Drawing.Color.Peru;
            this.btn_graficar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_graficar.Location = new System.Drawing.Point(921, 128);
            this.btn_graficar.Name = "btn_graficar";
            this.btn_graficar.Size = new System.Drawing.Size(144, 54);
            this.btn_graficar.TabIndex = 22;
            this.btn_graficar.Text = "GRAFICAR";
            this.btn_graficar.UseVisualStyleBackColor = false;
            this.btn_graficar.Click += new System.EventHandler(this.btn_graficar_Click);
            // 
            // btn_pre
            // 
            this.btn_pre.BackColor = System.Drawing.Color.Peru;
            this.btn_pre.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pre.Location = new System.Drawing.Point(240, 249);
            this.btn_pre.Name = "btn_pre";
            this.btn_pre.Size = new System.Drawing.Size(144, 54);
            this.btn_pre.TabIndex = 23;
            this.btn_pre.Text = "PreOrden";
            this.btn_pre.UseVisualStyleBackColor = false;
            this.btn_pre.Click += new System.EventHandler(this.btn_pre_Click);
            // 
            // btn_in
            // 
            this.btn_in.BackColor = System.Drawing.Color.Peru;
            this.btn_in.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_in.Location = new System.Drawing.Point(546, 249);
            this.btn_in.Name = "btn_in";
            this.btn_in.Size = new System.Drawing.Size(144, 54);
            this.btn_in.TabIndex = 24;
            this.btn_in.Text = "InOrden";
            this.btn_in.UseVisualStyleBackColor = false;
            this.btn_in.Click += new System.EventHandler(this.btn_in_Click);
            // 
            // btn_post
            // 
            this.btn_post.BackColor = System.Drawing.Color.Peru;
            this.btn_post.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_post.Location = new System.Drawing.Point(882, 249);
            this.btn_post.Name = "btn_post";
            this.btn_post.Size = new System.Drawing.Size(144, 54);
            this.btn_post.TabIndex = 25;
            this.btn_post.Text = "PostOrden";
            this.btn_post.UseVisualStyleBackColor = false;
            this.btn_post.Click += new System.EventHandler(this.btn_post_Click);
            // 
            // lst_pre
            // 
            this.lst_pre.FormattingEnabled = true;
            this.lst_pre.ItemHeight = 16;
            this.lst_pre.Location = new System.Drawing.Point(199, 309);
            this.lst_pre.Name = "lst_pre";
            this.lst_pre.Size = new System.Drawing.Size(232, 148);
            this.lst_pre.TabIndex = 26;
            // 
            // lst_in
            // 
            this.lst_in.FormattingEnabled = true;
            this.lst_in.ItemHeight = 16;
            this.lst_in.Location = new System.Drawing.Point(502, 309);
            this.lst_in.Name = "lst_in";
            this.lst_in.Size = new System.Drawing.Size(232, 148);
            this.lst_in.TabIndex = 27;
            // 
            // lst_post
            // 
            this.lst_post.FormattingEnabled = true;
            this.lst_post.ItemHeight = 16;
            this.lst_post.Location = new System.Drawing.Point(833, 309);
            this.lst_post.Name = "lst_post";
            this.lst_post.Size = new System.Drawing.Size(232, 148);
            this.lst_post.TabIndex = 28;
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.BackColor = System.Drawing.Color.Peru;
            this.btn_limpiar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiar.Location = new System.Drawing.Point(546, 500);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(144, 54);
            this.btn_limpiar.TabIndex = 29;
            this.btn_limpiar.Text = "LIMPIAR";
            this.btn_limpiar.UseVisualStyleBackColor = false;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // lbl_hojas
            // 
            this.lbl_hojas.AutoSize = true;
            this.lbl_hojas.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hojas.Location = new System.Drawing.Point(32, 514);
            this.lbl_hojas.Name = "lbl_hojas";
            this.lbl_hojas.Size = new System.Drawing.Size(292, 26);
            this.lbl_hojas.TabIndex = 30;
            this.lbl_hojas.Text = "EL ARBOL TIENE 0 HOJAS";
            this.lbl_hojas.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackColor = System.Drawing.Color.Peru;
            this.btn_eliminar.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.Location = new System.Drawing.Point(728, 188);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(144, 54);
            this.btn_eliminar.TabIndex = 31;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = false;
            this.btn_eliminar.Visible = false;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(1229, 589);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lbl_hojas);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.lst_post);
            this.Controls.Add(this.lst_in);
            this.Controls.Add(this.lst_pre);
            this.Controls.Add(this.btn_post);
            this.Controls.Add(this.btn_in);
            this.Controls.Add(this.btn_pre);
            this.Controls.Add(this.btn_graficar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.lbl_titulo);
            this.Name = "frm_main";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_graficar;
        private System.Windows.Forms.Button btn_pre;
        private System.Windows.Forms.Button btn_in;
        private System.Windows.Forms.Button btn_post;
        private System.Windows.Forms.ListBox lst_pre;
        private System.Windows.Forms.ListBox lst_in;
        private System.Windows.Forms.ListBox lst_post;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Label lbl_hojas;
        private System.Windows.Forms.Button btn_eliminar;
    }
}

