﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolesBinarios
{
    class Nodo
    {
        int dato;
        Nodo izq;
        Nodo der;

        public Nodo()
        {
            dato = 0;
            izq = null;
            der = null;
        }

        public int Dato { get => dato; set => dato = value; }
        public Nodo Izq { get => izq; set => izq = value; }
        public Nodo Der { get => der; set => der = value; }
    }
}
