﻿namespace EJERCICIO2OP
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Unir = new System.Windows.Forms.Button();
            this.btn_registrar2 = new System.Windows.Forms.Button();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.lst_lista3 = new System.Windows.Forms.ListBox();
            this.lst_lista2 = new System.Windows.Forms.ListBox();
            this.txt_l2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lst_lista = new System.Windows.Forms.ListBox();
            this.txt_l1 = new System.Windows.Forms.TextBox();
            this.lbl_texto = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Unir
            // 
            this.btn_Unir.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_Unir.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Unir.Location = new System.Drawing.Point(585, 366);
            this.btn_Unir.Name = "btn_Unir";
            this.btn_Unir.Size = new System.Drawing.Size(131, 46);
            this.btn_Unir.TabIndex = 36;
            this.btn_Unir.Text = "UNIR";
            this.btn_Unir.UseVisualStyleBackColor = false;
            this.btn_Unir.Click += new System.EventHandler(this.btn_Unir_Click);
            // 
            // btn_registrar2
            // 
            this.btn_registrar2.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_registrar2.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar2.Location = new System.Drawing.Point(301, 265);
            this.btn_registrar2.Name = "btn_registrar2";
            this.btn_registrar2.Size = new System.Drawing.Size(131, 46);
            this.btn_registrar2.TabIndex = 35;
            this.btn_registrar2.Text = "REGISTRAR";
            this.btn_registrar2.UseVisualStyleBackColor = false;
            this.btn_registrar2.Click += new System.EventHandler(this.btn_registrar2_Click);
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_registrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(55, 265);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(131, 46);
            this.btn_registrar.TabIndex = 34;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // lst_lista3
            // 
            this.lst_lista3.FormattingEnabled = true;
            this.lst_lista3.ItemHeight = 16;
            this.lst_lista3.Location = new System.Drawing.Point(570, 53);
            this.lst_lista3.Name = "lst_lista3";
            this.lst_lista3.Size = new System.Drawing.Size(195, 292);
            this.lst_lista3.TabIndex = 33;
            // 
            // lst_lista2
            // 
            this.lst_lista2.FormattingEnabled = true;
            this.lst_lista2.ItemHeight = 16;
            this.lst_lista2.Location = new System.Drawing.Point(265, 97);
            this.lst_lista2.Name = "lst_lista2";
            this.lst_lista2.Size = new System.Drawing.Size(186, 148);
            this.lst_lista2.TabIndex = 32;
            // 
            // txt_l2
            // 
            this.txt_l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_l2.Location = new System.Drawing.Point(353, 38);
            this.txt_l2.Name = "txt_l2";
            this.txt_l2.Size = new System.Drawing.Size(59, 28);
            this.txt_l2.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 22);
            this.label1.TabIndex = 30;
            this.label1.Text = "TEXTO";
            // 
            // lst_lista
            // 
            this.lst_lista.FormattingEnabled = true;
            this.lst_lista.ItemHeight = 16;
            this.lst_lista.Location = new System.Drawing.Point(39, 97);
            this.lst_lista.Name = "lst_lista";
            this.lst_lista.Size = new System.Drawing.Size(162, 148);
            this.lst_lista.TabIndex = 29;
            // 
            // txt_l1
            // 
            this.txt_l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_l1.Location = new System.Drawing.Point(127, 38);
            this.txt_l1.Name = "txt_l1";
            this.txt_l1.Size = new System.Drawing.Size(59, 28);
            this.txt_l1.TabIndex = 28;
            // 
            // lbl_texto
            // 
            this.lbl_texto.AutoSize = true;
            this.lbl_texto.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_texto.Location = new System.Drawing.Point(35, 39);
            this.lbl_texto.Name = "lbl_texto";
            this.lbl_texto.Size = new System.Drawing.Size(72, 22);
            this.lbl_texto.TabIndex = 27;
            this.lbl_texto.Text = "TEXTO";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMin.Location = new System.Drawing.Point(114, 366);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(72, 22);
            this.lblMin.TabIndex = 37;
            this.lblMin.Text = "TEXTO";
            this.lblMin.Click += new System.EventHandler(this.lblMin_Click);
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMax.Location = new System.Drawing.Point(114, 402);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(72, 22);
            this.lblMax.TabIndex = 38;
            this.lblMax.Text = "TEXTO";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.btn_Unir);
            this.Controls.Add(this.btn_registrar2);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.lst_lista3);
            this.Controls.Add(this.lst_lista2);
            this.Controls.Add(this.txt_l2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lst_lista);
            this.Controls.Add(this.txt_l1);
            this.Controls.Add(this.lbl_texto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Unir;
        private System.Windows.Forms.Button btn_registrar2;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.ListBox lst_lista3;
        private System.Windows.Forms.ListBox lst_lista2;
        private System.Windows.Forms.TextBox txt_l2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lst_lista;
        private System.Windows.Forms.TextBox txt_l1;
        private System.Windows.Forms.Label lbl_texto;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblMax;
    }
}

