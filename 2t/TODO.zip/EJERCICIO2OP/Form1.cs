﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EJERCICIO2OP
{
    public partial class Form1 : Form
    {
        Pila pA,pB,aux;
        Cola c;
        public Form1()
        {
            pA=new Pila();
            pB=new Pila();
            aux=new Pila();
            c=new Cola();
            InitializeComponent();
        }

        private void btn_registrar2_Click(object sender, EventArgs e)
        {
            pB.apilar(int.Parse(txt_l2.Text));
            mostrarB();
        }

        private void btn_Unir_Click(object sender, EventArgs e)
        {
            while (pB.estaVacio()!=true || pA.estaVacio()!=true)
            {
                Nodo n=null;

                if (!pA.estaVacio())
                {
                    n= pA.desapilar();
                    if (!c.buscar(n.Num))
                    {
                        c.encolar(n.Num);
                    }

                }
                if (!pB.estaVacio())
                {
                     n = pB.desapilar();
                    if (!c.buscar(n.Num))
                    {
                        c.encolar(n.Num);
                    }
                }
                
            }
            mostrarC();
            mostrarB();
            mostrarA();
            lblMax.Text = "EL MAYOR ES" + c.max()+" ";
            lblMin.Text = "EL MENOR ES" + c.min() + " ";
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            pA.apilar(int.Parse(txt_l1.Text));
            mostrarA();
        }
        private void mostrarA()
        {
            Nodo punt;
            lst_lista.Items.Clear();
            while (pA.getTope() != null)
            {
                punt = pA.desapilar();
                lst_lista.Items.Add(punt.Num);
                aux.apilar(punt.Num);
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                pA.apilar(punt.Num);
            }
        }

        private void lblMin_Click(object sender, EventArgs e)
        {

        }

        private void mostrarB()
        {
            Nodo punt;
            lst_lista2.Items.Clear();
            while (pB.getTope() != null)
            {
                punt = pB.desapilar();
                lst_lista2.Items.Add(punt.Num);
                aux.apilar(punt.Num);
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                pB.apilar(punt.Num);
            }

        }
        private void mostrarC()
        {
            Nodo au = c.getFrente();
            lst_lista3.Items.Clear();
            while (au != null)
            {
                lst_lista3.Items.Add(au.Num);
                au = au.Enlace;
            }
        }

    }
}
