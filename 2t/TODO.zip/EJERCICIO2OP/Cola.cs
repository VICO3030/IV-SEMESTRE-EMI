﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJERCICIO2OP
{
    class Cola
    { 
    Nodo frente, final, nuevo;
    public Cola()
    {
        frente = null;
        nuevo = null;
        final = null;
    }
    public void crearNodo(int n)
    {
        nuevo = new Nodo();
        nuevo.Num = n;
        nuevo.Enlace = null;

    }
    public string encolar(int n)
    {
        crearNodo(n);
        if (frente == null)
        {

            frente = nuevo;
            final = nuevo;
        }
        else
        {
            final.Enlace = nuevo;
            final = nuevo;
        }

        return ("SE ENCOLO CON EXITO");
    }
    public Nodo desencolar()
    {
        Nodo aux = frente;
        frente = frente.Enlace;
        aux.Enlace = null;
        if (frente == null)
        {
            final = null;
        }
        return (aux);
    }
    public Nodo getFrente()
    {
        return frente;
    }
    public Nodo getFinal()
    {
        return final;
    }
    public bool estaVacio()
    {
        return frente == null;//si esta vacio devuelve verdadero
    }
    public bool buscar(int n)
    {
        Nodo punt = getFrente();
        while (punt != null)
        {
            if (punt.Num == n)
            {
                return true;
            }
            punt = punt.Enlace;
        }
        return false;
    }
    public int max()
    {
        Nodo punt = getFrente();
            int m=0;
        while (punt != null)
        {
            if (punt.Num >m)
            {
                m = punt.Num;
            }
            punt = punt.Enlace;
        }
        return m;
    }
        public int min()
        {
            Nodo punt = getFrente();
            int m = 1000;
            while (punt != null)
            {
                if (punt.Num < m)
                {
                    m = punt.Num;
                }
                punt = punt.Enlace;
            }
            return m;
        }
        public string eliminar(int n)
    {
        Nodo actual = frente;
        Nodo anterior = null;
        while (actual != null)
        {
            if (frente.Num == n)
            {
                desencolar();
                return ("SE ELIMINO A " + actual.Num);
            }
            else
            {
                if (actual.Num == n)
                {
                    anterior.Enlace = actual.Enlace;
                    actual.Enlace = null;
                    return ("SE ELIMINO A " + actual.Num);
                }
                anterior = actual;
                actual = actual.Enlace;
            }
        }
        return "NO EXISTE";
    }
}
}
