﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PILA
{
    public partial class frm_main : Form
    {
        PILA aux, p;
        public frm_main()
        {
            aux = new PILA();
            p = new PILA();
            InitializeComponent();
        }
        public void eliminar()
        {
            NodoPila punt = p.getTope();
            int n = int.Parse(txt_numero.Text);
            if(punt.getNum()==n)
            {
                punt = p.desapilar();
                aux.apilar(punt.getNum());
            }
            while (p.getTope() != null && punt.getNum() != n)
            {

                punt = p.desapilar();
                aux.apilar(punt.getNum());

            }
            if (punt.getNum()!=n)
            {

                MessageBox.Show("NO SE ENCONTRO EL NUMERO");
            }
            else
            {
                MessageBox.Show("SE ELIMINO EL NUMERO  "+punt.getNum());
                punt = aux.desapilar();
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                p.apilar(punt.getNum());
            }
        }
        public void buscar()
        {
            NodoPila punt = p.getTope();
            int n = int.Parse(txt_numero.Text);
            while (p.getTope() != null && punt.getNum() != n)
            {

                punt = p.desapilar();
                aux.apilar(punt.getNum());

            }
            if (punt.getNum() != n)
            {
                MessageBox.Show("NO SE ENCONTRO EL NUMERO");
            }
            else
            {
                MessageBox.Show("SE ENCONTRO EL NUMERO " + n);
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                p.apilar(punt.getNum());
            }
        }
        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            NodoPila punt;
            lst_pilas.Items.Clear();
            while (p.getTope()!= null)
            {
                punt=p.desapilar();
                lst_pilas.Items.Add(punt.getNum());
                aux.apilar(punt.getNum());
            }
            while (aux.getTope() != null)
            {
           
                punt = aux.desapilar();
                p.apilar(punt.getNum());
            }
        }

        private void frm_main_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (p.estaVacio())
            {
                MessageBox.Show ("ESTA VACIO");
            }
            else
            {
                MessageBox.Show("NO ESTA VACIO");
            }
            
        }

        private void btn_desapilar_Click(object sender, EventArgs e)
        {
            if (p.getTope() == null) MessageBox.Show("NO HAY DATOS EN LA COLA");
            else MessageBox.Show("SE DESAPILO EL NUMERO: " + p.desapilar().getNum());

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            if (p.getTope() == null) MessageBox.Show("NO HAY DATOS EN LA COLA");
            else buscar();
        }

        private void brn_eliminar_Click(object sender, EventArgs e)
        {
            if (p.getTope() == null) MessageBox.Show("NO HAY DATOS EN LA COLA");
            else eliminar();
            
        }

        private void txt_numero_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_numero_Click(object sender, EventArgs e)
        {

        }

        private void lbl_titulo_Click(object sender, EventArgs e)
        {

        }

        private void lst_pilas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(p.apilar(int.Parse(txt_numero.Text)));
        }
    }
}
