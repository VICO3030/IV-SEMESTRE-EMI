﻿namespace PILA
{
    partial class frm_main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_registrar = new System.Windows.Forms.Button();
            this.txt_numero = new System.Windows.Forms.TextBox();
            this.lbl_numero = new System.Windows.Forms.Label();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.lst_pilas = new System.Windows.Forms.ListBox();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.brn_eliminar = new System.Windows.Forms.Button();
            this.btn_desapilar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_registrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(419, 100);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(131, 46);
            this.btn_registrar.TabIndex = 17;
            this.btn_registrar.Text = "APILAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // txt_numero
            // 
            this.txt_numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numero.Location = new System.Drawing.Point(277, 109);
            this.txt_numero.Name = "txt_numero";
            this.txt_numero.Size = new System.Drawing.Size(113, 28);
            this.txt_numero.TabIndex = 16;
            this.txt_numero.TextChanged += new System.EventHandler(this.txt_numero_TextChanged);
            // 
            // lbl_numero
            // 
            this.lbl_numero.AutoSize = true;
            this.lbl_numero.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numero.Location = new System.Drawing.Point(42, 109);
            this.lbl_numero.Name = "lbl_numero";
            this.lbl_numero.Size = new System.Drawing.Size(214, 22);
            this.lbl_numero.TabIndex = 15;
            this.lbl_numero.Text = "INGRESE EL NUMERO:";
            this.lbl_numero.Click += new System.EventHandler(this.lbl_numero_Click);
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_mostrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrar.Location = new System.Drawing.Point(259, 360);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(131, 46);
            this.btn_mostrar.TabIndex = 19;
            this.btn_mostrar.Text = "MOSTRAR";
            this.btn_mostrar.UseVisualStyleBackColor = false;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // lst_pilas
            // 
            this.lst_pilas.FormattingEnabled = true;
            this.lst_pilas.ItemHeight = 16;
            this.lst_pilas.Location = new System.Drawing.Point(128, 184);
            this.lst_pilas.Name = "lst_pilas";
            this.lst_pilas.Size = new System.Drawing.Size(358, 148);
            this.lst_pilas.TabIndex = 18;
            this.lst_pilas.SelectedIndexChanged += new System.EventHandler(this.lst_pilas_SelectedIndexChanged);
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(316, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(131, 51);
            this.lbl_titulo.TabIndex = 20;
            this.lbl_titulo.Text = "PILAS";
            this.lbl_titulo.Click += new System.EventHandler(this.lbl_titulo_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CadetBlue;
            this.button1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(626, 150);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 46);
            this.button1.TabIndex = 21;
            this.button1.Text = "ESTA VACIA";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_buscar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Location = new System.Drawing.Point(626, 220);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(131, 46);
            this.btn_buscar.TabIndex = 22;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // brn_eliminar
            // 
            this.brn_eliminar.BackColor = System.Drawing.Color.CadetBlue;
            this.brn_eliminar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brn_eliminar.Location = new System.Drawing.Point(626, 296);
            this.brn_eliminar.Name = "brn_eliminar";
            this.brn_eliminar.Size = new System.Drawing.Size(131, 46);
            this.brn_eliminar.TabIndex = 23;
            this.brn_eliminar.Text = "ELIMINAR";
            this.brn_eliminar.UseVisualStyleBackColor = false;
            this.brn_eliminar.Click += new System.EventHandler(this.brn_eliminar_Click);
            // 
            // btn_desapilar
            // 
            this.btn_desapilar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_desapilar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_desapilar.Location = new System.Drawing.Point(626, 85);
            this.btn_desapilar.Name = "btn_desapilar";
            this.btn_desapilar.Size = new System.Drawing.Size(131, 46);
            this.btn_desapilar.TabIndex = 24;
            this.btn_desapilar.Text = "DESAPILAR";
            this.btn_desapilar.UseVisualStyleBackColor = false;
            this.btn_desapilar.Click += new System.EventHandler(this.btn_desapilar_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_desapilar);
            this.Controls.Add(this.brn_eliminar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.lst_pilas);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.txt_numero);
            this.Controls.Add(this.lbl_numero);
            this.Name = "frm_main";
            this.Text = "PILAS";
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.TextBox txt_numero;
        private System.Windows.Forms.Label lbl_numero;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.ListBox lst_pilas;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button brn_eliminar;
        private System.Windows.Forms.Button btn_desapilar;
    }
}

