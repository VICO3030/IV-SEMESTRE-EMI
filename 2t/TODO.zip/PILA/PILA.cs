﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PILA
{
    class PILA
    {
        NodoPila nuevo, tope;
        public PILA()
        {
            tope = null;
            nuevo = null;
        }
        public void crearNodo(int n)
        {
            nuevo=new NodoPila();
            nuevo.setNum(n);
            nuevo.setEnlace(null);
           
        }
        public string apilar(int n)
        {
            crearNodo(n);
            nuevo.setEnlace(tope);
            tope = nuevo;
            return ("SE APILA CON EXITO");
        }
        public NodoPila desapilar()
        {
            NodoPila aux=tope;
            tope=tope.getEnlace();
            aux.setEnlace(null);
            return (aux);
        }
        public NodoPila getTope()
        {
            return tope;
        }
        public bool estaVacio()
        {
            return tope == null;//si esta vacio devuelve verdadero
        }
    }
}
