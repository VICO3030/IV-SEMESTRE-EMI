﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PILA
{
    class NodoPila
    {
        int num;
        NodoPila enlace;//Direccion del nodo con el que se enlasa
        public NodoPila()
        {
            num = 0;
            enlace = null;
        }

        public void setNum(int n)
        {
            this.num = n;
        }
        public void setEnlace(NodoPila punt)
        {
            enlace = punt;
        }

        public int getNum()
        {
            return num;
        }
        public NodoPila getEnlace()
        {
            return enlace;
        }
    }
}
