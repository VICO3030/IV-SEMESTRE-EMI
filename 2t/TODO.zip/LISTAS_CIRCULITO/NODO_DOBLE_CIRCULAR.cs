﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_CIRCULITO
{
    class NODO_DOBLE_CIRCULAR
    {
        int num;
        NODO_DOBLE_CIRCULAR sig;//Direccion del nodo con el que se enlasa
        NODO_DOBLE_CIRCULAR ant;
        public NODO_DOBLE_CIRCULAR()
        {
            num = 0;
            sig = null;
            ant = null;
        }
        public void setNum(int n)
        {
            this.num = n;
        }
        public void setSig(NODO_DOBLE_CIRCULAR punt)
        {
            sig = punt;
        }

        public int getNum()
        {
            return num;
        }
        public NODO_DOBLE_CIRCULAR getSig()
        {
            return sig;
        }
        public void setAnt(NODO_DOBLE_CIRCULAR punt)
        {
            ant = punt;
        }
        public NODO_DOBLE_CIRCULAR getAnt()
        {
            return ant;
        }
    }
}
