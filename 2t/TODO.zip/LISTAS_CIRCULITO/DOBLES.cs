﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_CIRCULITO
{
    public partial class DOBLES : Form
    {
        LISTA_DOBLE_CIRCULAR ld=new LISTA_DOBLE_CIRCULAR();
        public DOBLES()
        {
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            ld.crearLista(int.Parse(txt_num.Text));
            MessageBox.Show("SE REGISTRO CON EXITO");

        }
    }
}
