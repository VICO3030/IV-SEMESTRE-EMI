﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_CIRCULITO
{
    class LISTA_DOBLE_CIRCULAR
    {
        NODO_DOBLE_CIRCULAR cabeza, nuevo, ultimo;
        public LISTA_DOBLE_CIRCULAR()
        {
            cabeza = null;
            nuevo = null;
        }
        public NODO_DOBLE_CIRCULAR getCabeza()
        {
            return cabeza;
        }
        public NODO_DOBLE_CIRCULAR getUltimo()
        {
            return ultimo;
        }
        public void crearNodo(int n)
        {
            nuevo = new NODO_DOBLE_CIRCULAR();
            nuevo.setNum(n);
            nuevo.setSig(null);
            nuevo.setAnt(null);
        }
        public void crearLista(int n)
        {
            NODO_DOBLE_CIRCULAR punt;
            crearNodo(n);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                ultimo.setSig(nuevo);
                nuevo.setAnt(ultimo);
            }
            ultimo = nuevo;
            ultimo.setSig(cabeza);
            cabeza.setAnt(ultimo);

        }
        public string eliminar(int n)
        {
            NODO_DOBLE_CIRCULAR actual = cabeza;
            NODO_DOBLE_CIRCULAR anterior = ultimo;
            do
            {
                if (cabeza.getNum() == n)
                {
                    if (cabeza == ultimo)
                    {
                        cabeza = null;
                        ultimo = null;
                        return ("SE ELIMINO A " + actual.getNum());
                    }
                    anterior.setSig(cabeza.getSig());
                    cabeza = cabeza.getSig();
                    actual.setSig(null);
                    return ("SE ELIMINO A " + actual.getNum());
                }
                else
                {
                    if (actual.getNum() == n)
                    {
                        anterior.setSig(actual.getSig());
                        actual.setSig(null);
                        return ("SE ELIMINO A " + actual.getSig());
                    }
                    anterior = actual;
                    actual = actual.getSig();
                }
            } while (actual != cabeza);
            return "NO EXISTE";
        }
    }
}

