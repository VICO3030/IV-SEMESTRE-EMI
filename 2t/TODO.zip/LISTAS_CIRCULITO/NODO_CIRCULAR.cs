﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_CIRCULITO
{
    class NODO_CIRCULAR
    {
        int num;
        NODO_CIRCULAR sig;//Direccion del nodo con el que se enlasa
        public NODO_CIRCULAR()
        {
            num = 0;
            sig = null;
        }
        public void setNum(int n)
        {
            this.num = n;
        }
        public void setSig(NODO_CIRCULAR punt)
        {
            sig = punt;
        }
        
        public int getNum()
        {
            return num;
        }
        public NODO_CIRCULAR getSig()
        {
            return sig;
        }
    }
}
