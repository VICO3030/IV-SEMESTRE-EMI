﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_CIRCULITO
{
    public partial class frm_main : Form
    {
        LISTA_CIRCULAR l = new LISTA_CIRCULAR();

        public frm_main()
        {
            InitializeComponent();
        }

        private void txt_num_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            l.crearLista(int.Parse(txt_num.Text));
            MessageBox.Show("SE REGISTRO CON EXISTO");
        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            NODO_CIRCULAR punt = l.getCabeza();
            do
            {
                if(punt == null)
                {
                    return;
                }
                lst_lista.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
            while (punt != l.getCabeza()) ;
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(l.eliminar(int.Parse(txt_num.Text)));
        }

        private void frm_main_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            l.ordenar();
            l.insertar(int.Parse(txt_num.Text));
            MessageBox.Show("SE INSERTO CON EXITO"); 
        }

        private void btn_ordenar_Click(object sender, EventArgs e)
        {
            lst_lista.Items.Clear();
            NODO_CIRCULAR punt = l.getCabeza();
            l.ordenar();
            do
            {
                if (punt == null)
                {
                    return;
                }
                lst_lista.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
            while (punt != l.getCabeza());
        }
    }
}
