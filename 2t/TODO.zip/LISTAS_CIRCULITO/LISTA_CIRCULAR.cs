﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_CIRCULITO
{
    class LISTA_CIRCULAR
    {

        NODO_CIRCULAR cabeza, nuevo, ultimo;
        public LISTA_CIRCULAR()
        {
            cabeza = null;
            nuevo = null;
        }
        public NODO_CIRCULAR getCabeza()
        {
            return cabeza;
        }
        public NODO_CIRCULAR getUltimo()
        {
            return ultimo;
        }
        public void crearNodo(int n)
        {
            nuevo=new NODO_CIRCULAR();
            nuevo.setNum(n);
            nuevo.setSig(null);
        }
        public void crearLista( int n)
        {
            NODO_CIRCULAR punt;
            crearNodo(n);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                ultimo.setSig(nuevo);
            }
            ultimo = nuevo;
            ultimo.setSig(cabeza);

        }
        public string eliminar(int n)
        {
            NODO_CIRCULAR actual = cabeza;
            NODO_CIRCULAR anterior = ultimo;
            do
            {
                if (cabeza.getNum() == n)
                {
                    if(cabeza==ultimo)
                    {
                        cabeza = null;
                        ultimo = null;
                        return ("SE ELIMINO A " + actual.getNum());
                    }
                    anterior.setSig(cabeza.getSig());
                    cabeza = cabeza.getSig();
                    actual.setSig(null);
                    return ("SE ELIMINO A " + actual.getNum());
                }
                else
                {
                    if (actual.getNum() == n)
                    {
                        anterior.setSig(actual.getSig());
                        actual.setSig(null);
                        return ("SE ELIMINO A " + actual.getSig());
                    }
                    anterior = actual;
                    actual = actual.getSig();
                }
            } while (actual != cabeza);
            return "NO EXISTE";
        }
        public void ordenar()
        {
            int aux;
            NODO_CIRCULAR punt = cabeza;
            do
            {
                NODO_CIRCULAR punt2 = punt.getSig();
                while (punt2 != cabeza) 
                {
                    if (punt2.getNum() < punt.getNum())
                    {
                        aux = punt.getNum();
                        punt.setNum(punt2.getNum());
                        punt2.setNum(aux);
                    }
                    punt2 = punt2.getSig();
                } 
                punt = punt.getSig();
            } while (punt != cabeza);
        }
        public void insertar(int n)
        {
            NODO_CIRCULAR actual = cabeza;
            NODO_CIRCULAR anterior = ultimo;
            crearNodo(n);
            if (cabeza.getNum() > nuevo.getNum())
            {
                nuevo.setSig(cabeza);
                cabeza = nuevo;
                ultimo.setSig(cabeza);
                
            }
          
            else if(ultimo.getNum() < nuevo.getNum())
            {
                ultimo.setSig(nuevo);
                ultimo = nuevo;
                ultimo.setSig(cabeza);
            }
            else
            {
                while (actual.getNum()<nuevo.getNum())
                {
                    anterior = actual;
                    actual = actual.getSig();
                    
                }
                anterior.setSig(nuevo);
                nuevo.setSig(actual);
            }
            
        }
    }
}
