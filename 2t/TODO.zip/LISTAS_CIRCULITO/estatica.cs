﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_CIRCULITO
{
    class estatica
    {
        public static LISTA_CIRCULAR l=new LISTA_CIRCULAR();
    }
}
