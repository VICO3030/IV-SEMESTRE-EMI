﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COLA
{
    public partial class frm_main : Form
    {
        Cola c,aux;
        public frm_main()
        {
            c= new Cola();
            aux= new Cola();
            InitializeComponent();
        }
        private void mostrar()
        {
            NodoCola punt=c.getFrente();
            lst_colas.Items.Clear();
            while (punt != null)
            {
                
                lst_colas.Items.Add(punt.getNum());
                punt = punt.getSig();
            }
        }
        

        private void btn_encolar_Click(object sender, EventArgs e)
        {
            c.encolar(int.Parse(txt_numero.Text));
            MessageBox.Show("Se encolo con EXITO");
        }

        private void frm_main_Load(object sender, EventArgs e)
        {

        }

        private void btn_desencolar_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Se desencolo con EXITO el numero"+ c.desencolar().getNum());
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(c.buscar(int.Parse(txt_numero.Text)));
            
        }

        private void brn_eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(c.eliminar(int.Parse(txt_numero.Text)));
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            mostrar();
        }
    }
}
