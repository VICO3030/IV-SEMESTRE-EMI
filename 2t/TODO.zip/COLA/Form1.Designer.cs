﻿namespace COLA
{
    partial class frm_main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_desencolar = new System.Windows.Forms.Button();
            this.brn_eliminar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.lst_colas = new System.Windows.Forms.ListBox();
            this.btn_encolar = new System.Windows.Forms.Button();
            this.txt_numero = new System.Windows.Forms.TextBox();
            this.lbl_numero = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_desencolar
            // 
            this.btn_desencolar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_desencolar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_desencolar.Location = new System.Drawing.Point(627, 103);
            this.btn_desencolar.Name = "btn_desencolar";
            this.btn_desencolar.Size = new System.Drawing.Size(131, 46);
            this.btn_desencolar.TabIndex = 34;
            this.btn_desencolar.Text = "DESENCOLAR";
            this.btn_desencolar.UseVisualStyleBackColor = false;
            this.btn_desencolar.Click += new System.EventHandler(this.btn_desencolar_Click);
            // 
            // brn_eliminar
            // 
            this.brn_eliminar.BackColor = System.Drawing.Color.CadetBlue;
            this.brn_eliminar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brn_eliminar.Location = new System.Drawing.Point(627, 314);
            this.brn_eliminar.Name = "brn_eliminar";
            this.brn_eliminar.Size = new System.Drawing.Size(131, 46);
            this.brn_eliminar.TabIndex = 33;
            this.brn_eliminar.Text = "ELIMINAR";
            this.brn_eliminar.UseVisualStyleBackColor = false;
            this.brn_eliminar.Click += new System.EventHandler(this.brn_eliminar_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_buscar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Location = new System.Drawing.Point(627, 238);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(131, 46);
            this.btn_buscar.TabIndex = 32;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CadetBlue;
            this.button1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(627, 168);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 46);
            this.button1.TabIndex = 31;
            this.button1.Text = "ESTA VACIA";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(317, 27);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(159, 51);
            this.lbl_titulo.TabIndex = 30;
            this.lbl_titulo.Text = "COLAS";
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_mostrar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrar.Location = new System.Drawing.Point(260, 378);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(131, 46);
            this.btn_mostrar.TabIndex = 29;
            this.btn_mostrar.Text = "MOSTRAR";
            this.btn_mostrar.UseVisualStyleBackColor = false;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // lst_colas
            // 
            this.lst_colas.FormattingEnabled = true;
            this.lst_colas.ItemHeight = 16;
            this.lst_colas.Location = new System.Drawing.Point(129, 202);
            this.lst_colas.Name = "lst_colas";
            this.lst_colas.Size = new System.Drawing.Size(358, 148);
            this.lst_colas.TabIndex = 28;
            // 
            // btn_encolar
            // 
            this.btn_encolar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_encolar.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_encolar.Location = new System.Drawing.Point(420, 118);
            this.btn_encolar.Name = "btn_encolar";
            this.btn_encolar.Size = new System.Drawing.Size(131, 46);
            this.btn_encolar.TabIndex = 27;
            this.btn_encolar.Text = "ENCOLAR";
            this.btn_encolar.UseVisualStyleBackColor = false;
            this.btn_encolar.Click += new System.EventHandler(this.btn_encolar_Click);
            // 
            // txt_numero
            // 
            this.txt_numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numero.Location = new System.Drawing.Point(278, 127);
            this.txt_numero.Name = "txt_numero";
            this.txt_numero.Size = new System.Drawing.Size(113, 28);
            this.txt_numero.TabIndex = 26;
            // 
            // lbl_numero
            // 
            this.lbl_numero.AutoSize = true;
            this.lbl_numero.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numero.Location = new System.Drawing.Point(43, 127);
            this.lbl_numero.Name = "lbl_numero";
            this.lbl_numero.Size = new System.Drawing.Size(214, 22);
            this.lbl_numero.TabIndex = 25;
            this.lbl_numero.Text = "INGRESE EL NUMERO:";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_desencolar);
            this.Controls.Add(this.brn_eliminar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.lst_colas);
            this.Controls.Add(this.btn_encolar);
            this.Controls.Add(this.txt_numero);
            this.Controls.Add(this.lbl_numero);
            this.Name = "frm_main";
            this.Text = "COLITA BB";
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_desencolar;
        private System.Windows.Forms.Button brn_eliminar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.ListBox lst_colas;
        private System.Windows.Forms.Button btn_encolar;
        private System.Windows.Forms.TextBox txt_numero;
        private System.Windows.Forms.Label lbl_numero;
    }
}

