﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COLA
{
    class NodoCola
    {
        int num;
        NodoCola sig;//Direccion del nodo con el que se enlasa
        public NodoCola()
        {
            num = 0;
            sig = null;
        }

        public void setNum(int n)
        {
            this.num = n;
        }
        public void setSig(NodoCola punt)
        {
            sig = punt;
        }

        public int getNum()
        {
            return num;
        }
        public NodoCola getSig()
        {
            return sig;
        }
    }
}
