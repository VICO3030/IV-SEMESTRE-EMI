﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Colabanco
{
    public partial class Form1 : Form
    {
        Cola c,c2;
        public Form1()
        {
            c = new Cola();
            c2 = new Cola();
            InitializeComponent();
            
        }
        public int generarRamd()
        {
            Random random = new Random();
            int num = random.Next(2000, 3000);
            MessageBox.Show(num.ToString());
            return num;

        }
        public void mostrar()
        {
            Nodo xd=c.getFrente();
            lst_lista1.Items.Clear();
            while (xd != null)
            {
                lst_lista1.Items.Add(xd.Num);
                xd=xd.Sig;
            }

        }
        public void mostrar2()
        {
            Nodo xd = c2.getFrente();
            lst_lista2.Items.Clear();
            while (xd != null)
            {
                lst_lista2.Items.Add(xd.Num);
                xd = xd.Sig;
            }

        }

        private void lst_lista1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_atender_Click(object sender, EventArgs e)
        {
            if(txt_dia.Text!="")
            {
                if (txt_dia.Text == "LUNES")
                {
                    atender(0, 1);
                    mostrar2();
                }
                else if (txt_dia.Text == "MARTES")
                {
                    atender(2, 3);
                    mostrar2();
                }
                else if (txt_dia.Text == "MIERCOLES")
                {
                    atender(4, 5);
                    mostrar2();
                }
                else if (txt_dia.Text == "JUEVES")
                {
                    atender(6, 7);
                    mostrar2();
                }
                else if (txt_dia.Text == "VIERNES")
                {
                    atender(8, 9);
                    mostrar2();
                }
                else
                {
                    MessageBox.Show("INGRESO MAL EL DIA");
                }
            }
            else
            {
                MessageBox.Show("NO COLOCO EL DIA!!!!!!!!!!!!!!!");
            }
        }

        private void btn_rand_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++) c.encolar(generarRamd());
            mostrar();
        }

        private void lst_lista2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbl_titulo_Click(object sender, EventArgs e)
        {

        }

        private void lbl_num_Click(object sender, EventArgs e)
        {

        }

        private void txt_dia_TextChanged(object sender, EventArgs e)
        {

        }

        public void atender(int n,int n2)
        {
            int cont=0;
            Nodo xd = c.getFrente();
            while (xd != null)
            {
                if (xd.Num % 10 == n || xd.Num % 10 == n2)
                {
                    c2.encolar(xd.Num);
                    cont++;
                }
                xd = xd.Sig;
            }
            MessageBox.Show("SE ATENDERAN A: "+cont+" PERSONAS");
        }
    }
}
