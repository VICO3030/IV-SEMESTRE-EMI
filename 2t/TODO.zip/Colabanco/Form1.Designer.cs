﻿namespace Colabanco
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_num = new System.Windows.Forms.Label();
            this.txt_dia = new System.Windows.Forms.TextBox();
            this.lst_lista1 = new System.Windows.Forms.ListBox();
            this.lst_lista2 = new System.Windows.Forms.ListBox();
            this.btn_atender = new System.Windows.Forms.Button();
            this.btn_rand = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(374, 18);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(159, 51);
            this.lbl_titulo.TabIndex = 35;
            this.lbl_titulo.Text = "COLAS";
            this.lbl_titulo.Click += new System.EventHandler(this.lbl_titulo_Click);
            // 
            // lbl_num
            // 
            this.lbl_num.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(48, 121);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(203, 37);
            this.lbl_num.TabIndex = 32;
            this.lbl_num.Text = "INGRESE EL DIA:";
            this.lbl_num.Click += new System.EventHandler(this.lbl_num_Click);
            // 
            // txt_dia
            // 
            this.txt_dia.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dia.Location = new System.Drawing.Point(257, 120);
            this.txt_dia.Name = "txt_dia";
            this.txt_dia.Size = new System.Drawing.Size(192, 36);
            this.txt_dia.TabIndex = 33;
            this.txt_dia.TextChanged += new System.EventHandler(this.txt_dia_TextChanged);
            // 
            // lst_lista1
            // 
            this.lst_lista1.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista1.ItemHeight = 27;
            this.lst_lista1.Location = new System.Drawing.Point(93, 261);
            this.lst_lista1.Name = "lst_lista1";
            this.lst_lista1.Size = new System.Drawing.Size(245, 139);
            this.lst_lista1.TabIndex = 34;
            this.lst_lista1.SelectedIndexChanged += new System.EventHandler(this.lst_lista1_SelectedIndexChanged);
            // 
            // lst_lista2
            // 
            this.lst_lista2.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista2.ItemHeight = 27;
            this.lst_lista2.Location = new System.Drawing.Point(487, 261);
            this.lst_lista2.Name = "lst_lista2";
            this.lst_lista2.Size = new System.Drawing.Size(245, 139);
            this.lst_lista2.TabIndex = 36;
            this.lst_lista2.SelectedIndexChanged += new System.EventHandler(this.lst_lista2_SelectedIndexChanged);
            // 
            // btn_atender
            // 
            this.btn_atender.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_atender.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_atender.Location = new System.Drawing.Point(541, 200);
            this.btn_atender.Name = "btn_atender";
            this.btn_atender.Size = new System.Drawing.Size(149, 55);
            this.btn_atender.TabIndex = 37;
            this.btn_atender.Text = "ATENDER";
            this.btn_atender.UseVisualStyleBackColor = false;
            this.btn_atender.Click += new System.EventHandler(this.btn_atender_Click);
            // 
            // btn_rand
            // 
            this.btn_rand.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_rand.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rand.Location = new System.Drawing.Point(151, 184);
            this.btn_rand.Name = "btn_rand";
            this.btn_rand.Size = new System.Drawing.Size(149, 71);
            this.btn_rand.TabIndex = 38;
            this.btn_rand.Text = "GENERAR RAND";
            this.btn_rand.UseVisualStyleBackColor = false;
            this.btn_rand.Click += new System.EventHandler(this.btn_rand_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 536);
            this.Controls.Add(this.btn_rand);
            this.Controls.Add(this.btn_atender);
            this.Controls.Add(this.lst_lista2);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.txt_dia);
            this.Controls.Add(this.lst_lista1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.TextBox txt_dia;
        private System.Windows.Forms.ListBox lst_lista1;
        private System.Windows.Forms.ListBox lst_lista2;
        private System.Windows.Forms.Button btn_atender;
        private System.Windows.Forms.Button btn_rand;
    }
}

