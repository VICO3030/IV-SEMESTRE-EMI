﻿namespace PLANTILLAP2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_motrar = new System.Windows.Forms.Button();
            this.lst_lista1 = new System.Windows.Forms.ListBox();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lbl_num = new System.Windows.Forms.Label();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_encolar = new System.Windows.Forms.Button();
            this.btn_desencolar = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_apilar = new System.Windows.Forms.Button();
            this.btn_desapilar = new System.Windows.Forms.Button();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.btn_ordenar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_motrar
            // 
            this.btn_motrar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_motrar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_motrar.Location = new System.Drawing.Point(603, 12);
            this.btn_motrar.Name = "btn_motrar";
            this.btn_motrar.Size = new System.Drawing.Size(149, 55);
            this.btn_motrar.TabIndex = 0;
            this.btn_motrar.Text = "MOSTRAR";
            this.btn_motrar.UseVisualStyleBackColor = false;
            // 
            // lst_lista1
            // 
            this.lst_lista1.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista1.ItemHeight = 27;
            this.lst_lista1.Location = new System.Drawing.Point(133, 185);
            this.lst_lista1.Name = "lst_lista1";
            this.lst_lista1.Size = new System.Drawing.Size(245, 139);
            this.lst_lista1.TabIndex = 0;
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(299, 94);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(100, 36);
            this.txt_num.TabIndex = 0;
            // 
            // lbl_num
            // 
            this.lbl_num.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(71, 94);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(203, 37);
            this.lbl_num.TabIndex = 0;
            this.lbl_num.Text = "INGRESE EL NUMERO:";
            this.lbl_num.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_eliminar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.Location = new System.Drawing.Point(603, 83);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(149, 55);
            this.btn_eliminar.TabIndex = 1;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = false;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_buscar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Location = new System.Drawing.Point(603, 152);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(149, 55);
            this.btn_buscar.TabIndex = 2;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            // 
            // btn_encolar
            // 
            this.btn_encolar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_encolar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_encolar.Location = new System.Drawing.Point(603, 222);
            this.btn_encolar.Name = "btn_encolar";
            this.btn_encolar.Size = new System.Drawing.Size(149, 55);
            this.btn_encolar.TabIndex = 3;
            this.btn_encolar.Text = "ENCOLAR";
            this.btn_encolar.UseVisualStyleBackColor = false;
            // 
            // btn_desencolar
            // 
            this.btn_desencolar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_desencolar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_desencolar.Location = new System.Drawing.Point(603, 296);
            this.btn_desencolar.Name = "btn_desencolar";
            this.btn_desencolar.Size = new System.Drawing.Size(149, 55);
            this.btn_desencolar.TabIndex = 4;
            this.btn_desencolar.Text = "DESENCOLAR";
            this.btn_desencolar.UseVisualStyleBackColor = false;
            // 
            // btn_insertar
            // 
            this.btn_insertar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_insertar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insertar.Location = new System.Drawing.Point(229, 366);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(149, 55);
            this.btn_insertar.TabIndex = 5;
            this.btn_insertar.Text = "INSERTAR";
            this.btn_insertar.UseVisualStyleBackColor = false;
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(290, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(159, 51);
            this.lbl_titulo.TabIndex = 31;
            this.lbl_titulo.Text = "COLAS";
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_salir.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salir.Location = new System.Drawing.Point(603, 366);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(149, 55);
            this.btn_salir.TabIndex = 32;
            this.btn_salir.Text = "SALIR";
            this.btn_salir.UseVisualStyleBackColor = false;
            // 
            // btn_apilar
            // 
            this.btn_apilar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_apilar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_apilar.Location = new System.Drawing.Point(448, 222);
            this.btn_apilar.Name = "btn_apilar";
            this.btn_apilar.Size = new System.Drawing.Size(149, 55);
            this.btn_apilar.TabIndex = 32;
            this.btn_apilar.Text = "APILAR";
            this.btn_apilar.UseVisualStyleBackColor = false;
            // 
            // btn_desapilar
            // 
            this.btn_desapilar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_desapilar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_desapilar.Location = new System.Drawing.Point(448, 296);
            this.btn_desapilar.Name = "btn_desapilar";
            this.btn_desapilar.Size = new System.Drawing.Size(149, 55);
            this.btn_desapilar.TabIndex = 33;
            this.btn_desapilar.Text = "DESAPILAR";
            this.btn_desapilar.UseVisualStyleBackColor = false;
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_registrar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(65, 366);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(149, 55);
            this.btn_registrar.TabIndex = 34;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            // 
            // btn_ordenar
            // 
            this.btn_ordenar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_ordenar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ordenar.Location = new System.Drawing.Point(448, 366);
            this.btn_ordenar.Name = "btn_ordenar";
            this.btn_ordenar.Size = new System.Drawing.Size(149, 55);
            this.btn_ordenar.TabIndex = 35;
            this.btn_ordenar.Text = "ORDENAR";
            this.btn_ordenar.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_ordenar);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.btn_desapilar);
            this.Controls.Add(this.btn_apilar);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.btn_desencolar);
            this.Controls.Add(this.btn_encolar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lst_lista1);
            this.Controls.Add(this.btn_motrar);
            this.Name = "Form1";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_motrar;
        private System.Windows.Forms.ListBox lst_lista1;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_encolar;
        private System.Windows.Forms.Button btn_desencolar;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_apilar;
        private System.Windows.Forms.Button btn_desapilar;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button btn_ordenar;
    }
}

