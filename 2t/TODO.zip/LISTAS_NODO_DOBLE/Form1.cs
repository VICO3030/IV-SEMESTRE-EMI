﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class frm_COMPETIDOR : Form
    {
        public frm_COMPETIDOR()
        {
            InitializeComponent();
        }

        private void frm_COMPETIDOR_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void grb_carrera_Enter(object sender, EventArgs e)
        {

        }

        private void grb_ciclista_Enter(object sender, EventArgs e)
        {

        }

        private void btn_registrarb_Click(object sender, EventArgs e)
        {
            CARRERA ca = new CARRERA();
            this.Hide();
            ca.Show();
        }

        private void btn_registrarC_Click(object sender, EventArgs e)
        {
            Ciclista c = new Ciclista();
            this.Hide();
            c.Show();
        }

        private void btn_mostrarC_Click(object sender, EventArgs e)
        {
            MostrarCiclista c = new MostrarCiclista();
            this.Hide();
            c.Show();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            BUSCARCICLISTA b = new BUSCARCICLISTA();
            b.Show();
            this.Hide();
        }

        private void btn_mostrarB_Click(object sender, EventArgs e)
        {
            MOSTRARCARRERRA c = new MOSTRARCARRERRA();
            this.Hide();
            c.Show();
        }

        private void ORDENAR_Click(object sender, EventArgs e)
        {
            estatica.ciclistaLista.ordenarCiclista();
        }

        private void btn_buscarcarrera_Click(object sender, EventArgs e)
        {
            BuscarCarrera b=new BuscarCarrera();
            this.Hide();
            b.Show();
        }
    }
}
