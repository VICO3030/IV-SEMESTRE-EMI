﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_NODO_DOBLE
{
    class NodoCarrera
    {
        int numBici;
        float tiempo;
        int lugar;
        DateTime date;
        NodoCarrera sig;
        NodoCarrera ant;
        public NodoCarrera()
        {
            numBici = 0;
            tiempo = 0;
            lugar = 0;
            date= DateTime.Now;
            ant = null;
            sig = null;
        }
        public void setNumBici(int b)
        {
            numBici = b;
        }
        public void setTiempo(float t)
        {
            tiempo = t;
        }
        public void setLugar(int lu)
        {
            lugar = lu;
        }
        public void setAnterior(NodoCarrera punt)
        {
            ant = punt;
        }
        public void setSiguiente(NodoCarrera punt)
        {
            sig = punt;
        }
        public int getNumBici()
        {
            return numBici;
        }
        public float getTiempo()
        {
            return tiempo;
        }
        public int getLugar()
        {
            return lugar;
        }
        public NodoCarrera getAnterior()
        {
            return ant;
        }
        public NodoCarrera getSiguiente()
        {
            return sig;
        }
        public DateTime getDate()
        {
            return date;
        }
        public void setDate(DateTime punt)
        {
            date = punt;
        }
    }
}
