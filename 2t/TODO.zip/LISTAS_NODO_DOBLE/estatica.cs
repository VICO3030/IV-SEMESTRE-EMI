﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_NODO_DOBLE
{
    class estatica
    {
        public static NodoDoble ciclista=new NodoDoble();
        public static NodoCarrera carrera=new NodoCarrera();
        public static ListaCarrera carreraLista = new ListaCarrera();
        public static Lista_doble ciclistaLista = new Lista_doble();
    }
}
