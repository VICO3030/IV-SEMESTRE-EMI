﻿namespace LISTAS_NODO_DOBLE
{
    partial class BuscarCarrera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_tiempo = new System.Windows.Forms.Label();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.txt_numBici = new System.Windows.Forms.TextBox();
            this.lbl_numBici = new System.Windows.Forms.Label();
            this.lbl_lugar = new System.Windows.Forms.Label();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_fecha.Location = new System.Drawing.Point(74, 221);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(18, 26);
            this.lbl_fecha.TabIndex = 29;
            this.lbl_fecha.Text = ".";
            // 
            // lbl_tiempo
            // 
            this.lbl_tiempo.AutoSize = true;
            this.lbl_tiempo.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tiempo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_tiempo.Location = new System.Drawing.Point(74, 174);
            this.lbl_tiempo.Name = "lbl_tiempo";
            this.lbl_tiempo.Size = new System.Drawing.Size(18, 26);
            this.lbl_tiempo.TabIndex = 28;
            this.lbl_tiempo.Text = ".";
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.Silver;
            this.btn_buscar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_buscar.Location = new System.Drawing.Point(534, 31);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(110, 48);
            this.btn_buscar.TabIndex = 27;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(798, 416);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 26;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // txt_numBici
            // 
            this.txt_numBici.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_numBici.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numBici.Location = new System.Drawing.Point(250, 35);
            this.txt_numBici.Name = "txt_numBici";
            this.txt_numBici.Size = new System.Drawing.Size(278, 32);
            this.txt_numBici.TabIndex = 25;
            // 
            // lbl_numBici
            // 
            this.lbl_numBici.AutoSize = true;
            this.lbl_numBici.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numBici.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_numBici.Location = new System.Drawing.Point(60, 41);
            this.lbl_numBici.Name = "lbl_numBici";
            this.lbl_numBici.Size = new System.Drawing.Size(190, 26);
            this.lbl_numBici.TabIndex = 24;
            this.lbl_numBici.Text = "NUMERO DE BICI:";
            // 
            // lbl_lugar
            // 
            this.lbl_lugar.AutoSize = true;
            this.lbl_lugar.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lugar.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_lugar.Location = new System.Drawing.Point(74, 274);
            this.lbl_lugar.Name = "lbl_lugar";
            this.lbl_lugar.Size = new System.Drawing.Size(18, 26);
            this.lbl_lugar.TabIndex = 30;
            this.lbl_lugar.Text = ".";
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackColor = System.Drawing.Color.Silver;
            this.btn_eliminar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_eliminar.Location = new System.Drawing.Point(673, 31);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(110, 48);
            this.btn_eliminar.TabIndex = 31;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = false;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // BuscarCarrera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(945, 503);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lbl_lugar);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_tiempo);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.txt_numBici);
            this.Controls.Add(this.lbl_numBici);
            this.Name = "BuscarCarrera";
            this.Text = "BuscarCarrera";
            this.Load += new System.EventHandler(this.BuscarCarrera_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_tiempo;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.TextBox txt_numBici;
        private System.Windows.Forms.Label lbl_numBici;
        private System.Windows.Forms.Label lbl_lugar;
        private System.Windows.Forms.Button btn_eliminar;
    }
}