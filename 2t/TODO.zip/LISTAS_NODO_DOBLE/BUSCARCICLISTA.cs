﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class BUSCARCICLISTA : Form
    {
        public BUSCARCICLISTA()
        {
            InitializeComponent();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            NodoDoble p;
            p = estatica.ciclistaLista.buscarCiclista(int.Parse(txt_numBici.Text));
            if (p == null)
            {
                MessageBox.Show("NO EXISTE EL CICLISTA");
                txt_numBici.Clear();
            }
            else
            {
                lbl_categoria.Text = p.getCategoria();
                lbl_nombre.Text = p.getNombreCiclista();
            }
        }

        private void lbl_nombre_Click(object sender, EventArgs e)
        {

        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR principal=new frm_COMPETIDOR();
            this.Hide();
            principal.Show();
            
        }

        private void BUSCARCICLISTA_Load(object sender, EventArgs e)
        {

        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(estatica.ciclistaLista.eliminar(int.Parse(txt_numBici.Text)));
            pcb_bici.Visible = true;
        }
    }
}
