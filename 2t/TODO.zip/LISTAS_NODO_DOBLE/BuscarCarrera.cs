﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class BuscarCarrera : Form
    {
        public BuscarCarrera()
        {
            InitializeComponent();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            NodoCarrera p;
            p = estatica.carreraLista.buscarCarrera(int.Parse(txt_numBici.Text));
            if (p == null)
            {
                MessageBox.Show("NO EXISTE EL CICLISTA");
                txt_numBici.Clear();
            }
            else
            {
                lbl_fecha.Text = ("FECHA: " + p.getDate().ToString());
                lbl_lugar.Text = ("LUGAR: " + p.getLugar());
                lbl_tiempo.Text = "TIEMPO: " + (p.getTiempo().ToString());
            }
        }

        private void BuscarCarrera_Load(object sender, EventArgs e)
        {

        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR p = new frm_COMPETIDOR();
            this.Hide();
            p.Show();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(estatica.carreraLista.eliminarCa(int.Parse(txt_numBici.Text)));
        }
    }
}
