﻿namespace LISTAS_NODO_DOBLE
{
    partial class frm_COMPETIDOR
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_registrarC = new System.Windows.Forms.Button();
            this.grb_ciclista = new System.Windows.Forms.GroupBox();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_mostrarC = new System.Windows.Forms.Button();
            this.grb_carrera = new System.Windows.Forms.GroupBox();
            this.btn_mostrarB = new System.Windows.Forms.Button();
            this.btn_registrarb = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_menu = new System.Windows.Forms.Label();
            this.ORDENAR = new System.Windows.Forms.Button();
            this.btn_buscarcarrera = new System.Windows.Forms.Button();
            this.grb_ciclista.SuspendLayout();
            this.grb_carrera.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_registrarC
            // 
            this.btn_registrarC.BackColor = System.Drawing.Color.Silver;
            this.btn_registrarC.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrarC.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registrarC.Location = new System.Drawing.Point(175, 177);
            this.btn_registrarC.Name = "btn_registrarC";
            this.btn_registrarC.Size = new System.Drawing.Size(110, 48);
            this.btn_registrarC.TabIndex = 7;
            this.btn_registrarC.Text = "REGISTRAR";
            this.btn_registrarC.UseVisualStyleBackColor = false;
            this.btn_registrarC.Click += new System.EventHandler(this.btn_registrarC_Click);
            // 
            // grb_ciclista
            // 
            this.grb_ciclista.Controls.Add(this.ORDENAR);
            this.grb_ciclista.Controls.Add(this.btn_buscar);
            this.grb_ciclista.Controls.Add(this.btn_mostrarC);
            this.grb_ciclista.Controls.Add(this.btn_registrarC);
            this.grb_ciclista.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.grb_ciclista.Location = new System.Drawing.Point(71, 63);
            this.grb_ciclista.Name = "grb_ciclista";
            this.grb_ciclista.Size = new System.Drawing.Size(493, 455);
            this.grb_ciclista.TabIndex = 8;
            this.grb_ciclista.TabStop = false;
            this.grb_ciclista.Text = "Menu cilcista";
            this.grb_ciclista.Enter += new System.EventHandler(this.grb_ciclista_Enter);
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.Silver;
            this.btn_buscar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_buscar.Location = new System.Drawing.Point(175, 296);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(110, 48);
            this.btn_buscar.TabIndex = 9;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_mostrarC
            // 
            this.btn_mostrarC.BackColor = System.Drawing.Color.Silver;
            this.btn_mostrarC.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarC.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_mostrarC.Location = new System.Drawing.Point(175, 231);
            this.btn_mostrarC.Name = "btn_mostrarC";
            this.btn_mostrarC.Size = new System.Drawing.Size(110, 48);
            this.btn_mostrarC.TabIndex = 8;
            this.btn_mostrarC.Text = "MOSTRAR";
            this.btn_mostrarC.UseVisualStyleBackColor = false;
            this.btn_mostrarC.Click += new System.EventHandler(this.btn_mostrarC_Click);
            // 
            // grb_carrera
            // 
            this.grb_carrera.Controls.Add(this.btn_buscarcarrera);
            this.grb_carrera.Controls.Add(this.btn_mostrarB);
            this.grb_carrera.Controls.Add(this.btn_registrarb);
            this.grb_carrera.Controls.Add(this.button1);
            this.grb_carrera.Controls.Add(this.label5);
            this.grb_carrera.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.grb_carrera.Location = new System.Drawing.Point(619, 63);
            this.grb_carrera.Name = "grb_carrera";
            this.grb_carrera.Size = new System.Drawing.Size(485, 455);
            this.grb_carrera.TabIndex = 9;
            this.grb_carrera.TabStop = false;
            this.grb_carrera.Text = "Menu Carrera";
            this.grb_carrera.Enter += new System.EventHandler(this.grb_carrera_Enter);
            // 
            // btn_mostrarB
            // 
            this.btn_mostrarB.BackColor = System.Drawing.Color.Silver;
            this.btn_mostrarB.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarB.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_mostrarB.Location = new System.Drawing.Point(184, 231);
            this.btn_mostrarB.Name = "btn_mostrarB";
            this.btn_mostrarB.Size = new System.Drawing.Size(110, 48);
            this.btn_mostrarB.TabIndex = 10;
            this.btn_mostrarB.Text = "MOSTRAR";
            this.btn_mostrarB.UseVisualStyleBackColor = false;
            this.btn_mostrarB.Click += new System.EventHandler(this.btn_mostrarB_Click);
            // 
            // btn_registrarb
            // 
            this.btn_registrarb.BackColor = System.Drawing.Color.Silver;
            this.btn_registrarb.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrarb.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registrarb.Location = new System.Drawing.Point(184, 177);
            this.btn_registrarb.Name = "btn_registrarb";
            this.btn_registrarb.Size = new System.Drawing.Size(110, 48);
            this.btn_registrarb.TabIndex = 10;
            this.btn_registrarb.Text = "REGISTRAR";
            this.btn_registrarb.UseVisualStyleBackColor = false;
            this.btn_registrarb.Click += new System.EventHandler(this.btn_registrarb_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(981, 77);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 48);
            this.button1.TabIndex = 7;
            this.button1.Text = "REGISTRAR";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "label5";
            // 
            // lbl_menu
            // 
            this.lbl_menu.AutoSize = true;
            this.lbl_menu.Font = new System.Drawing.Font("MS Reference Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_menu.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lbl_menu.Location = new System.Drawing.Point(363, 9);
            this.lbl_menu.Name = "lbl_menu";
            this.lbl_menu.Size = new System.Drawing.Size(378, 40);
            this.lbl_menu.TabIndex = 10;
            this.lbl_menu.Text = "MENU DE OPCIONES";
            // 
            // ORDENAR
            // 
            this.ORDENAR.BackColor = System.Drawing.Color.Silver;
            this.ORDENAR.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ORDENAR.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ORDENAR.Location = new System.Drawing.Point(175, 350);
            this.ORDENAR.Name = "ORDENAR";
            this.ORDENAR.Size = new System.Drawing.Size(110, 48);
            this.ORDENAR.TabIndex = 10;
            this.ORDENAR.Text = "ORDENAR";
            this.ORDENAR.UseVisualStyleBackColor = false;
            this.ORDENAR.Click += new System.EventHandler(this.ORDENAR_Click);
            // 
            // btn_buscarcarrera
            // 
            this.btn_buscarcarrera.BackColor = System.Drawing.Color.Silver;
            this.btn_buscarcarrera.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscarcarrera.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_buscarcarrera.Location = new System.Drawing.Point(184, 285);
            this.btn_buscarcarrera.Name = "btn_buscarcarrera";
            this.btn_buscarcarrera.Size = new System.Drawing.Size(110, 48);
            this.btn_buscarcarrera.TabIndex = 11;
            this.btn_buscarcarrera.Text = "BUSCAR";
            this.btn_buscarcarrera.UseVisualStyleBackColor = false;
            this.btn_buscarcarrera.Click += new System.EventHandler(this.btn_buscarcarrera_Click);
            // 
            // frm_COMPETIDOR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1167, 624);
            this.Controls.Add(this.lbl_menu);
            this.Controls.Add(this.grb_carrera);
            this.Controls.Add(this.grb_ciclista);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Name = "frm_COMPETIDOR";
            this.Text = "MENU DE OPCIONES";
            this.Load += new System.EventHandler(this.frm_COMPETIDOR_Load);
            this.grb_ciclista.ResumeLayout(false);
            this.grb_carrera.ResumeLayout(false);
            this.grb_carrera.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_registrarC;
        private System.Windows.Forms.GroupBox grb_ciclista;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_mostrarC;
        private System.Windows.Forms.GroupBox grb_carrera;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_mostrarB;
        private System.Windows.Forms.Button btn_registrarb;
        private System.Windows.Forms.Label lbl_menu;
        private System.Windows.Forms.Button ORDENAR;
        private System.Windows.Forms.Button btn_buscarcarrera;
    }
}

