﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class Ciclista : Form
    {
        public Ciclista()
        {
            InitializeComponent();
        }

        private void Ciclista_Load(object sender, EventArgs e)
        {

        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR principal = new frm_COMPETIDOR();
            this.Hide();
            principal.Show();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            int numBici=int.Parse(txt_numBici.Text);
            string nombreCiclista=txt_nombreComp.Text;
            string categoria=cbx_categoria.Text;
            estatica.ciclistaLista.registrarLista(numBici,nombreCiclista,categoria);
        }

        private void txt_nombreComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                txt_numBici.Focus();

            }
        }
    }
}
