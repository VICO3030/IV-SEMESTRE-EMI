﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class MOSTRARCARRERRA : Form
    {
        public MOSTRARCARRERRA()
        {
            InitializeComponent();
        }

        private void MOSTRARCARRERRA_Load(object sender, EventArgs e)
        {

        }

        

        public void mostrarinicio()
        {
            NodoCarrera punt = estatica.carreraLista.getCabezaCa();
            int cont = 0;
            while (punt != null)
            {
                cont++;
                punt.setLugar(cont);
                if (cont <= 3)
                {
                    dgv_mostrarcarrera.Rows.Add(punt.getNumBici(), punt.getTiempo(), punt.getDate(), punt.getLugar());
                }
                else
                {
                    dgv_mostrarcarrera.Rows.Add(punt.getNumBici(), punt.getTiempo(), punt.getDate(),"NO CLASIFICO?");
                }
                punt = punt.getSiguiente();
            }
        }
        public void mostrarFinal()
        {
            NodoCarrera punt = estatica.carreraLista.getCabezaCa();
            while (punt.getSiguiente() != null)
            {
                punt = punt.getSiguiente();
            }
            while (punt != null)
            {
                dgv_mostrarcarrera.Rows.Add(punt.getNumBici(), punt.getTiempo(), punt.getDate(), punt.getLugar());
                punt = punt.getAnterior();

            }
        }
        private void btn_mostrarf_Click(object sender, EventArgs e)
        {
            if (estatica.carreraLista.getCabezaCa() == null)
            {
                MessageBox.Show("NO HAY DATOS EN LA LISTA");
            }
            else
            {
                mostrarFinal();

            }
        }
        private void btn_MOSTRARI_Click(object sender, EventArgs e)
        {
            estatica.carreraLista.ordenarinsercion();
            if (estatica.carreraLista.getCabezaCa() == null)
            {
                MessageBox.Show("NO HAY DATOS EN LA LISTA");
            }
            else
            {
                mostrarinicio();

            }
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR principal = new frm_COMPETIDOR();
            this.Hide();
            principal.Show();
        }

        private void dgv_mostrarcarrera_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
