﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class CARRERA : Form
    {
        NodoDoble p;
        public CARRERA()
        {
            InitializeComponent();
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {

            int numBici = int.Parse(txt_numBici.Text);
            float tiempo = float.Parse(txt_tiempo.Text);
            DateTime date=DateTime.Parse(txt_fecha.Text);
            estatica.carreraLista.registrarCarrera(numBici,tiempo,date);
            dgv_carreras.Rows.Add(p.getNombreCiclista(),numBici,tiempo,date);
            MessageBox.Show("Alumno REGITRADO!");
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR principal = new frm_COMPETIDOR();
            this.Hide();
            principal.Show();
        }

        private void CARRERA_Load(object sender, EventArgs e)
        {

        }

        private void txt_lugar_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_numBici_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                 p=estatica.ciclistaLista.buscarCiclista(int.Parse(txt_numBici.Text));
                if (p == null)
                {
                    MessageBox.Show("NO EXISTE EL CICLISTA");
                    txt_numBici.Clear();
                    txt_numBici.Focus();
                }
                else
                {
                    lbl_categoria.Text = p.getCategoria();
                    lbl_nombre.Text = p.getNombreCiclista();
                    txt_fecha.Enabled = true;
                    txt_tiempo.Enabled = true;
                    btn_registrar.Enabled = true;
                }
            }
        }

        private void txt_numBici_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgv_carreras_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbl_numBici_Click(object sender, EventArgs e)
        {

        }

        private void grb_datosca_Enter(object sender, EventArgs e)
        {

        }
    }
}
