﻿namespace LISTAS_NODO_DOBLE
{
    partial class CARRERA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_numBici = new System.Windows.Forms.TextBox();
            this.txt_tiempo = new System.Windows.Forms.TextBox();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_numBici = new System.Windows.Forms.Label();
            this.lbl_tiempo = new System.Windows.Forms.Label();
            this.txt_fecha = new System.Windows.Forms.TextBox();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.grb_datosca = new System.Windows.Forms.GroupBox();
            this.grb_datosci = new System.Windows.Forms.GroupBox();
            this.lbl_categoria = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.dgv_carreras = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grb_datosca.SuspendLayout();
            this.grb_datosci.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_carreras)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_numBici
            // 
            this.txt_numBici.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_numBici.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numBici.Location = new System.Drawing.Point(229, 59);
            this.txt_numBici.Name = "txt_numBici";
            this.txt_numBici.Size = new System.Drawing.Size(188, 32);
            this.txt_numBici.TabIndex = 17;
            this.txt_numBici.TextChanged += new System.EventHandler(this.txt_numBici_TextChanged);
            this.txt_numBici.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_numBici_KeyPress);
            // 
            // txt_tiempo
            // 
            this.txt_tiempo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_tiempo.Enabled = false;
            this.txt_tiempo.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tiempo.Location = new System.Drawing.Point(171, 102);
            this.txt_tiempo.Name = "txt_tiempo";
            this.txt_tiempo.Size = new System.Drawing.Size(246, 32);
            this.txt_tiempo.TabIndex = 16;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_fecha.Location = new System.Drawing.Point(7, 190);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(222, 26);
            this.lbl_fecha.TabIndex = 15;
            this.lbl_fecha.Text = "INGRESE LA FECHA: ";
            // 
            // lbl_numBici
            // 
            this.lbl_numBici.AutoSize = true;
            this.lbl_numBici.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numBici.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_numBici.Location = new System.Drawing.Point(39, 65);
            this.lbl_numBici.Name = "lbl_numBici";
            this.lbl_numBici.Size = new System.Drawing.Size(190, 26);
            this.lbl_numBici.TabIndex = 14;
            this.lbl_numBici.Text = "NUMERO DE BICI:";
            this.lbl_numBici.Click += new System.EventHandler(this.lbl_numBici_Click);
            // 
            // lbl_tiempo
            // 
            this.lbl_tiempo.AutoSize = true;
            this.lbl_tiempo.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tiempo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_tiempo.Location = new System.Drawing.Point(67, 108);
            this.lbl_tiempo.Name = "lbl_tiempo";
            this.lbl_tiempo.Size = new System.Drawing.Size(98, 26);
            this.lbl_tiempo.TabIndex = 13;
            this.lbl_tiempo.Text = "TIEMPO:";
            // 
            // txt_fecha
            // 
            this.txt_fecha.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_fecha.Enabled = false;
            this.txt_fecha.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fecha.Location = new System.Drawing.Point(229, 190);
            this.txt_fecha.Name = "txt_fecha";
            this.txt_fecha.Size = new System.Drawing.Size(188, 32);
            this.txt_fecha.TabIndex = 20;
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Silver;
            this.btn_registrar.Enabled = false;
            this.btn_registrar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registrar.Location = new System.Drawing.Point(758, 599);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(110, 48);
            this.btn_registrar.TabIndex = 21;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(894, 599);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 22;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // grb_datosca
            // 
            this.grb_datosca.Controls.Add(this.txt_fecha);
            this.grb_datosca.Controls.Add(this.txt_numBici);
            this.grb_datosca.Controls.Add(this.txt_tiempo);
            this.grb_datosca.Controls.Add(this.lbl_fecha);
            this.grb_datosca.Controls.Add(this.lbl_numBici);
            this.grb_datosca.Controls.Add(this.lbl_tiempo);
            this.grb_datosca.Location = new System.Drawing.Point(12, 41);
            this.grb_datosca.Name = "grb_datosca";
            this.grb_datosca.Size = new System.Drawing.Size(445, 262);
            this.grb_datosca.TabIndex = 23;
            this.grb_datosca.TabStop = false;
            this.grb_datosca.Text = "groupBox1";
            this.grb_datosca.Enter += new System.EventHandler(this.grb_datosca_Enter);
            // 
            // grb_datosci
            // 
            this.grb_datosci.Controls.Add(this.lbl_categoria);
            this.grb_datosci.Controls.Add(this.lbl_nombre);
            this.grb_datosci.Location = new System.Drawing.Point(524, 38);
            this.grb_datosci.Name = "grb_datosci";
            this.grb_datosci.Size = new System.Drawing.Size(379, 264);
            this.grb_datosci.TabIndex = 24;
            this.grb_datosci.TabStop = false;
            this.grb_datosci.Text = "groupBox2";
            // 
            // lbl_categoria
            // 
            this.lbl_categoria.AutoSize = true;
            this.lbl_categoria.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_categoria.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_categoria.Location = new System.Drawing.Point(38, 111);
            this.lbl_categoria.Name = "lbl_categoria";
            this.lbl_categoria.Size = new System.Drawing.Size(18, 26);
            this.lbl_categoria.TabIndex = 22;
            this.lbl_categoria.Text = ".";
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_nombre.Location = new System.Drawing.Point(38, 68);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(18, 26);
            this.lbl_nombre.TabIndex = 21;
            this.lbl_nombre.Text = ".";
            // 
            // dgv_carreras
            // 
            this.dgv_carreras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_carreras.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dgv_carreras.Location = new System.Drawing.Point(24, 353);
            this.dgv_carreras.Name = "dgv_carreras";
            this.dgv_carreras.RowHeadersWidth = 51;
            this.dgv_carreras.RowTemplate.Height = 24;
            this.dgv_carreras.Size = new System.Drawing.Size(901, 172);
            this.dgv_carreras.TabIndex = 25;
            this.dgv_carreras.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_carreras_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "CLICLISTA";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NUMERO";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "TIEMPO";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "FECHA";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 125;
            // 
            // CARRERA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1061, 659);
            this.Controls.Add(this.dgv_carreras);
            this.Controls.Add(this.grb_datosci);
            this.Controls.Add(this.grb_datosca);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.btn_registrar);
            this.Name = "CARRERA";
            this.Text = "CARRERA";
            this.Load += new System.EventHandler(this.CARRERA_Load);
            this.grb_datosca.ResumeLayout(false);
            this.grb_datosca.PerformLayout();
            this.grb_datosci.ResumeLayout(false);
            this.grb_datosci.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_carreras)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txt_numBici;
        private System.Windows.Forms.TextBox txt_tiempo;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_numBici;
        private System.Windows.Forms.Label lbl_tiempo;
        private System.Windows.Forms.TextBox txt_fecha;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.GroupBox grb_datosca;
        private System.Windows.Forms.GroupBox grb_datosci;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_categoria;
        private System.Windows.Forms.DataGridView dgv_carreras;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}