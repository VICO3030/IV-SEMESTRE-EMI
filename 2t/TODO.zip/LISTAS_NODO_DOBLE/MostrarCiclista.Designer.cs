﻿namespace LISTAS_NODO_DOBLE
{
    partial class MostrarCiclista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_mostrarciclista = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_volver = new System.Windows.Forms.Button();
            this.btn_MOSTRARI = new System.Windows.Forms.Button();
            this.btn_mostrarf = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mostrarciclista)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_mostrarciclista
            // 
            this.dgv_mostrarciclista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mostrarciclista.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgv_mostrarciclista.Location = new System.Drawing.Point(63, 22);
            this.dgv_mostrarciclista.Name = "dgv_mostrarciclista";
            this.dgv_mostrarciclista.RowHeadersWidth = 51;
            this.dgv_mostrarciclista.RowTemplate.Height = 24;
            this.dgv_mostrarciclista.Size = new System.Drawing.Size(574, 266);
            this.dgv_mostrarciclista.TabIndex = 0;
            this.dgv_mostrarciclista.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_mostrarciclista_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "NOMBRE";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NUMERO";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "CATEGORIA";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(643, 384);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 24;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // btn_MOSTRARI
            // 
            this.btn_MOSTRARI.BackColor = System.Drawing.Color.Silver;
            this.btn_MOSTRARI.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MOSTRARI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_MOSTRARI.Location = new System.Drawing.Point(412, 384);
            this.btn_MOSTRARI.Name = "btn_MOSTRARI";
            this.btn_MOSTRARI.Size = new System.Drawing.Size(110, 60);
            this.btn_MOSTRARI.TabIndex = 23;
            this.btn_MOSTRARI.Text = "MOSTRAR INICIO";
            this.btn_MOSTRARI.UseVisualStyleBackColor = false;
            this.btn_MOSTRARI.Click += new System.EventHandler(this.btn_MOSTRARI_Click);
            // 
            // btn_mostrarf
            // 
            this.btn_mostrarf.BackColor = System.Drawing.Color.Silver;
            this.btn_mostrarf.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarf.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_mostrarf.Location = new System.Drawing.Point(527, 384);
            this.btn_mostrarf.Name = "btn_mostrarf";
            this.btn_mostrarf.Size = new System.Drawing.Size(110, 60);
            this.btn_mostrarf.TabIndex = 25;
            this.btn_mostrarf.Text = "MOSTRAR FINAL";
            this.btn_mostrarf.UseVisualStyleBackColor = false;
            this.btn_mostrarf.Click += new System.EventHandler(this.btn_mostrarf_Click);
            // 
            // MostrarCiclista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(799, 456);
            this.Controls.Add(this.btn_mostrarf);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.btn_MOSTRARI);
            this.Controls.Add(this.dgv_mostrarciclista);
            this.Name = "MostrarCiclista";
            this.Text = "MostrarCiclista";
            this.Load += new System.EventHandler(this.MostrarCiclista_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mostrarciclista)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_mostrarciclista;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Button btn_MOSTRARI;
        private System.Windows.Forms.Button btn_mostrarf;
    }
}