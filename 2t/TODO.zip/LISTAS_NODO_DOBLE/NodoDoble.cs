﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_NODO_DOBLE
{
    //POR DEFECTO LAS CALSES SON PRIVADAS Y LOS STRUC SON PUBLICOS
    class NodoDoble
    {
        int numBici;
        string nombreCiclista;
        string categoria;
        NodoDoble sig;
        NodoDoble ant;
        public NodoDoble()
        {
            numBici = 0;
            nombreCiclista = "";
            categoria = "";
            ant = null;
            sig = null;

        }

        public void setNumBici(int b)
        {
            numBici=b;  
        }
        public void setNombreCiclista(string nom)
        {
            nombreCiclista = nom;
        }
        public void setCategoria(string cat)
        {
            categoria = cat;
        }
        public void setAnterior(NodoDoble punt)
        {
            ant = punt;
        }
        public void setSiguiente(NodoDoble punt)
        {
            sig = punt;
        }
        public int getNumBici()
        {
            return numBici;
        }
        public string getNombreCiclista()
        {
            return nombreCiclista;
        }
        public string getCategoria()
        {
            return categoria;
        }
        public NodoDoble getAnterior()
        {
            return ant;
        }
        public NodoDoble getSiguiente()
        {
            return sig;
        }
    }
    
}
