﻿namespace LISTAS_NODO_DOBLE
{
    partial class MOSTRARCARRERRA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_mostrarcarrera = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIEMPO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FECHA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_mostrarf = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.btn_MOSTRARI = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mostrarcarrera)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_mostrarcarrera
            // 
            this.dgv_mostrarcarrera.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mostrarcarrera.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.TIEMPO,
            this.FECHA,
            this.Column3});
            this.dgv_mostrarcarrera.Location = new System.Drawing.Point(12, 30);
            this.dgv_mostrarcarrera.Name = "dgv_mostrarcarrera";
            this.dgv_mostrarcarrera.RowHeadersWidth = 51;
            this.dgv_mostrarcarrera.RowTemplate.Height = 24;
            this.dgv_mostrarcarrera.Size = new System.Drawing.Size(805, 367);
            this.dgv_mostrarcarrera.TabIndex = 1;
            this.dgv_mostrarcarrera.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_mostrarcarrera_CellContentClick);
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NUMERO";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // TIEMPO
            // 
            this.TIEMPO.HeaderText = "TIEMPO";
            this.TIEMPO.MinimumWidth = 6;
            this.TIEMPO.Name = "TIEMPO";
            this.TIEMPO.Width = 125;
            // 
            // FECHA
            // 
            this.FECHA.HeaderText = "FECHA";
            this.FECHA.MinimumWidth = 6;
            this.FECHA.Name = "FECHA";
            this.FECHA.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "LUGAR";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // btn_mostrarf
            // 
            this.btn_mostrarf.BackColor = System.Drawing.Color.Silver;
            this.btn_mostrarf.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrarf.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_mostrarf.Location = new System.Drawing.Point(612, 445);
            this.btn_mostrarf.Name = "btn_mostrarf";
            this.btn_mostrarf.Size = new System.Drawing.Size(110, 60);
            this.btn_mostrarf.TabIndex = 28;
            this.btn_mostrarf.Text = "MOSTRAR FINAL";
            this.btn_mostrarf.UseVisualStyleBackColor = false;
            this.btn_mostrarf.Click += new System.EventHandler(this.btn_mostrarf_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(728, 445);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 27;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // btn_MOSTRARI
            // 
            this.btn_MOSTRARI.BackColor = System.Drawing.Color.Silver;
            this.btn_MOSTRARI.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MOSTRARI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_MOSTRARI.Location = new System.Drawing.Point(497, 445);
            this.btn_MOSTRARI.Name = "btn_MOSTRARI";
            this.btn_MOSTRARI.Size = new System.Drawing.Size(110, 60);
            this.btn_MOSTRARI.TabIndex = 26;
            this.btn_MOSTRARI.Text = "MOSTRAR INICIO";
            this.btn_MOSTRARI.UseVisualStyleBackColor = false;
            this.btn_MOSTRARI.Click += new System.EventHandler(this.btn_MOSTRARI_Click);
            // 
            // MOSTRARCARRERRA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(892, 529);
            this.Controls.Add(this.btn_mostrarf);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.btn_MOSTRARI);
            this.Controls.Add(this.dgv_mostrarcarrera);
            this.Name = "MOSTRARCARRERRA";
            this.Text = "MOSTRARCARRERRA";
            this.Load += new System.EventHandler(this.MOSTRARCARRERRA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mostrarcarrera)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_mostrarcarrera;
        private System.Windows.Forms.Button btn_mostrarf;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Button btn_MOSTRARI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIEMPO;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHA;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}