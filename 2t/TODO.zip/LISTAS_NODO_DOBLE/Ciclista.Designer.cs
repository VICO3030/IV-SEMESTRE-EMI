﻿namespace LISTAS_NODO_DOBLE
{
    partial class Ciclista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_numBici = new System.Windows.Forms.TextBox();
            this.txt_nombreComp = new System.Windows.Forms.TextBox();
            this.lbl_CATEGORIA = new System.Windows.Forms.Label();
            this.lbl_numBici = new System.Windows.Forms.Label();
            this.lbl_nombreComp = new System.Windows.Forms.Label();
            this.cbx_categoria = new System.Windows.Forms.ComboBox();
            this.btn_volver = new System.Windows.Forms.Button();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_numBici
            // 
            this.txt_numBici.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_numBici.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numBici.Location = new System.Drawing.Point(572, 131);
            this.txt_numBici.Name = "txt_numBici";
            this.txt_numBici.Size = new System.Drawing.Size(343, 32);
            this.txt_numBici.TabIndex = 11;
            // 
            // txt_nombreComp
            // 
            this.txt_nombreComp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_nombreComp.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombreComp.Location = new System.Drawing.Point(572, 93);
            this.txt_nombreComp.Name = "txt_nombreComp";
            this.txt_nombreComp.Size = new System.Drawing.Size(343, 32);
            this.txt_nombreComp.TabIndex = 10;
            this.txt_nombreComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_nombreComp_KeyPress);
            // 
            // lbl_CATEGORIA
            // 
            this.lbl_CATEGORIA.AutoSize = true;
            this.lbl_CATEGORIA.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CATEGORIA.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_CATEGORIA.Location = new System.Drawing.Point(289, 175);
            this.lbl_CATEGORIA.Name = "lbl_CATEGORIA";
            this.lbl_CATEGORIA.Size = new System.Drawing.Size(263, 26);
            this.lbl_CATEGORIA.TabIndex = 9;
            this.lbl_CATEGORIA.Text = "INGRESE LA CATEGORIA:";
            // 
            // lbl_numBici
            // 
            this.lbl_numBici.AutoSize = true;
            this.lbl_numBici.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numBici.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_numBici.Location = new System.Drawing.Point(45, 137);
            this.lbl_numBici.Name = "lbl_numBici";
            this.lbl_numBici.Size = new System.Drawing.Size(507, 26);
            this.lbl_numBici.TabIndex = 8;
            this.lbl_numBici.Text = "INGRESE EL NUMERO DE BICI DEL COMPETIDOR:";
            // 
            // lbl_nombreComp
            // 
            this.lbl_nombreComp.AutoSize = true;
            this.lbl_nombreComp.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombreComp.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_nombreComp.Location = new System.Drawing.Point(111, 99);
            this.lbl_nombreComp.Name = "lbl_nombreComp";
            this.lbl_nombreComp.Size = new System.Drawing.Size(426, 26);
            this.lbl_nombreComp.TabIndex = 7;
            this.lbl_nombreComp.Text = "INGRESE EL NOMBRE DEL COMPETIDOR:";
            // 
            // cbx_categoria
            // 
            this.cbx_categoria.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cbx_categoria.FormattingEnabled = true;
            this.cbx_categoria.Items.AddRange(new object[] {
            "Infantil",
            "Menores",
            "Juvenil",
            "Seniors",
            "Elite"});
            this.cbx_categoria.Location = new System.Drawing.Point(572, 175);
            this.cbx_categoria.Name = "cbx_categoria";
            this.cbx_categoria.Size = new System.Drawing.Size(343, 24);
            this.cbx_categoria.TabIndex = 12;
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(518, 264);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 24;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Silver;
            this.btn_registrar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registrar.Location = new System.Drawing.Point(382, 264);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(110, 48);
            this.btn_registrar.TabIndex = 23;
            this.btn_registrar.Text = "REGISTRAR";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // Ciclista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1011, 577);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.cbx_categoria);
            this.Controls.Add(this.txt_numBici);
            this.Controls.Add(this.txt_nombreComp);
            this.Controls.Add(this.lbl_CATEGORIA);
            this.Controls.Add(this.lbl_numBici);
            this.Controls.Add(this.lbl_nombreComp);
            this.Name = "Ciclista";
            this.Text = "Ciclista";
            this.Load += new System.EventHandler(this.Ciclista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_numBici;
        private System.Windows.Forms.TextBox txt_nombreComp;
        private System.Windows.Forms.Label lbl_CATEGORIA;
        private System.Windows.Forms.Label lbl_numBici;
        private System.Windows.Forms.Label lbl_nombreComp;
        private System.Windows.Forms.ComboBox cbx_categoria;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Button btn_registrar;
    }
}