﻿namespace LISTAS_NODO_DOBLE
{
    partial class BUSCARCICLISTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_numBici = new System.Windows.Forms.TextBox();
            this.lbl_numBici = new System.Windows.Forms.Label();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.lbl_categoria = new System.Windows.Forms.Label();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.pcb_bici = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_bici)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_numBici
            // 
            this.txt_numBici.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_numBici.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numBici.Location = new System.Drawing.Point(292, 125);
            this.txt_numBici.Name = "txt_numBici";
            this.txt_numBici.Size = new System.Drawing.Size(278, 32);
            this.txt_numBici.TabIndex = 19;
            // 
            // lbl_numBici
            // 
            this.lbl_numBici.AutoSize = true;
            this.lbl_numBici.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numBici.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_numBici.Location = new System.Drawing.Point(102, 131);
            this.lbl_numBici.Name = "lbl_numBici";
            this.lbl_numBici.Size = new System.Drawing.Size(190, 26);
            this.lbl_numBici.TabIndex = 18;
            this.lbl_numBici.Text = "NUMERO DE BICI:";
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackColor = System.Drawing.Color.Silver;
            this.btn_buscar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_buscar.Location = new System.Drawing.Point(576, 121);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(110, 48);
            this.btn_buscar.TabIndex = 21;
            this.btn_buscar.Text = "BUSCAR";
            this.btn_buscar.UseVisualStyleBackColor = false;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.Silver;
            this.btn_volver.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_volver.Location = new System.Drawing.Point(840, 506);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(110, 48);
            this.btn_volver.TabIndex = 20;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_nombre.Location = new System.Drawing.Point(116, 264);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(18, 26);
            this.lbl_nombre.TabIndex = 22;
            this.lbl_nombre.Text = ".";
            this.lbl_nombre.Click += new System.EventHandler(this.lbl_nombre_Click);
            // 
            // lbl_categoria
            // 
            this.lbl_categoria.AutoSize = true;
            this.lbl_categoria.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_categoria.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_categoria.Location = new System.Drawing.Point(116, 311);
            this.lbl_categoria.Name = "lbl_categoria";
            this.lbl_categoria.Size = new System.Drawing.Size(18, 26);
            this.lbl_categoria.TabIndex = 23;
            this.lbl_categoria.Text = ".";
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackColor = System.Drawing.Color.Silver;
            this.btn_eliminar.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_eliminar.Location = new System.Drawing.Point(728, 121);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(110, 48);
            this.btn_eliminar.TabIndex = 24;
            this.btn_eliminar.Text = "ELIMINAR";
            this.btn_eliminar.UseVisualStyleBackColor = false;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // pcb_bici
            // 
            this.pcb_bici.Image = global::LISTAS_NODO_DOBLE.Properties.Resources.BICIDE_LOS_HUAQUITA;
            this.pcb_bici.Location = new System.Drawing.Point(706, 205);
            this.pcb_bici.Name = "pcb_bici";
            this.pcb_bici.Size = new System.Drawing.Size(244, 184);
            this.pcb_bici.TabIndex = 25;
            this.pcb_bici.TabStop = false;
            this.pcb_bici.Visible = false;
            // 
            // BUSCARCICLISTA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1002, 566);
            this.Controls.Add(this.pcb_bici);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lbl_categoria);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.txt_numBici);
            this.Controls.Add(this.lbl_numBici);
            this.Name = "BUSCARCICLISTA";
            this.Text = "BUSCARCICLISTA";
            this.Load += new System.EventHandler(this.BUSCARCICLISTA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_bici)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_numBici;
        private System.Windows.Forms.Label lbl_numBici;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_categoria;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.PictureBox pcb_bici;
    }
}