﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTAS_NODO_DOBLE
{
    public partial class MostrarCiclista : Form
    {
        public MostrarCiclista()
        {
            InitializeComponent();
        }
        public void mostrarinicio()
        {
            NodoDoble punt = estatica.ciclistaLista.getCabezaCI();
            while (punt != null)
            {
                dgv_mostrarciclista.Rows.Add(punt.getNombreCiclista(), punt.getNumBici(), punt.getCategoria());
                punt = punt.getSiguiente();
            }
        }
        public void mostrarFinal()
        {
            NodoDoble punt = estatica.ciclistaLista.getNuevoCI();
            while (punt!=null)
            {
                dgv_mostrarciclista.Rows.Add(punt.getNombreCiclista(),punt.getNumBici(),punt.getCategoria());
                punt = punt.getAnterior();
                
            }
        }

        private void btn_MOSTRARI_Click(object sender, EventArgs e)
        {
            if(estatica.ciclistaLista.getCabezaCI()==null)
            {
                MessageBox.Show("NO HAY DATOS EN LA LISTA");
            }
            else
            {
                dgv_mostrarciclista.Rows.Clear();
                mostrarinicio();
                
            }
        }

        private void dgv_mostrarciclista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_mostrarf_Click(object sender, EventArgs e)
        {
            if (estatica.ciclistaLista.getCabezaCI() == null)
            {
                MessageBox.Show("NO HAY DATOS EN LA LISTA");
            }
            else
            {
                dgv_mostrarciclista.Rows.Clear();
                mostrarFinal();

            }
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_COMPETIDOR principal = new frm_COMPETIDOR();
            this.Hide();
            principal.Show();
        }

        private void MostrarCiclista_Load(object sender, EventArgs e)
        {

        }
    }
}
