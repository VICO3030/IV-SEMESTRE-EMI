﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_NODO_DOBLE
{
    class Lista_doble
    {
        NodoDoble cabezaCi, nuevoCi;//PARA EL CICLISTA
        public Lista_doble()
        {
            this.cabezaCi = null;
            this.nuevoCi = null;
        }
        public NodoDoble getCabezaCI()
            { return this.cabezaCi; }
        public NodoDoble getNuevoCI()
        { return this.nuevoCi; }
        public void crearCiclista(int num,string nom,string cat)
        {
            nuevoCi=new NodoDoble();
            nuevoCi.setNombreCiclista(nom);
            nuevoCi.setCategoria(cat);
            nuevoCi.setNumBici(num);
            nuevoCi.setAnterior(null);
            nuevoCi.setSiguiente(null);
        } 
        public string registrarLista(int num, string nom, string cat)
        {
            crearCiclista(num, nom, cat);
            if(cabezaCi==null)
            {
                cabezaCi=nuevoCi;
            }
            else
            {
                NodoDoble punt = cabezaCi;
                while (punt.getSiguiente() != null)
                {
                    punt = punt.getSiguiente();                                    
                }
                punt.setSiguiente(nuevoCi);
                nuevoCi.setAnterior(punt);
            }
            return "SE REGISTRO CON EXITO"; 
        }
        public NodoDoble buscarCiclista(int num)
        {
            NodoDoble punt = cabezaCi;
            while (punt != null)
            {
                if (punt.getNumBici() == num)
                {
                    return punt;
                }
                punt = punt.getSiguiente();
            }
            return punt;
        }
        public void ordenarCiclista()
        {
            NodoDoble punt = cabezaCi;
            NodoDoble aux ;
            int num;
            string nom, cat;
            
            while (punt != null)
            {
                aux = punt.getSiguiente();
                while (aux != null)
                {
                    if (aux.getNumBici() < punt.getNumBici())
                    {
                        num=aux.getNumBici();
                        aux.setNumBici(punt.getNumBici());
                        punt.setNumBici(num);

                        nom = aux.getNombreCiclista();
                        aux.setNombreCiclista(punt.getNombreCiclista());
                        punt.setNombreCiclista(nom);

                        cat = aux.getCategoria();
                        aux.setCategoria(punt.getCategoria());
                        punt.setCategoria(cat);

                    }
                    aux = aux.getSiguiente();
                }
                punt = punt.getSiguiente();
            }
        }

        public string eliminar(int num)
        {
            NodoDoble punt = cabezaCi;
            NodoDoble anterior=punt;
            if (cabezaCi.getNumBici() == num)
            {
                cabezaCi = cabezaCi.getSiguiente();
                if(cabezaCi!=null)
                {
                    cabezaCi.setAnterior(null);
                }
                punt.setSiguiente(null);
                return "SE ELIMINO CON EXITO";
            }
            else 
            {
                while (punt.getSiguiente() != null)
                {
                    if (punt.getNumBici() == num)
                    {
                        anterior.setSiguiente(punt.getSiguiente());
                        punt.getSiguiente().setAnterior(anterior);
                        return "SE ELIMINO CON EXITO";
                    }
                    anterior = punt;
                    punt = punt.getSiguiente();
                    
                }
            }
            if (punt.getNumBici() == num)
            {
                anterior.setSiguiente(null);
                punt.setAnterior(null);
                return "SE ELIMINO CON EXITO";
            }
            return "NO SE ELIMINO";

        }

    }
}
