﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTAS_NODO_DOBLE
{
    class ListaCarrera
    {
        NodoCarrera cabezaCa, nuevoCa;
        public ListaCarrera()
        {
            this.cabezaCa = null;
            this.nuevoCa = null;
        }
        public NodoCarrera getCabezaCa()
        {
            return this.cabezaCa;
        }
        public NodoCarrera getNuevoCa()
        {
            return nuevoCa;
        }

        public void crearCarrera(int num, float tiem,DateTime date)
        {
            nuevoCa = new NodoCarrera();
            nuevoCa.setNumBici(num);
            nuevoCa.setTiempo(tiem);
            nuevoCa.setDate(date);
            nuevoCa.setAnterior(null);
            nuevoCa.setSiguiente(null);
        }
        public string registrarCarrera(int num, float tiem, DateTime date)
        {
            crearCarrera(num , tiem, date);
            if (cabezaCa == null)
            {
                cabezaCa = nuevoCa;
            }
            else
            {
                NodoCarrera punt = cabezaCa;
                while (punt.getSiguiente() != null)
                {
                    punt = punt.getSiguiente();
                }
                punt.setSiguiente(nuevoCa);
                nuevoCa.setAnterior(punt);
            }
            return "SE REGISTRO CON EXITO";
        }
        public NodoCarrera buscarCarrera(int num)
        {
            NodoCarrera punt = cabezaCa;
            while (punt != null)
            {
                if (punt.getNumBici() == num)
                {
                    return punt;
                }
                punt = punt.getSiguiente();
            }
            return punt;
        }

        public void ordenarinsercion()
        {
            NodoCarrera j = cabezaCa.getSiguiente();
            NodoCarrera i; 
            while (j!= null)
            {
                float tiempo = j.getTiempo();
                i= j.getAnterior();
                while (i != null && (i.getTiempo() > tiempo))
                {
                   
                    float aux = i.getSiguiente().getTiempo();
                    i.getSiguiente().setTiempo(i.getTiempo());
                    i.setTiempo(aux);
                    

                    DateTime aux2= i.getSiguiente().getDate();
                    i.getSiguiente().setDate(i.getDate());
                    i.setDate(aux2);

                    int aux3= i.getSiguiente().getLugar();
                    i.getSiguiente().setLugar(i.getLugar());
                    i.setLugar(aux3);

                    int aux4 = i.getSiguiente().getNumBici();
                    i.getSiguiente().setNumBici(i.getNumBici());
                    i.setNumBici(aux4);
                    i = i.getAnterior();
                }
                /*
                if (i== null)
                {
                    aux = j;
                    NodoCarrera siguiente = j.getSiguiente();
                    NodoCarrera anterior = j.getAnterior();
                    anterior.setSiguiente(siguiente);
                    if (siguiente != null)
                    {
                        siguiente.setAnterior(anterior);
                    }
                    aux.setAnterior(null);
                    aux.setSiguiente(cabezaCa);
                    cabezaCa = aux;

                }
                else
                {
                    if(i.getTiempo() > tiempo)
                    {
                        NodoCarrera siguiente = j.getSiguiente();
                        NodoCarrera anterior = j.getAnterior();
                        anterior.setSiguiente(siguiente);
                        if (siguiente != null)
                        {
                            siguiente.setAnterior(anterior);
                        }
                        i.getSiguiente().setAnterior(j);
                        i.setSiguiente(j);
                    }
                    
                }*/
                j = j.getSiguiente();
            }

        }
        public string eliminarCa(float num)
        {
            NodoCarrera punt = cabezaCa;
            NodoCarrera anterior = punt;
            if (cabezaCa.getNumBici() == num)
            {
                cabezaCa = cabezaCa.getSiguiente();
                if (cabezaCa != null)
                {
                    cabezaCa.setAnterior(null);
                }
                punt.setSiguiente(null);
                return "SE ELIMINO CON EXITO";
            }
            else
            {
                while (punt.getSiguiente() != null)
                {
                    if (punt.getNumBici() == num)
                    {
                        anterior.setSiguiente(punt.getSiguiente());
                        punt.getSiguiente().setAnterior(anterior);
                        punt.setSiguiente(null);
                        punt.setAnterior(null);
                        return "SE ELIMINO CON EXITO";
                    }
                    anterior = punt;
                    punt = punt.getSiguiente();

                }
            }
            if (punt.getNumBici() == num)
            {
                anterior.setSiguiente(null);
                punt.setAnterior(null);
                return "SE ELIMINO CON EXITO";
            }
            return "NO SE ELIMINO";

        }
    }
}
