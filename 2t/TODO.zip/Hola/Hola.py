from ast import keyword
from asyncio import events
from multiprocessing import _EventType
from tkinter import Event, EventType


for i in range(1,4,2):
    print("HOLA MUNDO\n")

while True:
    print("jiji")
    if EventType.Key=="Enter":
        break
