﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pila_EJERCICIO2
{
    class NodoPila
    {
        int num;
        float precio;
        string descripcion;
        int stock;
        NodoPila enlace;//Direccion del nodo con el que se enlasa
        public NodoPila()
        {
            num = 0;
            stock = 0;
            precio = 0;
            descripcion = "  ";
            enlace = null;
        }

        public void setNum(int n)
        {
            this.num = n;
        }
        public void setStock(int a)
        {
            stock= a;
        }
        public void setPrecio(float n)
        {
            precio = n;
        }
        public void setDesc(string d)
        {
            descripcion = d;
        }
        public void setEnlace(NodoPila punt)
        {
            enlace = punt;
        }

        public int getNum()
        {
            return num;
        }
        public int getStock()
        {
            return stock;
        }
        public float getPrecio()
        {
            return precio;
        }
        public string getDesc()
        {
            return descripcion;

        }
        public NodoPila getEnlace()
        {
            return enlace;
        }
    }
}
