﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pila_EJERCICIO2
{
    public partial class lbl_stock : Form
    {
        PILA arti, compra, aux;
        public lbl_stock()
        {
            InitializeComponent();
            arti=new PILA();
            compra=new PILA(); 
            aux=new PILA();
        }
        private void mostrar()
        {
            NodoPila punt;
            dgv_registro.Rows.Clear();
            while (arti.getTope() != null)
            {

                punt = arti.desapilar();
                dgv_registro.Rows.Add(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(),punt.getDesc()) ;
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                arti.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
        }
        private void mostrarc()
        {
            NodoPila punt;
            dgv_compras.Rows.Clear();
            while (compra.getTope() != null)
            {

                punt = compra.desapilar();
                dgv_compras.Rows.Add(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                compra.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
        }
        private NodoPila buscar(int n,int nn,float p,string d)
        {
            NodoPila punt = arti.getTope();
            NodoPila l = null;
            if(punt.getNum()==n)
            {
                punt = arti.desapilar();
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            while (arti.getTope() != null && punt.getNum() != n)
            {

                punt = arti.desapilar();
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());

            }
            if (punt.getNum() != n)
            {
            }
            else
            {
                l=punt;
                
                punt = aux.desapilar();
                punt.setStock(nn + punt.getStock());

                punt.setPrecio(p);
                punt.setDesc(d);
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                arti.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            return l;
        }
        private NodoPila buscarxd(int n)
        {
            NodoPila punt = arti.getTope();
            NodoPila l = null;
            if (punt.getNum() == n)
            {
                punt = arti.desapilar();
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            while (arti.getTope() != null && punt.getNum() != n)
            {

                punt = arti.desapilar();
                aux.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());

            }
            if (punt.getNum() != n)
            {
            }
            else
            {
                l = punt;
            }
            while (aux.getTope() != null)
            {

                punt = aux.desapilar();
                arti.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
            }
            return l;
        }

        private void brn_eliminar_Click(object sender, EventArgs e)
        {
            int n=int.Parse(txt_cod.Text);
            int s = int.Parse(txt_stock.Text);
            float p = int.Parse(txt_precio.Text);
            string d = txt_descripcion.Text;
            arti.apilar(n, s, p, d);
            txt_descripcion.Text = " ";
            txt_precio.Text = " ";
            txt_stock.Text = " ";
            mostrar();
        }

        private void lbl_stock_Load(object sender, EventArgs e)
        {

        }

        private void dgv_registro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_cod_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_cod_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                NodoPila h = buscarxd(int.Parse(txt_cod.Text));
               if (h!=null)
                {
                    txt_descripcion.Text = h.getDesc();
                    txt_precio.Text = h.getPrecio().ToString();
                    txt_stock.Text=h.getStock().ToString();

                }
               else
                {
                    txt_descripcion.Text = " ";
                    txt_precio.Text = " ";
                    txt_stock.Text = " ";
                }
            }
        }

        private void btn_comprar_Click(object sender, EventArgs e)
        {
            int n = int.Parse(txt_cod.Text);
            int s = int.Parse(txt_stock.Text);
            float p = int.Parse(txt_precio.Text);
            string d = txt_descripcion.Text;
            compra.apilar(n, s, p, d);
            mostrarc();

        }

        private void btn_anadir_Click(object sender, EventArgs e)
        {
            NodoPila punt;
            while (compra.getTope() != null)
            {

                punt = compra.desapilar();
                NodoPila bus = buscar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
                if (bus==null)
                {
                    arti.apilar(punt.getNum(), punt.getStock(), punt.getPrecio(), punt.getDesc());
                }
                else
                {
                    /*
                    int n = bus.getStock();
                    MessageBox.Show(n.ToString()+"  +  "+ punt.getStock().ToString());
                    bus.setStock(n + punt.getStock());
                    MessageBox.Show(bus.getStock().ToString());*/
                }
                
            }
            
            mostrarc();
            mostrar();
        }

    }
}
