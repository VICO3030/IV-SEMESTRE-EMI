﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pila_EJERCICIO2
{
    class PILA
    {
        NodoPila nuevo, tope;
        public PILA()
        {
            tope = null;
            nuevo = null;
        }
        public void crearNodo(int n,int s,float p,string d)
        {
            nuevo = new NodoPila();
            nuevo.setNum(n);
            nuevo.setStock(s);
            nuevo.setPrecio(p);
            nuevo.setDesc(d);
            nuevo.setEnlace(null);

        }
        public string apilar(int n, int s, float p, string d)
        {
            crearNodo(n,s,p,d);
            nuevo.setEnlace(tope);
            tope = nuevo;
            return ("SE APILA CON EXITO");
        }
        public NodoPila desapilar()
        {
            NodoPila aux = tope;
            tope = tope.getEnlace();
            aux.setEnlace(null);
            return (aux);
        }
        public NodoPila getTope()
        {
            return tope;
        }
        public bool estaVacio()
        {
            return tope == null;//si esta vacio devuelve verdadero
        }
    }
}
