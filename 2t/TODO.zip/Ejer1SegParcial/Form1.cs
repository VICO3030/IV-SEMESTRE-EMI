﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer1SegParcial
{
    public partial class Form1 : Form
    {
        Pila p, aux, pri;
        public Form1()
        {
            p = new Pila();
            aux = new Pila();
            pri = new Pila();
            InitializeComponent();
        }

        private void btn_apilar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(p.apilar(int.Parse(txt_num.Text)));
            mostrar();
            
            
        }
        public void mostrar()
        {
            lst_lista1.Items.Clear();
            Nodo traspaso;
            while(p.getTope()!=null)
            {
                traspaso = p.desapilar();
                lst_lista1.Items.Add(traspaso.Num);
                aux.apilar(traspaso.Num);
            }
            while (aux.getTope() != null)
            {
                traspaso = aux.desapilar();
                p.apilar(traspaso.Num);
            }
            mostrarCantPrimos();
        }
        public void mostrarPrimos()
        {
            lst_lista2.Items.Clear();
            Nodo traspaso;
            while (pri.getTope() != null)
            {
                traspaso = pri.desapilar();
                lst_lista2.Items.Add(traspaso.Num);
                aux.apilar(traspaso.Num);
            }
            while (aux.getTope() != null)
            {
                traspaso = aux.desapilar();
                pri.apilar(traspaso.Num);
            }
        }
        public void mostrarCantPrimos()
        {
            Nodo traspaso;
            int cont = 0;
            while (p.getTope() != null)
            {
                
                traspaso = p.desapilar();
                if (esPrimo(traspaso.Num))
                {
                    cont++;
                }
                aux.apilar(traspaso.Num);
            }
            while (aux.getTope() != null)
            {
                traspaso = aux.desapilar();
                p.apilar(traspaso.Num);
            }
            lbl_numPrimos.Text = "CANTIDAD DE NUMEROS PRIMOS: " + cont;
        }

        private void btn_desapilar_Click(object sender, EventArgs e)
        {
            desapilarPrimos();
            mostrar();
            mostrarPrimos();
        }

        public bool esPrimo(int num)
        {
            for(int i=2;i<num;i++)
            {
                if(num%i==0)
                {
                    return false;
                }
            }
            return true;
        }
        public void desapilarPrimos()
        {
            Nodo traspaso;
            while (p.getTope() != null)
            {
                traspaso = p.desapilar();
                if (esPrimo(traspaso.Num))
                {
                    pri.apilar(traspaso.Num);
                }
                else
                {
                    aux.apilar(traspaso.Num);
                } 
            }
            while (aux.getTope() != null)
            {
                traspaso = aux.desapilar();
                p.apilar(traspaso.Num);
            }
        }
    }
}
