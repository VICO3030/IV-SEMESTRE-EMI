﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer1SegParcial
{
    class Pila
    {

        Nodo nuevo, tope;
        public Pila()
        {
            tope = null;
            nuevo = null;
        }
        public void crearNodo(int n)
        {
            nuevo = new Nodo();
            nuevo.Num=n;
            nuevo.Enlace=null;

        }
        public string apilar(int n)
        {
            crearNodo(n);
            nuevo.Enlace=tope;
            tope = nuevo;
            return ("SE APILA CON EXITO");
        }
        public Nodo desapilar()
        {
            Nodo aux = tope;
            tope = tope.Enlace;
            aux.Enlace=null;
            return (aux);
        }
        public Nodo getTope()
        {
            return tope;
        }
        public bool estaVacio()
        {
            return tope == null;//si esta vacio devuelve verdadero
        }
    }
}
