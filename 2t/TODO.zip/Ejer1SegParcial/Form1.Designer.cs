﻿namespace Ejer1SegParcial
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_num = new System.Windows.Forms.Label();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lst_lista1 = new System.Windows.Forms.ListBox();
            this.btn_apilar = new System.Windows.Forms.Button();
            this.lst_lista2 = new System.Windows.Forms.ListBox();
            this.btn_desapilar = new System.Windows.Forms.Button();
            this.lbl_numPrimos = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Maiandra GD", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(261, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(269, 51);
            this.lbl_titulo.TabIndex = 32;
            this.lbl_titulo.Text = "EJERCICIO 1";
            // 
            // lbl_num
            // 
            this.lbl_num.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num.Location = new System.Drawing.Point(30, 122);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(235, 37);
            this.lbl_num.TabIndex = 33;
            this.lbl_num.Text = "INGRESE EL NUMERO:";
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num.Location = new System.Drawing.Point(258, 122);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(100, 36);
            this.txt_num.TabIndex = 34;
            // 
            // lst_lista1
            // 
            this.lst_lista1.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista1.ItemHeight = 27;
            this.lst_lista1.Location = new System.Drawing.Point(75, 247);
            this.lst_lista1.Name = "lst_lista1";
            this.lst_lista1.Size = new System.Drawing.Size(245, 139);
            this.lst_lista1.TabIndex = 35;
            // 
            // btn_apilar
            // 
            this.btn_apilar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_apilar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_apilar.Location = new System.Drawing.Point(415, 111);
            this.btn_apilar.Name = "btn_apilar";
            this.btn_apilar.Size = new System.Drawing.Size(149, 55);
            this.btn_apilar.TabIndex = 36;
            this.btn_apilar.Text = "APILAR";
            this.btn_apilar.UseVisualStyleBackColor = false;
            this.btn_apilar.Click += new System.EventHandler(this.btn_apilar_Click);
            // 
            // lst_lista2
            // 
            this.lst_lista2.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_lista2.ItemHeight = 27;
            this.lst_lista2.Location = new System.Drawing.Point(462, 247);
            this.lst_lista2.Name = "lst_lista2";
            this.lst_lista2.Size = new System.Drawing.Size(245, 139);
            this.lst_lista2.TabIndex = 37;
            // 
            // btn_desapilar
            // 
            this.btn_desapilar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_desapilar.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_desapilar.Location = new System.Drawing.Point(515, 414);
            this.btn_desapilar.Name = "btn_desapilar";
            this.btn_desapilar.Size = new System.Drawing.Size(149, 77);
            this.btn_desapilar.TabIndex = 38;
            this.btn_desapilar.Text = "DESAPILAR PRIMOS";
            this.btn_desapilar.UseVisualStyleBackColor = false;
            this.btn_desapilar.Click += new System.EventHandler(this.btn_desapilar_Click);
            // 
            // lbl_numPrimos
            // 
            this.lbl_numPrimos.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numPrimos.Location = new System.Drawing.Point(30, 192);
            this.lbl_numPrimos.Name = "lbl_numPrimos";
            this.lbl_numPrimos.Size = new System.Drawing.Size(338, 37);
            this.lbl_numPrimos.TabIndex = 39;
            this.lbl_numPrimos.Text = "CANTIDAD DE NUMEROS PRIMOS:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 522);
            this.Controls.Add(this.lbl_numPrimos);
            this.Controls.Add(this.btn_desapilar);
            this.Controls.Add(this.lst_lista2);
            this.Controls.Add(this.btn_apilar);
            this.Controls.Add(this.lbl_num);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.lst_lista1);
            this.Controls.Add(this.lbl_titulo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.ListBox lst_lista1;
        private System.Windows.Forms.Button btn_apilar;
        private System.Windows.Forms.ListBox lst_lista2;
        private System.Windows.Forms.Button btn_desapilar;
        private System.Windows.Forms.Label lbl_numPrimos;
    }
}

