﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_aplicacion_2
{
    class Estatica
    {
        public static ColaImp Impresiones = new ColaImp();
    }
}
