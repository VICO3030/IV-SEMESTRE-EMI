﻿
namespace Ejercicio_aplicacion_2
{
    partial class frm_principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_encolar_impresion = new System.Windows.Forms.Button();
            this.cmb_opciones = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_salir = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.txt_hojas = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_hojas);
            this.groupBox1.Controls.Add(this.btn_encolar_impresion);
            this.groupBox1.Controls.Add(this.cmb_opciones);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(142, 118);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btn_encolar_impresion
            // 
            this.btn_encolar_impresion.Location = new System.Drawing.Point(9, 89);
            this.btn_encolar_impresion.Name = "btn_encolar_impresion";
            this.btn_encolar_impresion.Size = new System.Drawing.Size(121, 23);
            this.btn_encolar_impresion.TabIndex = 1;
            this.btn_encolar_impresion.Text = "Mandar Impresion";
            this.btn_encolar_impresion.UseVisualStyleBackColor = false;
            this.btn_encolar_impresion.Click += new System.EventHandler(this.btn_encolar_impresion_Click);
            // 
            // cmb_opciones
            // 
            this.cmb_opciones.FormattingEnabled = true;
            this.cmb_opciones.Items.AddRange(new object[] {
            "Borrador y color",
            "Borrador y negro_gris",
            "Estandar y color",
            "Estandar y negro_gris",
            "Alto y color",
            "Alto y negro_gris"});
            this.cmb_opciones.Location = new System.Drawing.Point(9, 38);
            this.cmb_opciones.Name = "cmb_opciones";
            this.cmb_opciones.Size = new System.Drawing.Size(121, 21);
            this.cmb_opciones.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Elija opcion de impresion:";
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(6, 65);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(75, 23);
            this.btn_salir.TabIndex = 1;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_mostrar);
            this.groupBox2.Controls.Add(this.btn_salir);
            this.groupBox2.Location = new System.Drawing.Point(162, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(92, 100);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Opciones";
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(6, 17);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(75, 23);
            this.btn_mostrar.TabIndex = 2;
            this.btn_mostrar.Text = "Mostrar ";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // txt_hojas
            // 
            this.txt_hojas.Location = new System.Drawing.Point(9, 63);
            this.txt_hojas.Name = "txt_hojas";
            this.txt_hojas.Size = new System.Drawing.Size(100, 20);
            this.txt_hojas.TabIndex = 3;
            this.txt_hojas.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // frm_principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 143);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_principal";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_encolar_impresion;
        private System.Windows.Forms.ComboBox cmb_opciones;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.TextBox txt_hojas;
    }
}

