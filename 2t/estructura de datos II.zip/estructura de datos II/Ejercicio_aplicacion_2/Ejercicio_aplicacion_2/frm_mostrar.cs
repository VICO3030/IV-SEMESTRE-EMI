﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_aplicacion_2
{
   
    public partial class frm_mostrar : Form
    {
        NodoImp aux;
        public frm_mostrar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mostrar()
        {
            dgv_cola.Rows.Clear();
            NodoImp punt = Estatica.Impresiones.get_frente();
            while(punt != null)
            {
                dgv_cola.Rows.Add(punt.get_opcion(), punt.get_hojas(),"en espera");
                punt = punt.get_sig();
            }
        }
        private void frm_mostrar_Load(object sender, EventArgs e)
        {
            mostrar();
        }
        private void tmr_impresion_Tick(object sender, EventArgs e)
        {
            

                
                if (pgbr_estado.Value != Estatica.Impresiones.get_tam())
                {
                    double auz = (double)1000 * Estatica.Impresiones.get_frente().get_tmp();
                    tmr_impresion.Interval = (int)auz;

                    pgbr_estado.Value++;
                    aux = Estatica.Impresiones.desencolar();
                    dgv_impresos.Rows.Add(aux.get_opcion(), aux.get_hojas(), "impreso");

                }
                else
                {
                    tmr_impresion.Stop();
                }
            
        }

        private void btn_imprimir_Click(object sender, EventArgs e)
        {
            double a = (double)1000 * Estatica.Impresiones.get_frente().get_tmp();
            tmr_impresion.Enabled = true;
            tmr_impresion.Start();
            tmr_impresion.Interval = (int)a;
            pgbr_estado.Maximum = Estatica.Impresiones.get_tam();
            tmr_impresion.Tick += new EventHandler(tmr_impresion_Tick);
        }
    }
}
