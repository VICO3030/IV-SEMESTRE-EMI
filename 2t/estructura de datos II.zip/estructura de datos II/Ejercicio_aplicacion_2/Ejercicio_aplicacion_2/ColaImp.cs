﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_aplicacion_2
{
    class ColaImp
    {
		NodoImp frente, final, nuevo;
		int tam;
		//CONSTRUCTOR
		public ColaImp()
		{
			frente = null;
			final = null;
			nuevo = null;
			tam = 0;
		}
		//getters y setters
		public NodoImp get_frente() { return frente; }
		public NodoImp get_final() { return final; }
		public int get_tam() { return tam; }
		//metodos
		public void newNode(string opcion, int hojas)
		{
			nuevo = new NodoImp();
			nuevo.set_opcion(opcion);
			nuevo.set_hojas(hojas);
            
		}
		public void encolar(string opcion, int hojas)
		{
			newNode(opcion, hojas);
			if (frente == null) frente = nuevo;
			else final.set_sig(nuevo);
			final = nuevo;
			tam++;
		}
		public NodoImp desencolar()
		{
			NodoImp aux;
			aux = frente;
			frente = frente.get_sig();
			aux.set_sig(null);
			tam--;
			return aux;
		}
	}
}
