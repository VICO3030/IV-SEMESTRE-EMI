﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_aplicacion_2
{
    public partial class frm_principal : Form
    {
        double tempo = 0;
        public frm_principal()
        {
            InitializeComponent();
        }

        private void btn_encolar_impresion_Click(object sender, EventArgs e)
        {
            if (cmb_opciones.SelectedItem.ToString() == "") MessageBox.Show("Elija una opcion valida");
            else
            {
                String opcion = cmb_opciones.SelectedItem.ToString();
                Estatica.Impresiones.encolar(cmb_opciones.SelectedItem.ToString(), int.Parse(txt_hojas.Text));
                
                switch (opcion)
                {
                    case "Borrador y color":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.15;                        
                        break;
                    case "Borrador y negro_gris":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.5;
                        break;
                    case "Estandar y color":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.20;
                        break;
                    case "Estandar y negro_gris":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.18;
                        break;
                    case "Alto y color":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.30;
                        break;
                    case "Alto y negro_gris":
                        tempo += Convert.ToDouble(int.Parse(txt_hojas.Text)) * 0.25;
                        break;
                }
                Estatica.Impresiones.get_final().set_tmp(tempo);
                MessageBox.Show("Impresion agregada a la cola");
            }
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            if (Estatica.Impresiones.get_frente() != null)
            {
                frm_mostrar mostrar = new frm_mostrar();
                mostrar.Show();
            }
            else MessageBox.Show("Cola de impresion vacia");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
