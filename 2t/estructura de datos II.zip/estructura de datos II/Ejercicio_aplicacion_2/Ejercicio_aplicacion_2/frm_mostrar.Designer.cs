﻿
namespace Ejercicio_aplicacion_2
{
    partial class frm_mostrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgv_cola = new System.Windows.Forms.DataGridView();
            this.btn_salir = new System.Windows.Forms.Button();
            this.tmr_impresion = new System.Windows.Forms.Timer(this.components);
            this.pgbr_estado = new System.Windows.Forms.ProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgv_impresos = new System.Windows.Forms.DataGridView();
            this.btn_imprimir = new System.Windows.Forms.Button();
            this.clmn_tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_hojas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmn_hojas_imp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cola)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_impresos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgv_cola);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(257, 187);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COLA DE IMPRESION";
            // 
            // dgv_cola
            // 
            this.dgv_cola.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cola.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmn_tipo,
            this.clmn_hojas,
            this.clmn_estado});
            this.dgv_cola.Location = new System.Drawing.Point(7, 20);
            this.dgv_cola.Name = "dgv_cola";
            this.dgv_cola.ReadOnly = true;
            this.dgv_cola.Size = new System.Drawing.Size(240, 150);
            this.dgv_cola.TabIndex = 0;
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(458, 228);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(75, 23);
            this.btn_salir.TabIndex = 1;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.button1_Click);
            // 
            // tmr_impresion
            // 
            this.tmr_impresion.Tick += new System.EventHandler(this.tmr_impresion_Tick);
            // 
            // pgbr_estado
            // 
            this.pgbr_estado.Location = new System.Drawing.Point(20, 228);
            this.pgbr_estado.Name = "pgbr_estado";
            this.pgbr_estado.Size = new System.Drawing.Size(432, 23);
            this.pgbr_estado.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgv_impresos);
            this.groupBox2.Location = new System.Drawing.Point(276, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(257, 187);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DOCUMENTOS IMPRESOS";
            // 
            // dgv_impresos
            // 
            this.dgv_impresos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_impresos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.clmn_hojas_imp,
            this.dataGridViewTextBoxColumn2});
            this.dgv_impresos.Location = new System.Drawing.Point(6, 20);
            this.dgv_impresos.Name = "dgv_impresos";
            this.dgv_impresos.ReadOnly = true;
            this.dgv_impresos.Size = new System.Drawing.Size(240, 150);
            this.dgv_impresos.TabIndex = 1;
            // 
            // btn_imprimir
            // 
            this.btn_imprimir.Location = new System.Drawing.Point(458, 206);
            this.btn_imprimir.Name = "btn_imprimir";
            this.btn_imprimir.Size = new System.Drawing.Size(75, 23);
            this.btn_imprimir.TabIndex = 3;
            this.btn_imprimir.Text = "Imprimir";
            this.btn_imprimir.UseVisualStyleBackColor = true;
            this.btn_imprimir.Click += new System.EventHandler(this.btn_imprimir_Click);
            // 
            // clmn_tipo
            // 
            this.clmn_tipo.HeaderText = "Tipo";
            this.clmn_tipo.Name = "clmn_tipo";
            this.clmn_tipo.ReadOnly = true;
            // 
            // clmn_hojas
            // 
            this.clmn_hojas.HeaderText = "nro hojas";
            this.clmn_hojas.Name = "clmn_hojas";
            this.clmn_hojas.ReadOnly = true;
            // 
            // clmn_estado
            // 
            this.clmn_estado.HeaderText = "Estado";
            this.clmn_estado.Name = "clmn_estado";
            this.clmn_estado.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Tipo";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // clmn_hojas_imp
            // 
            this.clmn_hojas_imp.HeaderText = "nro hojas";
            this.clmn_hojas_imp.Name = "clmn_hojas_imp";
            this.clmn_hojas_imp.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Estado";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // frm_mostrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 263);
            this.Controls.Add(this.btn_imprimir);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pgbr_estado);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_mostrar";
            this.Text = "frm_mostrar";
            this.Load += new System.EventHandler(this.frm_mostrar_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cola)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_impresos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Timer tmr_impresion;
        private System.Windows.Forms.ProgressBar pgbr_estado;
        private System.Windows.Forms.DataGridView dgv_cola;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgv_impresos;
        private System.Windows.Forms.Button btn_imprimir;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_hojas;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_estado;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmn_hojas_imp;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}