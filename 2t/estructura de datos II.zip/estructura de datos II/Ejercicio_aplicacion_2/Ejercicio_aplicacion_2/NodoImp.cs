﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_aplicacion_2
{
    class NodoImp
    {
        string opcion;
        NodoImp siguiente;
        int hojas;
        double tiempo;

        public NodoImp()
        {
            opcion = "";
            siguiente = null;
            hojas = 0;
            tiempo = 0;
        }
        //getters y setters
        public string get_opcion() { return opcion; }
        public NodoImp get_sig() { return siguiente; }
        public double get_tmp() { return tiempo; }
        public int get_hojas() { return hojas; }
        public void set_opcion(string opcion) { this.opcion = opcion; }
        public void set_sig(NodoImp siguiente) { this.siguiente = siguiente; }
        public void set_tmp(double tiempo) { this.tiempo = tiempo; }
        public void set_hojas(int hojas) { this.hojas = hojas; }
    }
}
