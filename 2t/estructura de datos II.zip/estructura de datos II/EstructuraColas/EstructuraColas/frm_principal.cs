﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstructuraColas
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            if(Static.cola.get_frente() == null)
            {
                MessageBox.Show("Cola Vacia");
            }
            else
            {
                frm_mostrar mostrar = new frm_mostrar();
                mostrar.Show();
            }
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void encolar(int num)
        {
            Static.cola.encolar(num);
        }
        private void btn_encolar_Click(object sender, EventArgs e)
        {
            if (txt_dato.Text != "")
            {
                encolar(int.Parse(txt_dato.Text));
                MessageBox.Show("Dato Ingresado");
                txt_dato.Clear();
            }
            else MessageBox.Show("Invalido");
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (Static.cola.get_frente() == null) MessageBox.Show("Cola Vacia");
            else
            {
                Static.cola.desencolar();
                MessageBox.Show("Dato Desencolado");
            }
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frm_buscar buscar = new frm_buscar();
            buscar.Show();
        }
    }
}
