﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraColas
{
    class NodoC
    {
        int num;
        NodoC siguiente;

        //CONSTRUCTOR
        public NodoC()
        {
            num = 0;
            siguiente = null;
        }
        //Getters y Setters
        public int get_num() { return num; }
        public NodoC get_sig() { return siguiente; }
        public void set_num(int num) { this.num = num; }
        public void set_sig(NodoC siguiente) { this.siguiente = siguiente; }
    }
}
