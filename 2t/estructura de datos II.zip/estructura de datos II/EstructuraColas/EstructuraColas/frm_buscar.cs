﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstructuraColas
{
    public partial class frm_buscar : Form
    {
        NodoC encontrado = null;
        private NodoC buscar(int num)
        {
            NodoC punt = Static.cola.get_frente();
            while (punt != null)
            {
                if (punt.get_num() == num) return punt;
                punt = punt.get_sig();
            }
            return null;
        }
        public frm_buscar()
        {
            InitializeComponent();

        }
        
        private void btn_buscar_Click(object sender, EventArgs e)
        {
            encontrado = buscar(int.Parse(txt_dato.Text));
            if (encontrado == null) MessageBox.Show("Dato Inexistente");
            else
            {
                MessageBox.Show("Dato Encontrado;");
                lbl_dato.Text = encontrado.get_num().ToString();
                grp_edicion.Visible = true;
            }
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void eliminar(int num)
        {
            NodoC anterior = Static.cola.get_frente(), actual = anterior.get_sig();

            while(actual != null)
            {
                if (actual.get_num() == num) break;
                anterior = actual;
                actual = actual.get_sig();
            }

            anterior.set_sig(actual.get_sig());
            actual.set_sig(null);
        }
        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            eliminar(encontrado.get_num());
            MessageBox.Show("Dato Eliminado");
        }
    }
}
