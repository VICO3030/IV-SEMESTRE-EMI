﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraColas
{
    class Cola
    {
        NodoC frente, final, nuevo;
        //CONSTRUCTOR
        public Cola()
        {
            frente = null;
            final = null;
            nuevo = null;
        }
        //getters y setters
        public NodoC get_frente() { return frente; }
        public NodoC get_final() { return final; }
        //metodos
        public void newNode(int num)
        {
            nuevo = new NodoC();
            nuevo.set_num(num);
        }
        public void encolar(int num)
        {
            newNode(num);
            if (frente == null) frente = nuevo;
            else final.set_sig(nuevo);
            final = nuevo;
        }
        public NodoC desencolar() {
            NodoC aux;
            aux = frente;
            frente = frente.get_sig();
            aux.set_sig(null);
            return aux;
        }
    }
}
