﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstructuraColas
{
    public partial class frm_mostrar : Form
    {
        public frm_mostrar()
        {
            InitializeComponent();
        }
        public void mostrar()
        {
            lst_mostrar.Items.Clear();
            NodoC punt = Static.cola.get_frente();
            while(punt != null)
            {
                lst_mostrar.Items.Add(punt.get_num());
                punt = punt.get_sig();
            }
        }
        private void frm_mostrar_Load(object sender, EventArgs e)
        {
            mostrar();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
