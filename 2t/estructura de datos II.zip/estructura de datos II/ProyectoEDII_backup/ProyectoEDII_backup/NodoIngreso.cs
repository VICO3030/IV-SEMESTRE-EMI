﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class NodoIngreso
    {
        int codigoEntrada;
        int ciCliente;
        
        NodoIngreso siguiente;

        public NodoIngreso(int codigoEntrada = 0, int ciCliente = 0, NodoIngreso siguiente = null)
        {
            this.codigoEntrada = codigoEntrada;
            this.ciCliente = ciCliente;
            this.siguiente = siguiente;
        }
        
        public int CodigoEntrada { get => codigoEntrada; set => codigoEntrada = value; }
        public int CiCliente { get => ciCliente; set => ciCliente = value; }
        public NodoIngreso Siguiente { get => siguiente; set => siguiente = value; }
    }
}
