﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoEDII_backup
{
    public partial class frm_login : Form
    {
        private string usuario = "conejo arce";
        private string pasword = "123456789";
        public frm_login()
        {
            InitializeComponent();
        }
        private void inicioSesion(string user = "", string password = "")
        {
            if(this.usuario == user && this.pasword == password)
            {
                frm_principal principal = new frm_principal();
                MessageBox.Show("ACCESO CONCEDIDO");
                this.Hide();
                principal.Show();
            }
            else
            {
                MessageBox.Show("ACCESO DENEGADO");
                txt_password.Clear();
                txt_password.Clear();
            }
        }
        private void btn_iniciarSesion_Click(object sender, EventArgs e)
        {
            inicioSesion(txt_user.Text, txt_password.Text);
        }
    }
}
