﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class ListaIngreso
    {
        NodoIngreso cabeza;
        public ListaIngreso()
        {
            cabeza = null;
        }

        public void agregar(int codigo,int carnet)
        {
            NodoIngreso nuevo = new NodoIngreso(codigo, carnet);
            if (cabeza == null) cabeza = nuevo;
            else
            {
                NodoIngreso punt = cabeza;
                while(punt.Siguiente != null)
                {
                    punt = punt.Siguiente;
                }
                punt.Siguiente = nuevo;
            }
        }
        public NodoIngreso Cabeza { get => cabeza; set => cabeza = value; }
    }
}
