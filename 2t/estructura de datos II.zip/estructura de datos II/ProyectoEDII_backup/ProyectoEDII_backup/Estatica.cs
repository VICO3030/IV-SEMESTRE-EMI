﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class Estatica
    {
        public static ListaClientes clientes = new ListaClientes();
        public static ListaIngreso ingresados = new ListaIngreso();
        public static ColaVentas ventas = new ColaVentas();
        public static int E_butaca = 2;
        public static int E_curva = 2;
        public static int E_general = 2;
        public static int E_preferencia = 2;
    }
}
