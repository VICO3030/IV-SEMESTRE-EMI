﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class NodoCliente
    {
        string nombre;
        int carnet;
        NodoCliente siguiente;

        public NodoCliente(string nombre = "", int carnet = 0, NodoCliente siguiente = null)
        {
            this.nombre = nombre;
            this.carnet = carnet;
            this.siguiente = siguiente;
        }
        public string Nombre { get => nombre; set => nombre = value; }
        public int Carnet { get => carnet; set => carnet = value; }
        public NodoCliente Siguiente { get => siguiente; set => siguiente = value; }
    }
}
