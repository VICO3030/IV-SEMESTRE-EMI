﻿
namespace ProyectoEDII_backup
{
    partial class frm_reg_ven
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_cliente = new System.Windows.Forms.GroupBox();
            this.txt_ci = new System.Windows.Forms.TextBox();
            this.btn_reg_cli = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_compra = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nud_n_entradas = new System.Windows.Forms.NumericUpDown();
            this.txt_ci_busca = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_comprar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_sectores = new System.Windows.Forms.ComboBox();
            this.btn_volver = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nro_Entradas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grp_cliente.SuspendLayout();
            this.grp_compra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_n_entradas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // grp_cliente
            // 
            this.grp_cliente.Controls.Add(this.txt_ci);
            this.grp_cliente.Controls.Add(this.btn_reg_cli);
            this.grp_cliente.Controls.Add(this.label2);
            this.grp_cliente.Controls.Add(this.txt_nom);
            this.grp_cliente.Controls.Add(this.label1);
            this.grp_cliente.Location = new System.Drawing.Point(12, 12);
            this.grp_cliente.Name = "grp_cliente";
            this.grp_cliente.Size = new System.Drawing.Size(200, 93);
            this.grp_cliente.TabIndex = 0;
            this.grp_cliente.TabStop = false;
            this.grp_cliente.Text = "Registro Cliente";
            // 
            // txt_ci
            // 
            this.txt_ci.Location = new System.Drawing.Point(94, 39);
            this.txt_ci.Name = "txt_ci";
            this.txt_ci.Size = new System.Drawing.Size(100, 20);
            this.txt_ci.TabIndex = 6;
            // 
            // btn_reg_cli
            // 
            this.btn_reg_cli.Location = new System.Drawing.Point(119, 65);
            this.btn_reg_cli.Name = "btn_reg_cli";
            this.btn_reg_cli.Size = new System.Drawing.Size(75, 23);
            this.btn_reg_cli.TabIndex = 1;
            this.btn_reg_cli.Text = "Registrar";
            this.btn_reg_cli.UseVisualStyleBackColor = true;
            this.btn_reg_cli.Click += new System.EventHandler(this.btn_reg_cli_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Carnet Identidad:";
            // 
            // txt_nom
            // 
            this.txt_nom.Location = new System.Drawing.Point(94, 13);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(100, 20);
            this.txt_nom.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre:";
            // 
            // grp_compra
            // 
            this.grp_compra.Controls.Add(this.label5);
            this.grp_compra.Controls.Add(this.nud_n_entradas);
            this.grp_compra.Controls.Add(this.txt_ci_busca);
            this.grp_compra.Controls.Add(this.label3);
            this.grp_compra.Controls.Add(this.btn_comprar);
            this.grp_compra.Controls.Add(this.label4);
            this.grp_compra.Controls.Add(this.cmb_sectores);
            this.grp_compra.Enabled = false;
            this.grp_compra.Location = new System.Drawing.Point(342, 12);
            this.grp_compra.Name = "grp_compra";
            this.grp_compra.Size = new System.Drawing.Size(216, 129);
            this.grp_compra.TabIndex = 0;
            this.grp_compra.TabStop = false;
            this.grp_compra.Text = "Compra";
            this.grp_compra.Enter += new System.EventHandler(this.grp_compra_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nro. Entradas";
            // 
            // nud_n_entradas
            // 
            this.nud_n_entradas.Location = new System.Drawing.Point(88, 66);
            this.nud_n_entradas.Name = "nud_n_entradas";
            this.nud_n_entradas.Size = new System.Drawing.Size(120, 20);
            this.nud_n_entradas.TabIndex = 1;
            // 
            // txt_ci_busca
            // 
            this.txt_ci_busca.Location = new System.Drawing.Point(109, 13);
            this.txt_ci_busca.Name = "txt_ci_busca";
            this.txt_ci_busca.Size = new System.Drawing.Size(100, 20);
            this.txt_ci_busca.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Carnet Identidad:";
            // 
            // btn_comprar
            // 
            this.btn_comprar.Location = new System.Drawing.Point(135, 92);
            this.btn_comprar.Name = "btn_comprar";
            this.btn_comprar.Size = new System.Drawing.Size(75, 23);
            this.btn_comprar.TabIndex = 9;
            this.btn_comprar.Text = "Comprar";
            this.btn_comprar.UseVisualStyleBackColor = true;
            this.btn_comprar.Click += new System.EventHandler(this.btn_comprar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Sector";
            // 
            // cmb_sectores
            // 
            this.cmb_sectores.FormattingEnabled = true;
            this.cmb_sectores.Items.AddRange(new object[] {
            "curva",
            "general",
            "preferencia",
            "butaca"});
            this.cmb_sectores.Location = new System.Drawing.Point(88, 39);
            this.cmb_sectores.Name = "cmb_sectores";
            this.cmb_sectores.Size = new System.Drawing.Size(121, 21);
            this.cmb_sectores.TabIndex = 3;
            // 
            // btn_volver
            // 
            this.btn_volver.Location = new System.Drawing.Point(483, 303);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(75, 23);
            this.btn_volver.TabIndex = 1;
            this.btn_volver.Text = "Volver";
            this.btn_volver.UseVisualStyleBackColor = true;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nombre,
            this.CI,
            this.Nro_Entradas,
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(12, 147);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(546, 150);
            this.dataGridView1.TabIndex = 2;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            // 
            // CI
            // 
            this.CI.HeaderText = "CI";
            this.CI.Name = "CI";
            // 
            // Nro_Entradas
            // 
            this.Nro_Entradas.HeaderText = "Nro_entradas";
            this.Nro_Entradas.Name = "Nro_Entradas";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Precio_Unitario";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Precio_Total";
            this.Column2.Name = "Column2";
            // 
            // frm_reg_ven
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 333);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.grp_compra);
            this.Controls.Add(this.grp_cliente);
            this.Name = "frm_reg_ven";
            this.Text = "frm_reg_ven";
            this.grp_cliente.ResumeLayout(false);
            this.grp_cliente.PerformLayout();
            this.grp_compra.ResumeLayout(false);
            this.grp_compra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_n_entradas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_cliente;
        private System.Windows.Forms.GroupBox grp_compra;
        private System.Windows.Forms.Button btn_reg_cli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_sectores;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_ci;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_comprar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_ci_busca;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_n_entradas;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nro_Entradas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}