﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class ColaVentas
    {
        NodoVenta cabeza, cola;
        int sample = 1000000;
        public ColaVentas()
        {
            cabeza = null;
        }
        public int getPrecio(string sector)
        {
            int precio;
            switch (sector)
            {
                case "butaca":
                    precio = 100;
                    break;
                case "preferencia":
                    precio = 75;
                    break;
                case "curva":
                    precio = 30;
                    break;
                case "general":
                    precio = 60;
                    break;
                default:
                    precio = 10;
                    break;
            }
            return precio;
        }
        public void encolar(string sector,int ci, int n_entradas)
        {
            NodoVenta nuevo = new NodoVenta(sector, ci, n_entradas, n_entradas*getPrecio(sector), sample);
            if (cabeza == null) cabeza = nuevo;
            else cola.Siguiente = nuevo;
            cola = nuevo;
            sample++;
        }
        public NodoVenta desencolar()
        {
            NodoVenta aux = cabeza;
            cabeza = cabeza.Siguiente;
            aux.Siguiente = null;
            return aux;
        }
        public NodoVenta Cabeza { get => cabeza; set => cabeza = value; }
        public NodoVenta Cola { get => cola; set => cola = value; }
    }
}
