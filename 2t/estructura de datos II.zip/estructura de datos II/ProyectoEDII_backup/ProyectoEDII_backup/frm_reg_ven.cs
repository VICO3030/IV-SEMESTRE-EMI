﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoEDII_backup
{
    public partial class frm_reg_ven : Form
    {
        public frm_reg_ven()
        {
            InitializeComponent();
        }
        private void btn_reg_cli_Click(object sender, EventArgs e)
        {
            if(txt_ci.Text == "" || txt_nom.Text == "")
            {
                MessageBox.Show("Ingrese nombre y carnet validos.");
            }
            else
            {
                Estatica.clientes.agregar(txt_nom.Text, int.Parse(txt_ci.Text));
                MessageBox.Show("Cliente registrado.");
                grp_cliente.Enabled = false;
                grp_compra.Enabled = true;
            }
        }

        private void grp_compra_Enter(object sender, EventArgs e)
        {

        }
        public void comprar()
        {
            NodoCliente cliente = Estatica.clientes.buscar(int.Parse(txt_ci_busca.Text));
            int n = Convert.ToInt32(nud_n_entradas.Value);

            if (cliente != null)
            {
                string sector = cmb_sectores.Text;
                //Estatica.ventas.encolar(cmb_sectores.Text, cliente.Carnet, n);

                switch (sector)
                {
                    case "curva":
                        if (n > Estatica.E_curva) return;
                        Estatica.ventas.encolar(sector, cliente.Carnet, n);
                        Estatica.E_curva -= n;
                        break;
                    case "butaca":
                        if (n > Estatica.E_butaca) return;
                        Estatica.ventas.encolar(sector, cliente.Carnet, n);
                        Estatica.E_butaca -= n;
                        break;
                    case "general":
                        if (n > Estatica.E_general) return;
                        Estatica.ventas.encolar(sector, cliente.Carnet, n);
                        Estatica.E_general -= n;
                        break;
                    case "preferencia":
                        if (n > Estatica.E_preferencia) return;
                        Estatica.ventas.encolar(sector, cliente.Carnet, n);
                        Estatica.E_preferencia -= n;
                        break;
                }

                NodoVenta punt = Estatica.ventas.Cola;
                MessageBox.Show("Precio a pagar: " + punt.Precio);
                grp_compra.Enabled = false;
                grp_cliente.Enabled = true;
            }
            else
            {
                MessageBox.Show("Carnet inexistente o cantidad invalida");
            }
        }

        private void btn_comprar_Click(object sender, EventArgs e)
        {
            comprar();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            
            this.Close();
            
        }
    }
}
