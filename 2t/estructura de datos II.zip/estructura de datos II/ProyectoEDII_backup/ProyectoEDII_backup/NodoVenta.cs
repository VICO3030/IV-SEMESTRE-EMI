﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class NodoVenta
    {
        int codigo;
        float precio;
        string sector;
        int ci_comprador;
        int n_entradas;
        NodoVenta siguiente;
        public NodoVenta(string sector, int ci, int n_entradas, float precio = 0, int codigo = 0, NodoVenta siguiente = null)
        {
            this.codigo = codigo;
            this.precio = precio;
            this.sector = sector;
            this.ci_comprador = ci;
            this.siguiente = siguiente;
            this.n_entradas = n_entradas;
        }

        public int Codigo { get => codigo; set => codigo = value; }
        public float Precio { get => precio; set => precio = value; }
        public string Sector { get => sector; set => sector = value; }
        public int Ci_comprador { get => ci_comprador; set => ci_comprador = value; }
        public NodoVenta Siguiente { get => siguiente; set => siguiente = value; }
        public int N_entradas { get => n_entradas; set => n_entradas = value; }
    }

    
}
