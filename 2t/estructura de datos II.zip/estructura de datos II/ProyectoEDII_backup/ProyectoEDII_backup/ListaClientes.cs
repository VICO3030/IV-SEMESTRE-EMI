﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEDII_backup
{
    class ListaClientes
    {
        NodoCliente cabeza; 
        public ListaClientes()
        {
            cabeza = null;
        }

        public void agregar(string nombre, int ci)
        {
            NodoCliente nuevo = new NodoCliente(nombre, ci);
            if (cabeza == null) cabeza = nuevo;
            else
            {
                NodoCliente punt = cabeza;
                while(punt.Siguiente != null)
                {
                    punt = punt.Siguiente;
                }
                punt.Siguiente = nuevo;
            }
        }
        public NodoCliente buscar(int ci)
        {
            NodoCliente punt = cabeza;
            while(punt != null)
            {
                if (punt.Carnet == ci) return punt;
                punt = punt.Siguiente;
            }
            return null;
        }
        public NodoCliente Cabeza { get => cabeza; set => cabeza = value; }
    }
}
