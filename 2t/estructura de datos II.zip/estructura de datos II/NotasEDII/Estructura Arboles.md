# Estructura Arboles
+ Orden: Numero potencial de hijos de este nodo
+ Grado:  El grado es para todo el arbol, el numero que tiene el eelemento con mas hijos 
+ Nivel: la distancia de la raiz medida en nodos, el nivel de la raiz es cero y de sus hijos 1
+ Altura: la altura se degine como el nivel de nodos de mayor a menor
## Recorridos
1. **Preorden**: Raiz ,izquierda, derecha
2. **Inorden:** Izquierda, raiz, derecha
3. **Postorden:** Izquierda, derecha, raiz.

```c#

```
