```c#
//METODO BUSCAR
private void buscar(int num) {
	NodoP aux;
	Estatica.fillAux();
	while (!Estatica.auxiliar.vacia())
	{
		aux = Estatica.auxiliar.desapilar();
		if(aux.getNum() == num)
		{
			encontrado = aux;
		}
		Estatica.original.apilar(aux.getNum());
	}
}
//METODO ELIMINAR
private void eliminar(int num) {
    Estatica.fillAux();
	NodoP aux;
	while (!Estatica.auxiliar.vacia())
	{
		aux = Estatica.auxiliar.desapilar();
		if(aux.getNum() != num) {
			Estatica.original.apilar(aux.getNum());
		}
	}
}
```
---
[[Pila]]
