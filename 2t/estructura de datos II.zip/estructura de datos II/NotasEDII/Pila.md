```c#
class Pila
{
	NodoP cima, nuevo;
	public Pila()
	{
		cima = null;
		nuevo = null;
	}
	//getters
	public NodoP getCima() { return cima; }
	//setters
	public void setCima(NodoP cima) { this.cima = cima; }
	//METODOS
	public void nuevoNodo(int num)
	{
		nuevo = new NodoP();
		nuevo.setNum(num);
	}
	public void apilar(int num)
	{
		nuevoNodo(num);
		nuevo.setEnlace(cima);
		cima = nuevo;
	}
	public NodoP desapilar()
	{
		NodoP aux = cima;
		cima = cima.getEnlace();
		aux.setEnlace(null);
		return aux;
	}
	public bool vacia() { return cima == null; } 
}
```