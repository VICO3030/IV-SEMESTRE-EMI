﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaCircular
{
    public partial class frm_mostrar : Form
    {
        public frm_mostrar()
        {
            InitializeComponent();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lst_mostrar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void mostrar()
        {
            lst_mostrar.Items.Clear();
            NodoCircular punt = Estatica.lista.getCabeza();
            if (punt == null) MessageBox.Show("Lista Vacia");
            else
            {
                do
                {
                    lst_mostrar.Items.Add(punt.getNum());
                    punt = punt.getEnlace();
                } while (punt != Estatica.lista.getCabeza());
            }
        }
        private void frm_mostrar_Load(object sender, EventArgs e)
        {
            mostrar();
        }
    }
}
