﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaCircular
{
    class NodoCircular
    {
        int num;
        NodoCircular enlace;

        public NodoCircular()
        {
            num = 0;
            enlace = null;
        }

        public void setNum(int num)
        {
            this.num = num;
        }
        public void setEnlace(NodoCircular enlace)
        {
            this.enlace = enlace;
        }
        public int getNum()
        {
            return num;
        }
        public NodoCircular getEnlace()
        {
            return enlace;
        }
    }
}
