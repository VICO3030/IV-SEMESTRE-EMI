﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaCircular
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            Estatica.lista.agregar(int.Parse(txt_dato.Text));
            MessageBox.Show("Registrado");
            txt_dato.Clear();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            frm_mostrar mostrar = new frm_mostrar();
            mostrar.Show();
        }

        private void txt_dato_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frm_buscar buscar = new frm_buscar();
            buscar.Show();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            Estatica.lista.insertar(int.Parse(txt_dato.Text));
            MessageBox.Show("Dato insertado");
            txt_dato.Clear();
        }
    }
}
