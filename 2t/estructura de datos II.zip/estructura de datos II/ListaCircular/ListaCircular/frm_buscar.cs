﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaCircular
{
    public partial class frm_buscar : Form
    {
        NodoCircular dato;

        public frm_buscar()
        {
            InitializeComponent();
            
        }
        
        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_busca_Click(object sender, EventArgs e)
        {
            dato = Estatica.lista.existe(int.Parse(txt_busca.Text));
            if (dato == null) MessageBox.Show("Dato Inexistente");
            else
            {
                grp_editar.Visible = true;
                lbl_dato.Text = dato.getNum().ToString();
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            Estatica.lista.eliminar(dato.getNum());
            MessageBox.Show("Dato eliminado");
            grp_editar.Visible = false;
        }
    }
}
