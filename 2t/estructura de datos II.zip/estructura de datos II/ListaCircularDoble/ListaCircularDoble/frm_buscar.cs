﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaCircularDoble
{
    public partial class frm_buscar : Form
    {
        NodoC_doble encontrado;
        public frm_buscar()
        {
            InitializeComponent();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            Estatica.lista.eliminar(encontrado.getNum());
            MessageBox.Show("Dato Eliminado");
            grp_edicion.Visible = false;
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            encontrado = Estatica.lista.buscar(int.Parse(txt_busqueda.Text));
            if (encontrado == null) MessageBox.Show("Dato Inexistente");
            else
            {
                MessageBox.Show("Dato Encontrado");
                grp_edicion.Visible = true;
                lbl_dato.Text = encontrado.getNum().ToString();
            }
        }
    }
}
