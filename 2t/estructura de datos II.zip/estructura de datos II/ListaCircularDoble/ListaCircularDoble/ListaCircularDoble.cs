﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaCircularDoble
{
    class ListaCircularDoble
    {
        NodoC_doble cabeza, nuevo, ultimo;

        public ListaCircularDoble()
        {
            cabeza = null;
            nuevo = null;
            ultimo = null;
        }
        public NodoC_doble getCabeza() { return cabeza; }
        public NodoC_doble getUltimo() { return ultimo; }
        private void newNode(int num)
        {
            nuevo = new NodoC_doble();
            nuevo.setNum(num);
        }
        
        public void agregar(int num) {
            newNode(num);
            if(cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                ultimo.setSig(nuevo);
                nuevo.setAnt(ultimo);
            }
            ultimo = nuevo;
            ultimo.setSig(cabeza);
            cabeza.setAnt(ultimo);
        }
        //falta enlazar con formulario
        public void ordenar()
        {
            NodoC_doble punt = cabeza, punt2;
            int aux;
            do
            {
                punt2 = punt.getSig();
                do
                {
                    if (punt.getNum() > punt2.getNum())
                    {
                        aux = punt.getNum();
                        punt.setNum(punt2.getNum());
                        punt2.setNum(aux);
                    }
                    punt2 = punt2.getSig();
                } while (punt2 != cabeza);
                punt = punt.getSig();
            } while (punt != ultimo);
        }
        public NodoC_doble buscar(int num) {
            NodoC_doble punt = cabeza;
            do
            {
                if (punt.getNum() == num) return punt;
                punt = punt.getSig();
            } while (punt != cabeza);
            return null; 
        }
        public void eliminar(int num) {
            if(cabeza != null)
            {
                if (cabeza == ultimo && cabeza.getNum() == num)
                {
                    cabeza = null;
                }
                else
                {
                    NodoC_doble punt = cabeza;
                    bool encontrado = false;
                    do
                    {
                        if (punt.getNum() == num)
                        {
                            //primer caso, cabeza
                            if (punt == cabeza)
                            {
                                cabeza = punt.getSig();
                                cabeza.setAnt(ultimo);
                                ultimo.setSig(cabeza);
                            }
                            //segudno caso, ultimo
                            else if (punt == ultimo)
                            {
                                ultimo = ultimo.getAnt();
                                cabeza.setAnt(ultimo);
                                ultimo.setSig(cabeza);
                            }
                            //tercer caso, donde sea
                            else
                            {
                                NodoC_doble anterior = punt.getAnt();
                                NodoC_doble siguiente = punt.getSig();
                                anterior.setSig(siguiente);
                                siguiente.setAnt(anterior);

                            }
                            encontrado = true;
                        }
                        punt = punt.getSig();
                    } while (punt != cabeza && encontrado == false);
                }
            }
        }
        
    }
}
