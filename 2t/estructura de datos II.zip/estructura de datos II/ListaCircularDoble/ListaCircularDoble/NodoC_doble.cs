﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaCircularDoble
{
    class NodoC_doble
    {
        int num;
        NodoC_doble anterior, siguiente;

        public NodoC_doble()
        {
            num = 0;
            anterior = null;
            siguiente = null;
        }
        //GETTERS
        public int getNum() { return num; }
        public NodoC_doble getAnt() { return anterior; }
        public NodoC_doble getSig() { return siguiente; }
        //SETTERS
        public void setNum(int num) { this.num = num; }
        public void setAnt(NodoC_doble ant) { this.anterior = ant; }
        public void setSig(NodoC_doble sig) { this.siguiente = sig; }
    }
}
