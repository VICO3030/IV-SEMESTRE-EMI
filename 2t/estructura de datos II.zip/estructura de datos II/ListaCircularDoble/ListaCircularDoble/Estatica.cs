﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaCircularDoble
{
    class Estatica
    {
        public static ListaCircularDoble lista = new ListaCircularDoble();
        public static int opcion_mostrar = 0;
    }
}
