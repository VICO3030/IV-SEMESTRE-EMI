﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaCircularDoble
{
    public partial class frm_mostrar : Form
    {
        public frm_mostrar()
        {
            InitializeComponent();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void mostrar()
        {
            lst_mostrar.Items.Clear();
            NodoC_doble punt = Estatica.lista.getCabeza();
            do
            {
                lst_mostrar.Items.Add(punt.getNum());
                punt = punt.getSig();
            } while (punt != Estatica.lista.getCabeza());
        }
        public void mostrar_final()
        {
            lst_mostrar.Items.Clear();
            NodoC_doble punt = Estatica.lista.getUltimo();
            do
            {
                lst_mostrar.Items.Add(punt.getNum());
                punt = punt.getAnt();
            } while (punt != Estatica.lista.getUltimo());
        }
        private void frm_mostrar_Load(object sender, EventArgs e)
        {
            if (Estatica.opcion_mostrar == 0)
                mostrar();
            else
                mostrar_final();
        }
    }
}
