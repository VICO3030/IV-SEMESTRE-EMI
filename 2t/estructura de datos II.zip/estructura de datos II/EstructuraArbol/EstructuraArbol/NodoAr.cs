﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraArbol
{
    //INCIO CLASE NODO
    public class NodoAr
    {
        //Atributos de la clase
        //dato
        int num;
        //nodo padre
        NodoAr padre;
        //nodo izquierda
        NodoAr izquierda;
        //nodo derecha
        NodoAr derecha;

        //CONSTRUCTOR
        public NodoAr(int num = 0, NodoAr izq = null, NodoAr der = null)
        {
            this.num = num;
            padre = null;
            izquierda = izq;
            derecha = der;
        }
        //GETTERS Y SETTERS
        public int Num { get => num; set => num = value; }
        public NodoAr Izquierda { get => izquierda; set => izquierda = value; }
        public NodoAr Derecha { get => derecha; set => derecha = value; }
        public NodoAr Padre { get => padre; set => padre = value; }
    }
}
