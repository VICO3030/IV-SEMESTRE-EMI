﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstructuraArbol
{
    public partial class frm_principal : Form
    {
        public frm_principal()
        {
            InitializeComponent();
        }

        private void frm_principal_Load(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //FALTA IMPLEMENTAR//
        private void Preorden(NodoAr punt)
        {
            if (punt != null)
            {
                //raiz
                lst_pre.Items.Add(punt.Num);
                //izquierda
                Preorden(punt.Izquierda);
                //derecha
                Preorden(punt.Derecha);
            }
        }
        private void Inorden(NodoAr punt)
        {
            if(punt != null)
            {
                //izquierda
                Inorden(punt.Izquierda);
                //raiz
                lst_in.Items.Add(punt.Num);
                //derecha
                Inorden(punt.Derecha);
            }
        }
        private void Postorden(NodoAr punt)
        {
            if(punt != null)
            {
                Postorden(punt.Izquierda);
                Postorden(punt.Derecha);
                lst_post.Items.Add(punt.Num);
            }
        }
        public void Preorden() {
            lst_pre.Items.Clear();
            Preorden(Estatica.Arbol.Raiz); 
        }
        public void Inorden() {
            lst_in.Items.Clear();
            Inorden(Estatica.Arbol.Raiz);
        }
        public void Postorden() {
            lst_post.Items.Clear();
            Postorden(Estatica.Arbol.Raiz);
        }

        //FALTA IMPREMENTAR//
        private void btn_pre_Click(object sender, EventArgs e)
        {
            if(Estatica.Arbol.Raiz == null) { MessageBox.Show("Arbol vacio"); return; }
            Preorden();
        }
        private void btn_in_Click(object sender, EventArgs e)
        {
            Inorden();
        }
        private void btn_post_Click(object sender, EventArgs e)
        {
            Postorden();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            if (txt_num.Text == "") MessageBox.Show("Ingrese un elemento valido");
            else {
                Estatica.Arbol.Insertar(int.Parse(txt_num.Text));
                MessageBox.Show("Elemento Insertado");
                txt_num.Clear();
            }
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            int c = 0;
            if (Estatica.Arbol.buscar(int.Parse(txt_num.Text), ref c))
            {
                MessageBox.Show("Nodo encontrado en la altura " + c.ToString());
            }
            else
            {
                MessageBox.Show("Nodo Inexistente");
            }
        }

        private void btn_grafico_Click(object sender, EventArgs e)
        {
            frm_grafico grafico = new frm_grafico();
            grafico.Show();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            Estatica.Arbol.eliminar(int.Parse(txt_num.Text));
            MessageBox.Show("Nodo Eliminado");
        }

        private void btn_recorrido_Click(object sender, EventArgs e)
        {
            int c = 0;
            if (Estatica.Arbol.buscar(int.Parse(txt_num.Text),ref c))
            {
                MessageBox.Show("Nivel: " + c + '\n' + "Recorrido: " + Estatica.Arbol.recorrido(int.Parse(txt_num.Text)));
            }
            else
            {
                MessageBox.Show("Valor inexistente");
            }
        }
    }
}
