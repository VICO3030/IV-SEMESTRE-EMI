﻿
namespace EstructuraArbol
{
    partial class frm_principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_grafico = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_post = new System.Windows.Forms.Button();
            this.lst_post = new System.Windows.Forms.ListBox();
            this.btn_in = new System.Windows.Forms.Button();
            this.lst_in = new System.Windows.Forms.ListBox();
            this.btn_pre = new System.Windows.Forms.Button();
            this.lst_pre = new System.Windows.Forms.ListBox();
            this.btn_recorrido = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_recorrido);
            this.groupBox1.Controls.Add(this.btn_grafico);
            this.groupBox1.Controls.Add(this.btn_insertar);
            this.groupBox1.Controls.Add(this.txt_num);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REGISTRO";
            // 
            // btn_grafico
            // 
            this.btn_grafico.Location = new System.Drawing.Point(119, 71);
            this.btn_grafico.Name = "btn_grafico";
            this.btn_grafico.Size = new System.Drawing.Size(75, 23);
            this.btn_grafico.TabIndex = 6;
            this.btn_grafico.Text = "Grafica";
            this.btn_grafico.UseVisualStyleBackColor = true;
            this.btn_grafico.Click += new System.EventHandler(this.btn_grafico_Click);
            // 
            // btn_insertar
            // 
            this.btn_insertar.Location = new System.Drawing.Point(119, 45);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(75, 23);
            this.btn_insertar.TabIndex = 2;
            this.btn_insertar.Text = "Insertar";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // txt_num
            // 
            this.txt_num.Location = new System.Drawing.Point(94, 19);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(100, 20);
            this.txt_num.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese Dato:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_eliminar);
            this.groupBox2.Controls.Add(this.btn_salir);
            this.groupBox2.Controls.Add(this.btn_buscar);
            this.groupBox2.Location = new System.Drawing.Point(218, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(87, 101);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "OPCIONES";
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Location = new System.Drawing.Point(6, 45);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar.TabIndex = 5;
            this.btn_eliminar.Text = "Eliminar";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(6, 72);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(75, 23);
            this.btn_salir.TabIndex = 4;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.Location = new System.Drawing.Point(6, 17);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(75, 23);
            this.btn_buscar.TabIndex = 3;
            this.btn_buscar.Text = "Buscar";
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_post);
            this.groupBox3.Controls.Add(this.lst_post);
            this.groupBox3.Controls.Add(this.btn_in);
            this.groupBox3.Controls.Add(this.lst_in);
            this.groupBox3.Controls.Add(this.btn_pre);
            this.groupBox3.Controls.Add(this.lst_pre);
            this.groupBox3.Location = new System.Drawing.Point(12, 118);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(293, 165);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btn_post
            // 
            this.btn_post.Location = new System.Drawing.Point(212, 121);
            this.btn_post.Name = "btn_post";
            this.btn_post.Size = new System.Drawing.Size(75, 23);
            this.btn_post.TabIndex = 9;
            this.btn_post.Text = "Postorden";
            this.btn_post.UseVisualStyleBackColor = true;
            this.btn_post.Click += new System.EventHandler(this.btn_post_Click);
            // 
            // lst_post
            // 
            this.lst_post.FormattingEnabled = true;
            this.lst_post.Location = new System.Drawing.Point(212, 20);
            this.lst_post.Name = "lst_post";
            this.lst_post.Size = new System.Drawing.Size(75, 95);
            this.lst_post.TabIndex = 8;
            // 
            // btn_in
            // 
            this.btn_in.Location = new System.Drawing.Point(109, 121);
            this.btn_in.Name = "btn_in";
            this.btn_in.Size = new System.Drawing.Size(75, 23);
            this.btn_in.TabIndex = 7;
            this.btn_in.Text = "Inorden";
            this.btn_in.UseVisualStyleBackColor = true;
            this.btn_in.Click += new System.EventHandler(this.btn_in_Click);
            // 
            // lst_in
            // 
            this.lst_in.FormattingEnabled = true;
            this.lst_in.Location = new System.Drawing.Point(109, 20);
            this.lst_in.Name = "lst_in";
            this.lst_in.Size = new System.Drawing.Size(75, 95);
            this.lst_in.TabIndex = 6;
            // 
            // btn_pre
            // 
            this.btn_pre.Location = new System.Drawing.Point(6, 120);
            this.btn_pre.Name = "btn_pre";
            this.btn_pre.Size = new System.Drawing.Size(75, 23);
            this.btn_pre.TabIndex = 5;
            this.btn_pre.Text = "Preorden";
            this.btn_pre.UseVisualStyleBackColor = true;
            this.btn_pre.Click += new System.EventHandler(this.btn_pre_Click);
            // 
            // lst_pre
            // 
            this.lst_pre.FormattingEnabled = true;
            this.lst_pre.Location = new System.Drawing.Point(6, 19);
            this.lst_pre.Name = "lst_pre";
            this.lst_pre.Size = new System.Drawing.Size(75, 95);
            this.lst_pre.TabIndex = 0;
            // 
            // btn_recorrido
            // 
            this.btn_recorrido.Location = new System.Drawing.Point(38, 45);
            this.btn_recorrido.Name = "btn_recorrido";
            this.btn_recorrido.Size = new System.Drawing.Size(75, 23);
            this.btn_recorrido.TabIndex = 7;
            this.btn_recorrido.Text = "Recorrido";
            this.btn_recorrido.UseVisualStyleBackColor = true;
            this.btn_recorrido.Click += new System.EventHandler(this.btn_recorrido_Click);
            // 
            // frm_principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 290);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_principal";
            this.Text = "ESTRUCTURA ARBOL";
            this.Load += new System.EventHandler(this.frm_principal_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_post;
        private System.Windows.Forms.ListBox lst_post;
        private System.Windows.Forms.Button btn_in;
        private System.Windows.Forms.ListBox lst_in;
        private System.Windows.Forms.Button btn_pre;
        private System.Windows.Forms.ListBox lst_pre;
        private System.Windows.Forms.Button btn_grafico;
        private System.Windows.Forms.Button btn_recorrido;
    }
}

