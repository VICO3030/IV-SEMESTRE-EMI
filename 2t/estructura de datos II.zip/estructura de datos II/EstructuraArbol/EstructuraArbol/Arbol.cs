﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraArbol
{
    //CLASE ARBOL
    class Arbol
    {
        //Atributos raiz, nuevo;

  
        NodoAr raiz, nuevo;

        //CONSTRUCTOR
        public Arbol(NodoAr r = null, NodoAr n = null)
        {
            raiz = r;
            nuevo = n;
        }
        //INSERTAR LLAMAR
        public void Insertar(int d)
        {
            Insertar(d, raiz);
        }
        //INSERTAR RECURSIVO
        private void Insertar(int d, NodoAr nodo)
        {
            //primer caso, arbol vacio (raiz = null);
            if (raiz == null) { nuevo = new NodoAr(d); raiz = nuevo; }
            //segundo caso, arbol con datos (raiz != null);
            else
            {
                //el dato a insertar es mayor o menor?
                if (d > nodo.Num)
                {
                    //si el dato es mayor
                    if (nodo.Derecha == null) {
                        //si el nodo no tiene hijo a la derecha
                        nuevo = new NodoAr(d);
                        nuevo.Padre = nodo;
                        nodo.Derecha = nuevo; 
                    }
                    else
                    {
                        //si el nodo tiene hijo a la derecha
                        Insertar(d, nodo.Derecha);
                    }
                }
                //si el dato es menor
                else
                //nuevo = 4 padre = raiz;
                //nodo =  raiz;
                //raiz = 6;
                //arbol 6,4;
                {
                    //si el dato es menor
                    if (nodo.Izquierda == null) {
                        // si el nodo no tiene hijo a la izquierda
                        nuevo = new NodoAr(d);
                        nuevo.Padre = nodo;
                        nodo.Izquierda = nuevo;
                    }
                    else
                    {
                        //si el nodo tiene hijo a la izquierda
                        Insertar(d, nodo.Izquierda);
                    }
                }

            }
        }
        public bool buscar(int num, ref int c)
        {
            return buscar(num, raiz, ref c);
        }
        private bool buscar(int num, NodoAr nodo, ref int c)
        {
            if (nodo != null)
            {
                if (nodo.Num == num) return true;
                else
                {
                    if (nodo.Num < num) { c++; return buscar(num, nodo.Derecha, ref c); }
                    else { c++; return buscar(num, nodo.Izquierda, ref c); }
                }
            }
            return false;
        }
        private NodoAr buscar_nodo(int num, NodoAr nodo)
        {
            if (nodo != null)
            {
                if (nodo.Num == num) return nodo;
                else
                {
                    if (nodo.Num < num) { return buscar_nodo(num, nodo.Derecha); }
                    else { return buscar_nodo(num, nodo.Izquierda); }
                }
            }
            return null;
        }

        public string recorrido(int num)
        {
            string aux = "";
            recorrido(num, raiz,ref aux);
            return aux;
        }
        public int getAltura()
        {
            return getAltura(raiz);
        }
        public int getAltura(NodoAr nodo)
        {
            if (nodo != null)
                return getAltura(nodo.Derecha) + 1;
            else
                return 0;
        }
        private void recorrido(int num, NodoAr nodo, ref string cad)
        {
            if (nodo != null)
            {
                if (nodo.Num == num)
                {
                    cad += nodo.Num.ToString() + ';';
                }
                else
                {
                    cad += nodo.Num.ToString() + " ";
                    if (nodo.Num < num) { recorrido(num, nodo.Derecha,ref cad); }
                    else { recorrido(num, nodo.Izquierda, ref cad); }
                }
            }
        }
        public bool eliminar(int num)
        {
            return eliminar(buscar_nodo(num, raiz));
        }
        //eliminar nodo hoja
        private bool eliminar_1(NodoAr nodo)
        {
            NodoAr hijoIzq = nodo.Padre.Izquierda;
            NodoAr hijoDer = nodo.Padre.Derecha;

            if(hijoIzq == nodo)
            {
                nodo.Padre.Izquierda = null;
                return true;
            }

            if(hijoDer == nodo)
            {
                nodo.Padre.Derecha = null;
                return true;
            }

            return false;
        }
        //eliminar nodo con un hijo
        private bool eliminar_2(NodoAr nodo)
        {
            NodoAr hijoIzq = nodo.Padre.Izquierda;
            NodoAr hijoDer = nodo.Padre.Derecha;

            NodoAr hijoActual = nodo.Izquierda != null ? nodo.Izquierda : nodo.Derecha;

            if(hijoIzq == nodo)
            {
                nodo.Padre.Izquierda = hijoActual;

                hijoActual.Padre = nodo.Padre;
                nodo.Derecha = null;
                nodo.Izquierda = null;

                return true;
            }

            if(hijoDer == nodo)
            {
                nodo.Padre.Derecha = hijoActual;
                nodo.Derecha = null;
                nodo.Izquierda = null;

                return true;
            }

            return false;
        }
            
        private NodoAr recorrerIzq(NodoAr nodo)
        {
            if(nodo.Izquierda != null)
            {
                return recorrerIzq(nodo.Izquierda);
            }
            return nodo;
        }
        //eliminar nodo con 2 hijos
        private bool eliminar_3(NodoAr nodo)
        {
            NodoAr masIzq = recorrerIzq(nodo.Derecha);
            if(masIzq != null)
            {
                nodo.Num = masIzq.Num;
                eliminar(masIzq);
                return true;
            }
            return false;
        }
        private bool eliminar(NodoAr nodo)
        {
            bool tieneDerecha = nodo.Derecha != null;
            bool tieneIzquier = nodo.Izquierda != null;

            //eliminar nodo hoja
            if (!tieneDerecha && !tieneIzquier) return eliminar_1(nodo);
            //eliminar 1 hijo
            if (tieneDerecha && !tieneIzquier) return eliminar_2(nodo);
            if (!tieneDerecha && tieneIzquier) return eliminar_2(nodo);
            //eliminar 2 hijos
            if (tieneDerecha && tieneIzquier) return eliminar_3(nodo);

            return false;
        }

        
        public NodoAr Raiz { get => raiz; set => raiz = value; }
        
        
    }
    
}
