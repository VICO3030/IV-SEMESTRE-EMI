﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstructuraArbol
{
    public partial class frm_grafico : Form
    {
        public frm_grafico()
        {
            InitializeComponent();
        }

        private void frm_grafico_Load(object sender, EventArgs e)
        {
            
        }

        private void crearL(int posx, int posy, int posx2, int posy2, int tam)
        {
            Graphics nodo;
            nodo = CreateGraphics();
            Pen lapiz;
            lapiz = new Pen(Brushes.Black, 2);
            nodo.DrawLine(lapiz, posx + tam / 2, posy + tam / 2, posx2 + tam / 2, posy2 + tam / 2);
        }
        private void crearE(int posx, int posy, int tam, int num)
        {
            Graphics nodo;
            nodo = CreateGraphics();
            Pen lapiz;
            lapiz = new Pen(Brushes.Black, 2);

            nodo.FillEllipse(Brushes.Purple , posx, posy, tam, tam);
            nodo.DrawString(num.ToString(), Font, Brushes.Black, posx + 18, posy + 18);
            nodo.DrawEllipse(lapiz, posx, posy, tam, tam);
        }
        private void graficarA(int posx, int posy, int tam, NodoAr r)
        {

            crearE(posx, posy, tam, r.Num);
            if (r.Izquierda != null)
            {
                graficarA(posx - 150, posy + 60, tam, r.Izquierda);
            }
            if (r.Derecha != null)
            {
                graficarA(posx + 150, posy + 60, tam, r.Derecha);
            }
        }
        private void graficarL(int posx, int posy, int tam, NodoAr r)
        {

            if (r.Izquierda != null)
            {
                crearL(posx, posy, posx - 150, posy + 60, tam);
                graficarL(posx - 150, posy + 60, tam, r.Izquierda);
            }
            if (r.Derecha != null)
            {
                crearL(posx, posy, posx + 150, posy + 60, tam);
                graficarL(posx + 150, posy + 60, tam, r.Derecha);
            }
        }
        private void graficar2()
        {
            int posx = 350;
            int posy = 30;
            int tam = 50;
            graficarL(posx, posy, tam, Estatica.Arbol.Raiz);
            graficarA(posx, posy, tam, Estatica.Arbol.Raiz);
        }
        private void pruebaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graficar2();

        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
