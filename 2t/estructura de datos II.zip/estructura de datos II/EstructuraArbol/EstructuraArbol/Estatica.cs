﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraArbol
{
    class Estatica
    {
        public static Arbol Arbol = new Arbol();
    }
}
