﻿
namespace Listas
{
    partial class frm_llista
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.lbl_edad = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_edad = new System.Windows.Forms.TextBox();
            this.lst_lista = new System.Windows.Forms.ListBox();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.btn_promedio_edades = new System.Windows.Forms.Button();
            this.txt_promedio_edad = new System.Windows.Forms.TextBox();
            this.btn_my_edad = new System.Windows.Forms.Button();
            this.btn_mn_edad = new System.Windows.Forms.Button();
            this.txt_my_edad = new System.Windows.Forms.TextBox();
            this.txt_mn_edad = new System.Windows.Forms.TextBox();
            this.rdb_edad = new System.Windows.Forms.RadioButton();
            this.rdb_nombre = new System.Windows.Forms.RadioButton();
            this.btn_ord = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.ForeColor = System.Drawing.Color.White;
            this.lbl_nombre.Location = new System.Drawing.Point(34, 40);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(131, 20);
            this.lbl_nombre.TabIndex = 0;
            this.lbl_nombre.Text = "Ingrese Nombre: ";
            // 
            // lbl_edad
            // 
            this.lbl_edad.AutoSize = true;
            this.lbl_edad.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_edad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_edad.ForeColor = System.Drawing.Color.White;
            this.lbl_edad.Location = new System.Drawing.Point(34, 77);
            this.lbl_edad.Name = "lbl_edad";
            this.lbl_edad.Size = new System.Drawing.Size(113, 20);
            this.lbl_edad.TabIndex = 1;
            this.lbl_edad.Text = "Ingrese Edad: ";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(172, 39);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(202, 20);
            this.txt_nombre.TabIndex = 2;
            // 
            // txt_edad
            // 
            this.txt_edad.Location = new System.Drawing.Point(172, 77);
            this.txt_edad.Name = "txt_edad";
            this.txt_edad.Size = new System.Drawing.Size(100, 20);
            this.txt_edad.TabIndex = 3;
            // 
            // lst_lista
            // 
            this.lst_lista.FormattingEnabled = true;
            this.lst_lista.Location = new System.Drawing.Point(38, 126);
            this.lst_lista.Name = "lst_lista";
            this.lst_lista.Size = new System.Drawing.Size(127, 173);
            this.lst_lista.TabIndex = 4;
            // 
            // btn_registrar
            // 
            this.btn_registrar.Location = new System.Drawing.Point(402, 34);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(76, 28);
            this.btn_registrar.TabIndex = 5;
            this.btn_registrar.Text = "Registrar";
            this.btn_registrar.UseVisualStyleBackColor = true;
            this.btn_registrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(435, 315);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(76, 20);
            this.button4.TabIndex = 8;
            this.button4.Text = "Salir";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(402, 74);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(76, 28);
            this.btn_mostrar.TabIndex = 9;
            this.btn_mostrar.Text = "Mostrar";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.Location = new System.Drawing.Point(435, 281);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(76, 28);
            this.btn_limpiar.TabIndex = 10;
            this.btn_limpiar.Text = "Limpiar";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // btn_promedio_edades
            // 
            this.btn_promedio_edades.Enabled = false;
            this.btn_promedio_edades.Location = new System.Drawing.Point(172, 126);
            this.btn_promedio_edades.Name = "btn_promedio_edades";
            this.btn_promedio_edades.Size = new System.Drawing.Size(76, 47);
            this.btn_promedio_edades.TabIndex = 12;
            this.btn_promedio_edades.Text = "Promedio Edades:";
            this.btn_promedio_edades.UseVisualStyleBackColor = true;
            this.btn_promedio_edades.Click += new System.EventHandler(this.btn_promedio_edades_Click);
            // 
            // txt_promedio_edad
            // 
            this.txt_promedio_edad.Location = new System.Drawing.Point(254, 140);
            this.txt_promedio_edad.Name = "txt_promedio_edad";
            this.txt_promedio_edad.Size = new System.Drawing.Size(33, 20);
            this.txt_promedio_edad.TabIndex = 13;
            this.txt_promedio_edad.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btn_my_edad
            // 
            this.btn_my_edad.Location = new System.Drawing.Point(171, 184);
            this.btn_my_edad.Name = "btn_my_edad";
            this.btn_my_edad.Size = new System.Drawing.Size(76, 28);
            this.btn_my_edad.TabIndex = 14;
            this.btn_my_edad.Text = "Mayor edad: ";
            this.btn_my_edad.UseVisualStyleBackColor = true;
            this.btn_my_edad.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_mn_edad
            // 
            this.btn_mn_edad.Location = new System.Drawing.Point(172, 218);
            this.btn_mn_edad.Name = "btn_mn_edad";
            this.btn_mn_edad.Size = new System.Drawing.Size(76, 28);
            this.btn_mn_edad.TabIndex = 15;
            this.btn_mn_edad.Text = "Menor edad";
            this.btn_mn_edad.UseVisualStyleBackColor = true;
            this.btn_mn_edad.Click += new System.EventHandler(this.btn_mn_edad_Click);
            // 
            // txt_my_edad
            // 
            this.txt_my_edad.Enabled = false;
            this.txt_my_edad.Location = new System.Drawing.Point(254, 189);
            this.txt_my_edad.Name = "txt_my_edad";
            this.txt_my_edad.Size = new System.Drawing.Size(257, 20);
            this.txt_my_edad.TabIndex = 16;
            // 
            // txt_mn_edad
            // 
            this.txt_mn_edad.Location = new System.Drawing.Point(254, 223);
            this.txt_mn_edad.Name = "txt_mn_edad";
            this.txt_mn_edad.Size = new System.Drawing.Size(257, 20);
            this.txt_mn_edad.TabIndex = 17;
            // 
            // rdb_edad
            // 
            this.rdb_edad.AutoSize = true;
            this.rdb_edad.ForeColor = System.Drawing.Color.White;
            this.rdb_edad.Location = new System.Drawing.Point(346, 155);
            this.rdb_edad.Name = "rdb_edad";
            this.rdb_edad.Size = new System.Drawing.Size(50, 17);
            this.rdb_edad.TabIndex = 19;
            this.rdb_edad.TabStop = true;
            this.rdb_edad.Text = "Edad";
            this.rdb_edad.UseVisualStyleBackColor = true;
            this.rdb_edad.CheckedChanged += new System.EventHandler(this.rdb_edad_CheckedChanged);
            // 
            // rdb_nombre
            // 
            this.rdb_nombre.AutoSize = true;
            this.rdb_nombre.ForeColor = System.Drawing.Color.White;
            this.rdb_nombre.Location = new System.Drawing.Point(402, 155);
            this.rdb_nombre.Name = "rdb_nombre";
            this.rdb_nombre.Size = new System.Drawing.Size(62, 17);
            this.rdb_nombre.TabIndex = 20;
            this.rdb_nombre.TabStop = true;
            this.rdb_nombre.Text = "Nombre";
            this.rdb_nombre.UseVisualStyleBackColor = true;
            // 
            // btn_ord
            // 
            this.btn_ord.Location = new System.Drawing.Point(346, 121);
            this.btn_ord.Name = "btn_ord";
            this.btn_ord.Size = new System.Drawing.Size(118, 28);
            this.btn_ord.TabIndex = 21;
            this.btn_ord.Text = "Ordenar por: ";
            this.btn_ord.UseVisualStyleBackColor = true;
            this.btn_ord.Click += new System.EventHandler(this.btn_ord_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.Location = new System.Drawing.Point(172, 252);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(76, 20);
            this.btn_buscar.TabIndex = 22;
            this.btn_buscar.Text = "Buscar";
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_insertar
            // 
            this.btn_insertar.Location = new System.Drawing.Point(320, 74);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(76, 28);
            this.btn_insertar.TabIndex = 23;
            this.btn_insertar.Text = "insertar";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // frm_llista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(523, 345);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_ord);
            this.Controls.Add(this.rdb_nombre);
            this.Controls.Add(this.rdb_edad);
            this.Controls.Add(this.txt_mn_edad);
            this.Controls.Add(this.txt_my_edad);
            this.Controls.Add(this.btn_mn_edad);
            this.Controls.Add(this.btn_my_edad);
            this.Controls.Add(this.txt_promedio_edad);
            this.Controls.Add(this.btn_promedio_edades);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.lst_lista);
            this.Controls.Add(this.txt_edad);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_edad);
            this.Controls.Add(this.lbl_nombre);
            this.Name = "frm_llista";
            this.Text = "LISTAS_SIMPLES";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_edad;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_edad;
        private System.Windows.Forms.ListBox lst_lista;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Button btn_promedio_edades;
        private System.Windows.Forms.TextBox txt_promedio_edad;
        private System.Windows.Forms.Button btn_my_edad;
        private System.Windows.Forms.Button btn_mn_edad;
        private System.Windows.Forms.TextBox txt_my_edad;
        private System.Windows.Forms.TextBox txt_mn_edad;
        private System.Windows.Forms.RadioButton rdb_edad;
        private System.Windows.Forms.RadioButton rdb_nombre;
        private System.Windows.Forms.Button btn_ord;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_insertar;
    }
}

