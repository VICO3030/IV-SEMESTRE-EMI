﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas
{
    class Lista_simple
    {
        Nodo cabeza, nuevo;

        public Lista_simple()
        {
            cabeza = null;
            nuevo = null;
        }
        public void crearNodo(string nombre,int edad)
        {
            nuevo = new Nodo();
            nuevo.setNombre(nombre);
            nuevo.setEdad(edad);
            nuevo.setEnlace(null);
        }
        public void crearLista(string nombre,int edad)
        {
            Nodo punt;
            crearNodo(nombre, edad);

            if(cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                punt = cabeza;
                while(punt.getEnlace() != null)
                {
                    punt = punt.getEnlace();
                }
                punt.setEnlace(nuevo);
            }
        }
        public Nodo getCabeza()
        {
            return cabeza;
        }
        public Nodo mayor_edad()
        {
            Nodo punt = cabeza;
            Nodo mayor_= new Nodo();
            int mayor = int.MinValue;
            while(punt != null)
            {
                if(punt.getEdad() > mayor)
                {
                    mayor = punt.getEdad();
                    mayor_.setEdad(punt.getEdad());
                    mayor_.setNombre(punt.getNombre());
                }
                punt = punt.getEnlace();
            }
            return mayor_;
        }
        public Nodo menor_edad()
        {
            Nodo punt = cabeza;
            Nodo nuevo = new Nodo();
            int menor = int.MaxValue;
            while (punt != null)
            {
                if (punt.getEdad() < menor)
                {
                    menor = punt.getEdad();
                    nuevo.setEdad(punt.getEdad());
                    nuevo.setNombre(punt.getNombre());
                }
                punt = punt.getEnlace();
            }
            return nuevo;
        }
        public void ord_edad()
        {
            Nodo punt = cabeza;
            Nodo punt2 = new Nodo();
            int aux;
            string aux2;
            while(punt != null)
            {
                punt2 = punt.getEnlace();
                while(punt2 != null)
                {
                    if(punt.getEdad() > punt2.getEdad())
                    {
                        aux = punt.getEdad();
                        aux2 = punt.getNombre();
                        punt.setEdad(punt2.getEdad());
                        punt.setNombre(punt2.getNombre());
                        punt2.setEdad(aux);
                        punt2.setNombre(aux2);
                    }
                    punt2 = punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }
        }
        public void ord_nombre()
        {
            Nodo punt = cabeza;
            Nodo punt2 = new Nodo();
            int aux;
            string aux2;
            while (punt != null)
            {
                punt2 = punt.getEnlace();
                while (punt2 != null)
                {
                    if (punt.getNombre().CompareTo(punt2.getNombre())  > 0)
                    {
                        aux = punt.getEdad();
                        aux2 = punt.getNombre();
                        punt.setEdad(punt2.getEdad());
                        punt.setNombre(punt2.getNombre());
                        punt2.setEdad(aux);
                        punt2.setNombre(aux2);
                    }
                    punt2 = punt2.getEnlace();
                }
                punt = punt.getEnlace();
            }
        }
        public bool buscar(string nom)
        {
            Nodo punt = cabeza;
            while(punt != null)
            {
                if(punt.getNombre() == nom)
                {
                    return true;
                }
                punt = punt.getEnlace();
            }
            return false;
        }
        public bool buscar(int ed)
        {
            Nodo punt = cabeza;
            while (punt != null)
            {
                if (punt.getEdad() == ed)
                {
                    return true;
                }
                punt = punt.getEnlace();
            }
            return false;
        }
        public Nodo buscar_nodo(string nom)
        {
            Nodo punt = cabeza;
            while (punt != null)
            {
                if (punt.getNombre() == nom)
                {
                    return punt;
                }
                punt = punt.getEnlace();
            }
            return punt; //retorna null
        }
        public void eliminar(string nom)
        {
            if (cabeza.getNombre() == nom)
            {
                Nodo actual = cabeza;
                cabeza = cabeza.getEnlace();
                actual.setEnlace(null);
            }
            else
            {
                Nodo anterior = null;
                Nodo actual = estatica.Lista.getCabeza();
                
                while (actual != null && actual.getNombre() != nom)
                {
                    anterior = actual;
                    actual = actual.getEnlace();
                }

                if (actual != null)
                {
                    anterior.setEnlace(actual.getEnlace());
                    actual.setEnlace(null);
                }
            }
        }
        public int filtrar_iguales(int edad)
        {
            if (!buscar(edad)) return 0;
            if (cabeza.getEdad() == edad)
            {
                Nodo actual = cabeza;
                cabeza = cabeza.getEnlace();
                actual.setEnlace(null);
            }
            else
            {
                Nodo anterior = null;
                Nodo actual = estatica.Lista.getCabeza();

                while (actual != null && actual.getEdad() != edad)
                {
                    anterior = actual;
                    actual = actual.getEnlace();
                }

                if (actual != null)
                {
                    anterior.setEnlace(actual.getEnlace());
                    actual.setEnlace(null);
                }
            }
            return 1 + filtrar_iguales(edad);
            
        }
        public void insertar(Nodo nuevo)
        {
            if(nuevo.getEdad() <= cabeza.getEdad())
            {
                nuevo.setEnlace(cabeza);
                cabeza = nuevo;
            }
            else
            {
                Nodo punt1 = cabeza, punt2 = cabeza.getEnlace();
                while(punt2 != null)
                {
                    if (nuevo.getEdad() < punt2.getEdad() && nuevo.getEdad() >= punt1.getEdad())
                    {
                        punt1.setEnlace(nuevo);
                        nuevo.setEnlace(punt2);
                    }

                    punt1 = punt1.getEnlace();
                    punt2 = punt2.getEnlace();
                }
            }
            /*
            Nodo punt = cabeza;
            while(punt != null)
            {
                punt = punt.getEnlace();
            }
            punt.setEnlace(nuevo);
            */
        }
    }
}

