﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas
{
    public partial class Insertar : Form
    {
        public Insertar()
        {
            InitializeComponent();
        }

        private void btn_aceptar_insertar_Click(object sender, EventArgs e)
        {
            estatica.Lista.ord_edad();

            Nodo nuevo = new Nodo();
            nuevo.setEdad(int.Parse(txt_insertar_edad.Text));
            nuevo.setNombre(txt_insertar_nombre.Text);
            estatica.Lista.insertar(nuevo);
            MessageBox.Show("Insertado con exito");

            frm_llista principal = new frm_llista();
            this.Close();
            principal.Show();
        }
    }
}
