﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas
{
    public partial class frm_llista : Form
    { 
        //Lista_simple Lista;
        public frm_llista()
        {
            InitializeComponent();
            //estatica.Lista = new Lista_simple();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = txt_nombre.Text;
            int edad = int.Parse(txt_edad.Text);
            estatica.Lista.crearLista(nombre, edad);

            MessageBox.Show("ESTUDIANTE REGISTRADO.");
            
            
            btn_promedio_edades.Enabled = true;
        }

        public void mostrar()
        {
            Nodo punt;
            punt = estatica.Lista.getCabeza();
            while(punt != null)
            {
                lst_lista.Items.Add("Nombre : " + punt.getNombre());
                lst_lista.Items.Add("Edad : " + punt.getEdad());
                lst_lista.Items.Add("======================================");
                punt = punt.getEnlace();
            }
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            if (estatica.Lista.getCabeza() == null) MessageBox.Show("lista vacia");
            else 
            mostrar();
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            txt_nombre.Clear();
            txt_edad.Clear();
            txt_promedio_edad.Clear();
            lst_lista.Items.Clear();
            txt_my_edad.Clear();
            txt_mn_edad.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public float promedio()
        {
            Nodo punt;
            float s = 0;
            int n = 0;
            punt = estatica.Lista.getCabeza();
            while (punt != null)
            {
                s += punt.getEdad();
                punt = punt.getEnlace();
                n++;
            }
            return s / n;
        }

        private void btn_promedio_edades_Click(object sender, EventArgs e)
        {
            txt_promedio_edad.Text = promedio().ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txt_my_edad.Text = estatica.Lista.mayor_edad().getEdad().ToString() + " " + estatica.Lista.mayor_edad().getNombre();
        }

        private void btn_mn_edad_Click(object sender, EventArgs e)
        {
            txt_mn_edad.Text = estatica.Lista.menor_edad().getEdad().ToString() + " " + estatica.Lista.menor_edad().getNombre();
        }

        private void rdb_edad_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_ord_Click(object sender, EventArgs e)
        {
            if (rdb_edad.Checked)
            {
                estatica.Lista.ord_edad();
            }else if (rdb_nombre.Checked)
            {
                estatica.Lista.ord_nombre();
            }
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frm_buscar buscar = new frm_buscar();
            this.Hide();
            buscar.Show();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Insertar insertar = new Insertar();
            this.Hide();
            insertar.Show();
        }
    }
}
