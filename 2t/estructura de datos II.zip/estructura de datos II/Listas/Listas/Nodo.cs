﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas
{
    class Nodo
    {
        string nombre;
        int edad;
        Nodo enlace;
        //constructor
        public Nodo()
        {
            nombre = "";
            edad = 0;
            enlace = null;
        }
        //setters
        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }
        public void setEdad(int edad)
        {
            this.edad = edad;
        }
        public void setEnlace(Nodo enlace)
        {
            this.enlace = enlace;
        }
        //getters
        public string getNombre()
        {
            return this.nombre;
        }
        public int getEdad()
        {
            return this.edad;
        }
        public Nodo getEnlace()
        {
            return this.enlace;
        }
    }
}
