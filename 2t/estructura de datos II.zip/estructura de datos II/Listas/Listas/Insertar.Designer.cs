﻿
namespace Listas
{
    partial class Insertar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_insertar_edad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_insertar_nombre = new System.Windows.Forms.TextBox();
            this.btn_aceptar_insertar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_insertar_edad
            // 
            this.txt_insertar_edad.Location = new System.Drawing.Point(211, 48);
            this.txt_insertar_edad.Name = "txt_insertar_edad";
            this.txt_insertar_edad.Size = new System.Drawing.Size(100, 20);
            this.txt_insertar_edad.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese Edad a insertar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese Nombre a insertar";
            // 
            // txt_insertar_nombre
            // 
            this.txt_insertar_nombre.Location = new System.Drawing.Point(211, 9);
            this.txt_insertar_nombre.Name = "txt_insertar_nombre";
            this.txt_insertar_nombre.Size = new System.Drawing.Size(100, 20);
            this.txt_insertar_nombre.TabIndex = 3;
            // 
            // btn_aceptar_insertar
            // 
            this.btn_aceptar_insertar.Location = new System.Drawing.Point(339, 80);
            this.btn_aceptar_insertar.Name = "btn_aceptar_insertar";
            this.btn_aceptar_insertar.Size = new System.Drawing.Size(75, 23);
            this.btn_aceptar_insertar.TabIndex = 4;
            this.btn_aceptar_insertar.Text = "Aceptar";
            this.btn_aceptar_insertar.UseVisualStyleBackColor = true;
            this.btn_aceptar_insertar.Click += new System.EventHandler(this.btn_aceptar_insertar_Click);
            // 
            // Insertar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(426, 115);
            this.Controls.Add(this.btn_aceptar_insertar);
            this.Controls.Add(this.txt_insertar_nombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_insertar_edad);
            this.Name = "Insertar";
            this.Text = "Insertar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_insertar_edad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_insertar_nombre;
        private System.Windows.Forms.Button btn_aceptar_insertar;
    }
}