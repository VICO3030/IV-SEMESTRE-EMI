﻿using System;
namespace Listas
{
    class estatica
    {
        public static Lista_simple Lista = new Lista_simple();

    }
}
