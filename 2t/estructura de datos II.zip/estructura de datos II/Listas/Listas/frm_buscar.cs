﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Listas
{
    public partial class frm_buscar : Form
    {
        public frm_buscar()
        {
            InitializeComponent();
        }

        private void frm_buscar_Load(object sender, EventArgs e)
        {

        }

        private void btn_vover_Click(object sender, EventArgs e)
        {
            frm_llista principal = new frm_llista();
            this.Hide();
            principal.Show();
        }

        private void lbl_nombre_Click(object sender, EventArgs e)
        {

        }

        private void btn_modificar_edad_Click(object sender, EventArgs e)
        {
            gpb_modificar.Visible = true;
            Nodo punt = estatica.Lista.buscar_nodo(txt_busqueda_nombre.Text);
            lbl_edad_actual.Text = "Edad actual: " + punt.getEdad();
        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            Nodo punt = estatica.Lista.buscar_nodo(txt_busqueda_nombre.Text);
            punt.setEdad(int.Parse(txt_nueva_edad.Text));
            lbl_edad_actual.Text = "Edad actual: " + punt.getEdad();
        }

        private void gpb_modificar_Enter(object sender, EventArgs e)
        {

        }

        private void btn_buscar_nombre_Click(object sender, EventArgs e)
        {
            bool existe = estatica.Lista.buscar(txt_busqueda_nombre.Text);
            if (existe) MessageBox.Show(txt_busqueda_nombre.Text + " existe.");
            else MessageBox.Show(txt_busqueda_nombre.Text + " no existe");
        }

        private void btn_eliminar_uno_Click(object sender, EventArgs e)
        {
            estatica.Lista.eliminar(txt_busqueda_nombre.Text);
            MessageBox.Show("Eliminacion efectuada con exito");
        }

        private void btn_filtrar_Click(object sender, EventArgs e)
        {
            int c = estatica.Lista.filtrar_iguales(int.Parse(txt_parametro.Text));
            MessageBox.Show("Se eliminaron " + c + " estudiantes.");
        }
    }
}
