﻿
namespace Listas
{
    partial class frm_buscar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_vover = new System.Windows.Forms.Button();
            this.lbl_busqueda_nombre = new System.Windows.Forms.Label();
            this.txt_busqueda_nombre = new System.Windows.Forms.TextBox();
            this.btn_buscar_nombre = new System.Windows.Forms.Button();
            this.btn_modificar_edad = new System.Windows.Forms.Button();
            this.gpb_modificar = new System.Windows.Forms.GroupBox();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.txt_nueva_edad = new System.Windows.Forms.TextBox();
            this.lbl_ingreso_nombre = new System.Windows.Forms.Label();
            this.lbl_edad_actual = new System.Windows.Forms.Label();
            this.btn_eliminar_uno = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_parametro = new System.Windows.Forms.TextBox();
            this.btn_filtrar = new System.Windows.Forms.Button();
            this.gpb_modificar.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_vover
            // 
            this.btn_vover.Location = new System.Drawing.Point(421, 341);
            this.btn_vover.Name = "btn_vover";
            this.btn_vover.Size = new System.Drawing.Size(75, 23);
            this.btn_vover.TabIndex = 0;
            this.btn_vover.Text = "Volver";
            this.btn_vover.UseVisualStyleBackColor = true;
            this.btn_vover.Click += new System.EventHandler(this.btn_vover_Click);
            // 
            // lbl_busqueda_nombre
            // 
            this.lbl_busqueda_nombre.AutoSize = true;
            this.lbl_busqueda_nombre.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_busqueda_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_busqueda_nombre.ForeColor = System.Drawing.Color.White;
            this.lbl_busqueda_nombre.Location = new System.Drawing.Point(36, 47);
            this.lbl_busqueda_nombre.Name = "lbl_busqueda_nombre";
            this.lbl_busqueda_nombre.Size = new System.Drawing.Size(202, 20);
            this.lbl_busqueda_nombre.TabIndex = 1;
            this.lbl_busqueda_nombre.Text = "Ingrese Nombre  a Buscar: ";
            this.lbl_busqueda_nombre.Click += new System.EventHandler(this.lbl_nombre_Click);
            // 
            // txt_busqueda_nombre
            // 
            this.txt_busqueda_nombre.Location = new System.Drawing.Point(245, 46);
            this.txt_busqueda_nombre.Name = "txt_busqueda_nombre";
            this.txt_busqueda_nombre.Size = new System.Drawing.Size(276, 20);
            this.txt_busqueda_nombre.TabIndex = 2;
            // 
            // btn_buscar_nombre
            // 
            this.btn_buscar_nombre.Location = new System.Drawing.Point(40, 100);
            this.btn_buscar_nombre.Name = "btn_buscar_nombre";
            this.btn_buscar_nombre.Size = new System.Drawing.Size(198, 41);
            this.btn_buscar_nombre.TabIndex = 4;
            this.btn_buscar_nombre.Text = "Buscar";
            this.btn_buscar_nombre.UseVisualStyleBackColor = true;
            this.btn_buscar_nombre.Click += new System.EventHandler(this.btn_buscar_nombre_Click);
            // 
            // btn_modificar_edad
            // 
            this.btn_modificar_edad.Location = new System.Drawing.Point(323, 100);
            this.btn_modificar_edad.Name = "btn_modificar_edad";
            this.btn_modificar_edad.Size = new System.Drawing.Size(198, 41);
            this.btn_modificar_edad.TabIndex = 5;
            this.btn_modificar_edad.Text = "Modificar";
            this.btn_modificar_edad.UseVisualStyleBackColor = true;
            this.btn_modificar_edad.Click += new System.EventHandler(this.btn_modificar_edad_Click);
            // 
            // gpb_modificar
            // 
            this.gpb_modificar.Controls.Add(this.btn_eliminar_uno);
            this.gpb_modificar.Controls.Add(this.btn_actualizar);
            this.gpb_modificar.Controls.Add(this.txt_nueva_edad);
            this.gpb_modificar.Controls.Add(this.lbl_ingreso_nombre);
            this.gpb_modificar.Controls.Add(this.lbl_edad_actual);
            this.gpb_modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpb_modificar.ForeColor = System.Drawing.Color.White;
            this.gpb_modificar.Location = new System.Drawing.Point(40, 166);
            this.gpb_modificar.Name = "gpb_modificar";
            this.gpb_modificar.Size = new System.Drawing.Size(462, 169);
            this.gpb_modificar.TabIndex = 6;
            this.gpb_modificar.TabStop = false;
            this.gpb_modificar.Text = "Modificar";
            this.gpb_modificar.Visible = false;
            this.gpb_modificar.Enter += new System.EventHandler(this.gpb_modificar_Enter);
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.ForeColor = System.Drawing.Color.Black;
            this.btn_actualizar.Location = new System.Drawing.Point(344, 73);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(112, 56);
            this.btn_actualizar.TabIndex = 7;
            this.btn_actualizar.Text = "Actualizar edad";
            this.btn_actualizar.UseVisualStyleBackColor = true;
            this.btn_actualizar.Click += new System.EventHandler(this.btn_actualizar_Click);
            // 
            // txt_nueva_edad
            // 
            this.txt_nueva_edad.Location = new System.Drawing.Point(6, 79);
            this.txt_nueva_edad.Name = "txt_nueva_edad";
            this.txt_nueva_edad.Size = new System.Drawing.Size(192, 26);
            this.txt_nueva_edad.TabIndex = 7;
            // 
            // lbl_ingreso_nombre
            // 
            this.lbl_ingreso_nombre.AutoSize = true;
            this.lbl_ingreso_nombre.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_ingreso_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ingreso_nombre.ForeColor = System.Drawing.Color.White;
            this.lbl_ingreso_nombre.Location = new System.Drawing.Point(6, 56);
            this.lbl_ingreso_nombre.Name = "lbl_ingreso_nombre";
            this.lbl_ingreso_nombre.Size = new System.Drawing.Size(174, 20);
            this.lbl_ingreso_nombre.TabIndex = 8;
            this.lbl_ingreso_nombre.Text = "Ingrese la nueva edad: ";
            // 
            // lbl_edad_actual
            // 
            this.lbl_edad_actual.AutoSize = true;
            this.lbl_edad_actual.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_edad_actual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_edad_actual.ForeColor = System.Drawing.Color.White;
            this.lbl_edad_actual.Location = new System.Drawing.Point(6, 22);
            this.lbl_edad_actual.Name = "lbl_edad_actual";
            this.lbl_edad_actual.Size = new System.Drawing.Size(0, 20);
            this.lbl_edad_actual.TabIndex = 7;
            // 
            // btn_eliminar_uno
            // 
            this.btn_eliminar_uno.ForeColor = System.Drawing.Color.Black;
            this.btn_eliminar_uno.Location = new System.Drawing.Point(258, 22);
            this.btn_eliminar_uno.Name = "btn_eliminar_uno";
            this.btn_eliminar_uno.Size = new System.Drawing.Size(198, 41);
            this.btn_eliminar_uno.TabIndex = 7;
            this.btn_eliminar_uno.Text = "Eliminar ";
            this.btn_eliminar_uno.UseVisualStyleBackColor = true;
            this.btn_eliminar_uno.Click += new System.EventHandler(this.btn_eliminar_uno_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(557, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Edad a filtrar: ";
            // 
            // txt_parametro
            // 
            this.txt_parametro.Location = new System.Drawing.Point(561, 70);
            this.txt_parametro.Name = "txt_parametro";
            this.txt_parametro.Size = new System.Drawing.Size(67, 20);
            this.txt_parametro.TabIndex = 8;
            // 
            // btn_filtrar
            // 
            this.btn_filtrar.Location = new System.Drawing.Point(561, 100);
            this.btn_filtrar.Name = "btn_filtrar";
            this.btn_filtrar.Size = new System.Drawing.Size(103, 41);
            this.btn_filtrar.TabIndex = 9;
            this.btn_filtrar.Text = "Filtrar";
            this.btn_filtrar.UseVisualStyleBackColor = true;
            this.btn_filtrar.Click += new System.EventHandler(this.btn_filtrar_Click);
            // 
            // frm_buscar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(727, 378);
            this.Controls.Add(this.btn_filtrar);
            this.Controls.Add(this.txt_parametro);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gpb_modificar);
            this.Controls.Add(this.btn_modificar_edad);
            this.Controls.Add(this.btn_buscar_nombre);
            this.Controls.Add(this.txt_busqueda_nombre);
            this.Controls.Add(this.lbl_busqueda_nombre);
            this.Controls.Add(this.btn_vover);
            this.Name = "frm_buscar";
            this.Text = "frm_buscar";
            this.Load += new System.EventHandler(this.frm_buscar_Load);
            this.gpb_modificar.ResumeLayout(false);
            this.gpb_modificar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_vover;
        private System.Windows.Forms.Label lbl_busqueda_nombre;
        private System.Windows.Forms.TextBox txt_busqueda_nombre;
        private System.Windows.Forms.Button btn_buscar_nombre;
        private System.Windows.Forms.Button btn_modificar_edad;
        private System.Windows.Forms.GroupBox gpb_modificar;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.TextBox txt_nueva_edad;
        private System.Windows.Forms.Label lbl_ingreso_nombre;
        private System.Windows.Forms.Label lbl_edad_actual;
        private System.Windows.Forms.Button btn_eliminar_uno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_parametro;
        private System.Windows.Forms.Button btn_filtrar;
    }
}