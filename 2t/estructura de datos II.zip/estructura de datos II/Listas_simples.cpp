#include<iostream>
using namespace std;

class Formulario{
		
};

class Nodo
{
	string nombre;
	int edad;
	Nodo enlace;  //es la direccion del nodo con el que se enlaza
	
	public:
		Nodo(){
			nombre = "";
			edad = 0;
			enlace = NULL;
		}
		
		void setNombre(string nombre);
		void setEdad(int edad);
		void setEnlace(Nodo enlace);
		string getNombre();
		int getEdad();
		Nodo getEnlace();
};

class Operacion{
	
};

int main(){
	
}
//implementaciones
void Nodo::setEdad(int edad){
	this->edad = edad;
}

void Nodo::setNombre(string nombre){
	this->nombre = nombre;
}

void Nodo::setEnlace(Nodo enlace){
	this->enlace = enlace;
}

string Nodo::getNombre(){
	return nombre;
}

int Nodo::getEdad(){
	return edad;
}

Nodo Nodo::getEnlace(){
	return enlace;
}
