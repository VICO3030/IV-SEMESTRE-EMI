﻿
namespace ListaDobleEnlazada
{
    partial class frm_buscar_ciclista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_volver = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.grp_busqueda = new System.Windows.Forms.GroupBox();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.lbl_cat = new System.Windows.Forms.Label();
            this.lbl_nBici = new System.Windows.Forms.Label();
            this.lbl_nom = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_busca = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.grp_busqueda.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_volver
            // 
            this.btn_volver.Location = new System.Drawing.Point(233, 203);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(75, 23);
            this.btn_volver.TabIndex = 0;
            this.btn_volver.Text = "Volver";
            this.btn_volver.UseVisualStyleBackColor = true;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_buscar);
            this.groupBox1.Controls.Add(this.grp_busqueda);
            this.groupBox1.Controls.Add(this.txt_busca);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 185);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Busqueda Ciclista";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_buscar
            // 
            this.btn_buscar.Location = new System.Drawing.Point(210, 45);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(75, 23);
            this.btn_buscar.TabIndex = 2;
            this.btn_buscar.Text = "Buscar";
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // grp_busqueda
            // 
            this.grp_busqueda.Controls.Add(this.btn_eliminar);
            this.grp_busqueda.Controls.Add(this.lbl_cat);
            this.grp_busqueda.Controls.Add(this.lbl_nBici);
            this.grp_busqueda.Controls.Add(this.lbl_nom);
            this.grp_busqueda.Controls.Add(this.label4);
            this.grp_busqueda.Controls.Add(this.label3);
            this.grp_busqueda.Controls.Add(this.label2);
            this.grp_busqueda.Location = new System.Drawing.Point(48, 74);
            this.grp_busqueda.Name = "grp_busqueda";
            this.grp_busqueda.Size = new System.Drawing.Size(237, 102);
            this.grp_busqueda.TabIndex = 4;
            this.grp_busqueda.TabStop = false;
            this.grp_busqueda.Text = "Datos Ciclista";
            this.grp_busqueda.Visible = false;
            this.grp_busqueda.Enter += new System.EventHandler(this.grp_busqueda_Enter);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Location = new System.Drawing.Point(156, 73);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar.TabIndex = 2;
            this.btn_eliminar.Text = "Eliminar";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // lbl_cat
            // 
            this.lbl_cat.AutoSize = true;
            this.lbl_cat.Location = new System.Drawing.Point(119, 42);
            this.lbl_cat.Name = "lbl_cat";
            this.lbl_cat.Size = new System.Drawing.Size(35, 13);
            this.lbl_cat.TabIndex = 10;
            this.lbl_cat.Text = "label7";
            // 
            // lbl_nBici
            // 
            this.lbl_nBici.AutoSize = true;
            this.lbl_nBici.Location = new System.Drawing.Point(119, 29);
            this.lbl_nBici.Name = "lbl_nBici";
            this.lbl_nBici.Size = new System.Drawing.Size(35, 13);
            this.lbl_nBici.TabIndex = 9;
            this.lbl_nBici.Text = "label6";
            // 
            // lbl_nom
            // 
            this.lbl_nom.AutoSize = true;
            this.lbl_nom.Location = new System.Drawing.Point(119, 16);
            this.lbl_nom.Name = "lbl_nom";
            this.lbl_nom.Size = new System.Drawing.Size(35, 13);
            this.lbl_nom.TabIndex = 8;
            this.lbl_nom.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Categoria: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nro. Bici:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nombre: ";
            // 
            // txt_busca
            // 
            this.txt_busca.Location = new System.Drawing.Point(185, 19);
            this.txt_busca.Name = "txt_busca";
            this.txt_busca.Size = new System.Drawing.Size(100, 20);
            this.txt_busca.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ingrese Numero de bici";
            // 
            // frm_buscar_ciclista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 238);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_volver);
            this.Name = "frm_buscar_ciclista";
            this.Text = "frm_buscar_ciclista";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grp_busqueda.ResumeLayout(false);
            this.grp_busqueda.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.GroupBox grp_busqueda;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Label lbl_cat;
        private System.Windows.Forms.Label lbl_nBici;
        private System.Windows.Forms.Label lbl_nom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_busca;
        private System.Windows.Forms.Label label1;
    }
}