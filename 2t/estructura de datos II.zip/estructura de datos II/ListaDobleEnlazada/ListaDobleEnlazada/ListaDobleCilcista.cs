﻿using System;
namespace ListaDobleEnlazada
{
    class ListaDobleCilcista
    {
        NodoCiclista cabeza, nuevo;

        public ListaDobleCilcista()
        {
            cabeza = null;
            nuevo = null;
        }
        public NodoCiclista get_cabeza()
        {
            return cabeza;
        }
        public NodoCiclista get_nuevo()
        {
            return nuevo;
        }
        public void crearCiclista(int nBici,string nom,string cat)
        {
            nuevo = new NodoCiclista();
            nuevo.set_nBici(nBici);
            nuevo.set_nomCic(nom);
            nuevo.set_cat(cat);
            nuevo.set_ant(null);
            nuevo.set_sig(null);
        }
        public void agregar(int nBici,string nom,string cat)
        {
            crearCiclista(nBici, nom, cat);
            if(cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                NodoCiclista punt = cabeza;
                while(punt.get_sig() != null)
                {
                    punt = punt.get_sig();
                }
                punt.set_sig(nuevo);
                nuevo.set_ant(punt);
            }
        }
        public NodoCiclista existe_nBici(int nBici)
        {
            NodoCiclista punt = cabeza;
            while(punt != null)
            {
                if (punt.get_nBici() == nBici) 
                    return punt;
                punt = punt.get_sig();
            }
            return punt;
        }
        public void eliminar(NodoCiclista nodo)
        {
            NodoCiclista del = existe_nBici(nodo.get_nBici());//txt_nBici
            if (del != null)
            {   
                if(cabeza == del)
                {
                    if(cabeza.get_sig() == null)
                    {
                        cabeza = null;
                    }
                    else
                    {
                        NodoCiclista sig = cabeza;
                        cabeza = sig.get_sig();
                        sig.set_sig(null);
                        cabeza.set_ant(null);
                    }
                }
                else
                {
                    NodoCiclista ant = del.get_ant(), sig = del.get_sig();
                    ant.set_sig(sig);
                    sig.set_ant(ant);

                    del.set_ant(null);
                    del.set_sig(null);
                }
            }
        }
    }
}
