﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaDobleEnlazada
{
    public partial class frm_ciclistas : Form
    {
        public frm_ciclistas()
        {
            InitializeComponent();
        }

        private void frm_ciclistas_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txt_nom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                txt_nBici.Focus();
               
            }
        }

        private void txt_nBici_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_nBici_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                cmb_cat.Focus();
            }
        }

        private void btn_reg_Click(object sender, EventArgs e)
        {
            Estatica.ciclistas.agregar(int.Parse(txt_nBici.Text), txt_nom.Text, cmb_cat.Text);
            MessageBox.Show("Ciclista Registrado");
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_principal principal = new frm_principal();
            this.Hide();
            principal.Show();
        }
    }
}
