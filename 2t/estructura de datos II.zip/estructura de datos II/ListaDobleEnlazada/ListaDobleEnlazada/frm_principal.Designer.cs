﻿
namespace ListaDobleEnlazada
{
    partial class frm_principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_menu_ciclista = new System.Windows.Forms.GroupBox();
            this.btn_buscar_cic = new System.Windows.Forms.Button();
            this.btn_mostrar_cic = new System.Windows.Forms.Button();
            this.btn_reg_cic = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_buscar_ca = new System.Windows.Forms.Button();
            this.btn_mostrar_ca = new System.Windows.Forms.Button();
            this.btn_reg_ca = new System.Windows.Forms.Button();
            this.btn_salir = new System.Windows.Forms.Button();
            this.grp_menu_ciclista.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp_menu_ciclista
            // 
            this.grp_menu_ciclista.BackColor = System.Drawing.Color.LightSeaGreen;
            this.grp_menu_ciclista.Controls.Add(this.btn_buscar_cic);
            this.grp_menu_ciclista.Controls.Add(this.btn_mostrar_cic);
            this.grp_menu_ciclista.Controls.Add(this.btn_reg_cic);
            this.grp_menu_ciclista.Location = new System.Drawing.Point(56, 12);
            this.grp_menu_ciclista.Name = "grp_menu_ciclista";
            this.grp_menu_ciclista.Size = new System.Drawing.Size(222, 426);
            this.grp_menu_ciclista.TabIndex = 0;
            this.grp_menu_ciclista.TabStop = false;
            this.grp_menu_ciclista.Text = "MENU CICLISTA";
            // 
            // btn_buscar_cic
            // 
            this.btn_buscar_cic.Location = new System.Drawing.Point(37, 105);
            this.btn_buscar_cic.Name = "btn_buscar_cic";
            this.btn_buscar_cic.Size = new System.Drawing.Size(146, 37);
            this.btn_buscar_cic.TabIndex = 4;
            this.btn_buscar_cic.Text = "BUSCAR CICLISTA";
            this.btn_buscar_cic.UseVisualStyleBackColor = true;
            this.btn_buscar_cic.Click += new System.EventHandler(this.btn_buscar_cic_Click);
            // 
            // btn_mostrar_cic
            // 
            this.btn_mostrar_cic.Location = new System.Drawing.Point(37, 62);
            this.btn_mostrar_cic.Name = "btn_mostrar_cic";
            this.btn_mostrar_cic.Size = new System.Drawing.Size(146, 37);
            this.btn_mostrar_cic.TabIndex = 3;
            this.btn_mostrar_cic.Text = "MOSTRAR REGISTRO";
            this.btn_mostrar_cic.UseVisualStyleBackColor = true;
            this.btn_mostrar_cic.Click += new System.EventHandler(this.btn_mostrar_cic_Click);
            // 
            // btn_reg_cic
            // 
            this.btn_reg_cic.Location = new System.Drawing.Point(37, 19);
            this.btn_reg_cic.Name = "btn_reg_cic";
            this.btn_reg_cic.Size = new System.Drawing.Size(146, 37);
            this.btn_reg_cic.TabIndex = 2;
            this.btn_reg_cic.Text = "REGISTRAR CICLISTA";
            this.btn_reg_cic.UseVisualStyleBackColor = true;
            this.btn_reg_cic.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.groupBox2.Controls.Add(this.btn_buscar_ca);
            this.groupBox2.Controls.Add(this.btn_mostrar_ca);
            this.groupBox2.Controls.Add(this.btn_reg_ca);
            this.groupBox2.Location = new System.Drawing.Point(337, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(222, 426);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MENU CARRERA";
            // 
            // btn_buscar_ca
            // 
            this.btn_buscar_ca.Location = new System.Drawing.Point(37, 105);
            this.btn_buscar_ca.Name = "btn_buscar_ca";
            this.btn_buscar_ca.Size = new System.Drawing.Size(146, 37);
            this.btn_buscar_ca.TabIndex = 4;
            this.btn_buscar_ca.Text = "BUCAR CARRERA";
            this.btn_buscar_ca.UseVisualStyleBackColor = true;
            // 
            // btn_mostrar_ca
            // 
            this.btn_mostrar_ca.Location = new System.Drawing.Point(37, 62);
            this.btn_mostrar_ca.Name = "btn_mostrar_ca";
            this.btn_mostrar_ca.Size = new System.Drawing.Size(146, 37);
            this.btn_mostrar_ca.TabIndex = 3;
            this.btn_mostrar_ca.Text = "MOSTRAR CARRERAS";
            this.btn_mostrar_ca.UseVisualStyleBackColor = true;
            this.btn_mostrar_ca.Click += new System.EventHandler(this.btn_mostrar_ca_Click);
            // 
            // btn_reg_ca
            // 
            this.btn_reg_ca.Location = new System.Drawing.Point(37, 19);
            this.btn_reg_ca.Name = "btn_reg_ca";
            this.btn_reg_ca.Size = new System.Drawing.Size(146, 37);
            this.btn_reg_ca.TabIndex = 2;
            this.btn_reg_ca.Text = "REGISTRAR CARRERA";
            this.btn_reg_ca.UseVisualStyleBackColor = true;
            this.btn_reg_ca.Click += new System.EventHandler(this.btn_reg_ca_Click);
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(700, 412);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(88, 26);
            this.btn_salir.TabIndex = 5;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // frm_principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grp_menu_ciclista);
            this.Name = "frm_principal";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.frm_principal_Load);
            this.grp_menu_ciclista.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_menu_ciclista;
        private System.Windows.Forms.Button btn_buscar_cic;
        private System.Windows.Forms.Button btn_mostrar_cic;
        private System.Windows.Forms.Button btn_reg_cic;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_buscar_ca;
        private System.Windows.Forms.Button btn_mostrar_ca;
        private System.Windows.Forms.Button btn_reg_ca;
        private System.Windows.Forms.Button btn_salir;
    }
}