﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaDobleEnlazada
{
    class ListaDobleCarrera
    {
        NodoCarrera cabeza, nuevo;

        public ListaDobleCarrera()
        {
            cabeza = null;
            nuevo = null;
        }
        public void crearCarrera(int nbici, int tiempo, string lugar, DateTime fecha)
        {
            nuevo = new NodoCarrera();
            nuevo.set_nBici(nbici);
            nuevo.set_tiempo(tiempo);
            nuevo.set_lugar(lugar);
            nuevo.set_fecha(fecha);
            nuevo.set_ant(null);
            nuevo.set_sig(null);
        }
        public NodoCarrera getCabeza()
        {
            return cabeza;
        }
        public void agregar(int nbici, int tiempo, string lugar, DateTime fecha)
        {
            crearCarrera(nbici,tiempo,lugar,fecha);
            if (cabeza == null)
            {
                cabeza = nuevo;
            }
            else
            {
                //insertar al final
                /*NodoCarrera punt = cabeza;
                while (punt.get_sig() != null)
                {
                    punt = punt.get_sig();
                }
                punt.set_sig(nuevo);
                nuevo.set_ant(punt);*/

                //insertar al inicio
                nuevo.set_sig(cabeza);
                cabeza.set_ant(nuevo);
                cabeza = nuevo;
            }
        }
        public void ordenar()
        {
            int t, nb;
            string l;
            DateTime f;
            NodoCarrera i, j = cabeza.get_sig();
            while (j != null)
            {
                t = j.get_tiempo();
                f = j.get_fecha();
                l = j.get_lugar();
                nb = j.get_nBici();

                i = j.get_ant();
                while(i!=null && i.get_tiempo() > t)
                {

                    i.get_sig().set_tiempo(i.get_tiempo());
                    i.get_sig().set_fecha(i.get_fecha());
                    i.get_sig().set_lugar(i.get_lugar());
                    i.get_sig().set_nBici(i.get_nBici());

                    i = i.get_ant();
                }
                if(i == null)
                {
                    i = cabeza;
                    i.set_tiempo(t);
                    i.set_fecha(f);
                    i.set_lugar(l);
                    i.set_nBici(nb);
                }
                else
                {
                    i.get_sig().set_tiempo(t);
                    i.get_sig().set_fecha(f);
                    i.get_sig().set_lugar(l);
                    i.get_sig().set_nBici(nb);
                }

                j = j.get_sig();
            }
        }
    }
}
