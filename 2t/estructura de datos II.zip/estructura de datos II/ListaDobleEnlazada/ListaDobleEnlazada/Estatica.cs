﻿using System;
namespace ListaDobleEnlazada
{
    class Estatica
    {
        public static ListaDobleCilcista ciclistas = new ListaDobleCilcista();
        public static ListaDobleCarrera carreras = new ListaDobleCarrera();
    }
}
