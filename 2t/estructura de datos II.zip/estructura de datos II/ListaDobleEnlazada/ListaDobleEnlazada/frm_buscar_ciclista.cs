﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaDobleEnlazada
{
    public partial class frm_buscar_ciclista : Form
    {
        NodoCiclista encontrado;
        int n;
        public frm_buscar_ciclista()
        {
            InitializeComponent();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_principal principal = new frm_principal();
            this.Close();
            principal.Show();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            n = int.Parse(txt_busca.Text);
            encontrado = Estatica.ciclistas.existe_nBici(n);
            if(encontrado != null)
            {
                MessageBox.Show("Numero encontrado");
                grp_busqueda.Visible = true;
                lbl_nom.Text = encontrado.get_nomCic();
                lbl_nBici.Text = encontrado.get_nBici().ToString();
                lbl_cat.Text = encontrado.get_cat();
            }
            else
            {
                MessageBox.Show("No existe ese numero");
            }
        }

        private void grp_busqueda_Enter(object sender, EventArgs e)
        {

        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            Estatica.ciclistas.eliminar(encontrado);
            if(Estatica.ciclistas.existe_nBici(n) == null)
            {
                MessageBox.Show("Nodo Eliminado");
            }
            else
            {
                MessageBox.Show("Error, no se pudo eliminar");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
