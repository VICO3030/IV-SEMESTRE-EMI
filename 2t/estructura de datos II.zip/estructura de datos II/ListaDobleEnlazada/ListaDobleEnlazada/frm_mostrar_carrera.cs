﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaDobleEnlazada
{
    public partial class frm_mostrar_carrera : Form
    {
        public frm_mostrar_carrera()
        {
            InitializeComponent();
        }
        public void mostrar()
        {
            dgv_mostrar.Rows.Clear();
            NodoCarrera punt = Estatica.carreras.getCabeza();
            while(punt != null)
            {
                dgv_mostrar.Rows.Add(punt.get_nBici(), punt.get_fecha(), punt.get_tiempo(), punt.get_lugar());
                punt = punt.get_sig();
            }
        }
        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_principal principal = new frm_principal();
            this.Close();
            principal.Show();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            mostrar();
        }

        public void tabla()
        {
            NodoCarrera punt = Estatica.carreras.getCabeza();
            int c = 1;
            while(punt != null)
            {
                punt.set_lugar(c.ToString());
                
                switch (int.Parse(punt.get_lugar())){
                    case 1: punt.set_lugar("primero");break;
                    case 2: punt.set_lugar("segundo"); break;
                    case 3: punt.set_lugar("tercero"); break;
                    case 4: punt.set_lugar("cuarto"); break;
                    case 5: punt.set_lugar("quinto"); break;
                    case 6: punt.set_lugar("sexto"); break;
                    case 7: punt.set_lugar("septimo"); break;
                    case 8: punt.set_lugar("octavo"); break;
                    case 9: punt.set_lugar("noveno"); break;
                    case 10: punt.set_lugar("decimo"); break;
                    default: punt.set_lugar("desclasificado");break;
                }

                punt = punt.get_sig();
                c++;
            }


        }
        private void btn_ord_Click(object sender, EventArgs e)
        {
            Estatica.carreras.ordenar();
            tabla();
            mostrar();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
