package com.example.judokas.Modelo;

import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;

public class Estatica {
    public static Lista<Municipio> municipios = new Lista<>();

}
