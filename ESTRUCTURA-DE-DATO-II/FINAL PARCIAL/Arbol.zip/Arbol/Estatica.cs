﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arbol
{
    class Estatica
    {
        public static Arbol A = new Arbol();
        public static Cola C = new Cola();
    }
}
