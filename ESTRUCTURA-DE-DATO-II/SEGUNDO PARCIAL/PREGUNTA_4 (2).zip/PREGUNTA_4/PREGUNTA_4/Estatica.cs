﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace PREGUNTA_4
{
    class Estatica
    {
        public static Cola imp = new Cola();
    }
}
