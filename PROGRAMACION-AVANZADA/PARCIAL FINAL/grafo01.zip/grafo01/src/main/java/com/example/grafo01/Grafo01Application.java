package com.example.grafo01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grafo01Application {

	public static void main(String[] args) {
		SpringApplication.run(Grafo01Application.class, args);
	}

}
