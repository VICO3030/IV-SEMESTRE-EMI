package com.example.original;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class JUDOKAcontrolar {
    public TextField txt_nom;
    public Label lbl_nom;

    public void registrar(KeyEvent keyEvent) {
        System.out.println(txt_nom.getText());
        lbl_nom.setText("PRUEa superada "+txt_nom.getText());
    }
}
