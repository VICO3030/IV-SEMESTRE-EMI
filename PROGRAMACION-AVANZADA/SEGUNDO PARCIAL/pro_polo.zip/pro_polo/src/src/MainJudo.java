import JudoModel.Judo;
import JudoModel.Municipio;
import PrograAvan.Lineal.Lista;

public class MainJudo {
    public static void main(String[] args) {

        Judo[] lista = new Judo[3];
        lista[0]= new Judo("victor","caceres", 2004,"masculino","primera",16);
        lista[1]= new Judo("leandro","caceres", 2010,"masculino","tercera",56);
        lista[2]= new Judo("carla","paco", 2008,"femenino","quinta",46);


    }
}
