import JudoModel.Club;

public class MainClub {
    public static void main(String[] args) {
        Club[] lista = new Club[3];
        lista[0] = new Club("sanRoque", 465,"final America");
        lista[1]= new Club("leones",56,"laguna alalay");
        lista[2]= new Club("warrios", 23,"filex capriles");



    }
}
