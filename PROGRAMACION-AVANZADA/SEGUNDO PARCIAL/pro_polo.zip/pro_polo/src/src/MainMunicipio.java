import JudoModel.Municipio;

public class
MainMunicipio  {
    public static void main(String[] args) {
        Municipio[] lista = new Municipio[3];
        lista[0]=  new Municipio("punata",123456);
        lista[1]=  new Municipio("Tiquipaya",54698);
        lista[2] =  new Municipio("sacaba", 5653);

    }
}
