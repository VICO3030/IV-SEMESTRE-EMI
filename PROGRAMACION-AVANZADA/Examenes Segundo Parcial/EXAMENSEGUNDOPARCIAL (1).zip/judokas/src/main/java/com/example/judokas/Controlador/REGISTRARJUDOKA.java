package com.example.judokas.Controlador;

import com.example.judokas.HelloApplication;
import com.example.judokas.Modelo.Club;
import com.example.judokas.Modelo.Estatica;
import com.example.judokas.Modelo.JUDOKA;
import com.example.judokas.Modelo.Municipio;
import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class REGISTRARJUDOKA implements Initializable  {
    public Label lbl_fech;
    public TextField txtFecha;
    public Label lblPeso;
    public TextField txtPeso;
    public RadioButton rdbM;
    public RadioButton rdbF;
    public ComboBox cmbCat;
    public ComboBox cmbClubes;
    public ComboBox cmbMunicipio;

    public AnchorPane frmMain;
    public Label lblNombre;
    public TextField txtNombrej;
    public Label lblApellido;
    public TextField txtApellidoj;
    public Label lblCategoria;
    public TextField txtCategoria;
    public Label lblGenero;
    public TextField txtGenero;
    public Button btnRegistrar;
    public Label lblNombre2;
    public Label lblMunis2;
    public ComboBox cmbMunicipio2;
    public TableColumn dgvJudokas;
    public RadioButton rdbM2;
    public RadioButton rdbF2;
    public ComboBox cmbCat2;
    public Button btnBuscar;
    public ListView lstJudokasCat;
    public ComboBox cmbClubes2;
    public Button btnBuscar2;
    public ListView lstJudokasOrd;
    public TextField txtCantM;
    public Label lblCategoria3;
    public ComboBox cmbClubes3;
    public ComboBox cmbMunicipio3;
    public ComboBox cmbClubes4;
    public Button btnBuscar4;
    public TextField txtId;
    public Button btnP2;
    public Button btnP3;
    private Stage stage;
    public void setVentanaprincipal(Stage stage)
    {
        this.stage=stage;
    }
    public void ejmplito(MouseEvent mouseEvent) {
    }

    public void clickRegistrar(MouseEvent mouseEvent) {
        char genero;
        if (rdbF.isSelected()) genero='F';
        else genero='M';
        JUDOKA j;
        j =new JUDOKA(txtNombrej.getText(),txtApellidoj.getText(),genero,txtFecha.getText(),cmbCat.getSelectionModel().getSelectedItem().toString(),Float.parseFloat(txtPeso.getText()));
        int idMunis=cmbMunicipio.getSelectionModel().getSelectedIndex();
        int idClub=cmbClubes.getSelectionModel().getSelectedIndex();
        Estatica.municipios.get(idMunis).getClubes().get(idClub).anadir_Judoka(j);

        System.out.println(j);
        for(Municipio n: Estatica.municipios){
            System.out.println(n);
            n.mostrarClubes();
        }
    }

    public void cambiarF(MouseEvent mouseEvent) throws IOException {
        if(rdbF.isSelected()==rdbM.isSelected()){
            rdbF.setSelected(false);
        }
        System.out.println(cmbCat.getSelectionModel().getSelectedItem());

        cmbCat.getItems().removeAll(cmbCat.getItems());
        cmbCat.getItems().addAll("-60", "-66", "-73", "-81", "-90", "-100", "+100");
    }

    public void cambiarM(MouseEvent mouseEvent) {
        if(rdbF.isSelected()==rdbM.isSelected()){
            rdbM.setSelected(false);
        }
        cmbCat.getItems().removeAll(cmbCat.getItems());
        cmbCat.getItems().addAll("-48", "-52", "-57", "-63", "-70", "-78", "+78");

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        cmbCat.getItems().removeAll(cmbCat.getItems());
        cmbMunicipio.getItems().removeAll(cmbMunicipio.getItems());
        cmbMunicipio2.getItems().removeAll(cmbMunicipio2.getItems());
        cmbMunicipio3.getItems().removeAll(cmbMunicipio3.getItems());
        for (Municipio m:Estatica.municipios){
            cmbMunicipio.getItems().add(m.getNombre());
            cmbMunicipio2.getItems().add(m.getNombre());
            cmbMunicipio3.getItems().add(m.getNombre());
        }
        cmbCat.getItems().addAll("SELECCIONE UN GENRO");
        cmbCat.getSelectionModel().select("");
        p2();
    }

    public void cambiarMunicipio(ActionEvent actionEvent) {
        int idMunis=cmbMunicipio.getSelectionModel().getSelectedIndex();
        System.out.println(idMunis);
        cmbClubes.getItems().removeAll(cmbClubes.getItems());
        Lista <Club>c=Estatica.municipios.get(idMunis).getClubes();
        for(Club n:c){
            System.out.println(n);
            cmbClubes.getItems().add(n.getNombre());
        }
    }

    public void cambiarMunicipio2(MouseEvent mouseEvent) {

    }

    public void cambiarClub(MouseEvent mouseEvent) {

    }

    public void mostrarcategorias(ActionEvent actionEvent) {
    }

    public void cambiarF2(MouseEvent mouseEvent) {
        if(rdbF2.isSelected()==rdbM2.isSelected()){
            rdbF2.setSelected(false);
        }
        System.out.println(cmbCat2.getSelectionModel().getSelectedItem());

        cmbCat2.getItems().removeAll(cmbCat2.getItems());
        cmbCat2.getItems().addAll("-60", "-66", "-73", "-81", "-90", "-100", "+100");
    }

    public void cambiarM2(MouseEvent mouseEvent) {
        if(rdbF2.isSelected()==rdbM2.isSelected()){
            rdbM2.setSelected(false);
        }
        cmbCat2.getItems().removeAll(cmbCat2.getItems());
        cmbCat2.getItems().addAll("-48", "-52", "-57", "-63", "-70", "-78", "+78");

    }

    public void clickBuscar(MouseEvent mouseEvent) {
        int idMunis=cmbMunicipio2.getSelectionModel().getSelectedIndex();
        Lista<JUDOKA>x=Estatica.municipios.get(idMunis).getTodosJudokas();
        Lista<JUDOKA> porCat=new Lista<>();
        lstJudokasCat.getItems().removeAll(lstJudokasCat.getItems());
        for (int i=0;i< x.getTam();i++)
        {
            if(x.get(i).getCategoria()==cmbCat2.getSelectionModel().getSelectedItem().toString())
            {
                porCat.insertar(x.get(i));
                lstJudokasCat.getItems().add(x.get(i).getNombre()+"  "+x.get(i).getApellido()+"  "+x.get(i).getCategoria());
            }
        }
        for(JUDOKA n:porCat){
            System.out.println(n);
        }
    }

    public void clickMostrarOrdenado(MouseEvent mouseEvent) {
        int idMunis=cmbMunicipio3.getSelectionModel().getSelectedIndex();
        int idClub=cmbClubes3.getSelectionModel().getSelectedIndex();
        Lista<JUDOKA>x=Estatica.municipios.get(idMunis).getClubes().get(idClub).getJudos();
        int tope=Integer.parseInt(txtCantM.getText());
        if(x.getTam()<tope){
            System.out.println("No SE PUEDE LLEGAR HASTA ESE PUNTO");
            tope=x.getTam();
        }
        lstJudokasOrd.getItems().removeAll(lstJudokasOrd.getItems());
        for (int i=0;i< tope;i++)
        {
            lstJudokasOrd.getItems().add(i+"   "+x.get(i).getNombre()+"  "+x.get(i).getApellido()+"  "+x.get(i).getCategoria());
        }
    }

    public void cambiarMunicipio3(ActionEvent actionEvent) {
        int idMunis=cmbMunicipio3.getSelectionModel().getSelectedIndex();
        cmbClubes3.getItems().removeAll(cmbClubes3.getItems());
        Lista <Club>c=Estatica.municipios.get(idMunis).getClubes();
        for(Club n:c){
            System.out.println(n);
            cmbClubes3.getItems().add(n.getNombre());
        }

    }

    public void clickMostrarCubes(MouseEvent mouseEvent) {

        /*
        for(Club n:c){
            if()
            System.out.println(n);
            cmbClubes3.getItems().add(n.getNombre());
        }*/
    }

    public void clickP2(MouseEvent mouseEvent) {
        int idMunis=cmbMunicipio3.getSelectionModel().getSelectedIndex();
        Lista<Club>c=Estatica.municipios.get(idMunis).getordenado();
        for (Club xd:c){
            System.out.println(xd+" "+xd.tam());
        }
    }
    public void p2(){
        Lista<Club>c=Estatica.municipios.get(2).getordenado();
        for (Club xd:c){
            //System.out.println(xd+" "+xd.tam());
        }
    }
    public void clickP3(MouseEvent mouseEvent) {
        int idMunis=cmbMunicipio3.getSelectionModel().getSelectedIndex();
        Lista<JUDOKA>ls=Estatica.municipios.get(idMunis).judokaId(Integer.parseInt(txtCantM.getText()));
        for (JUDOKA j:ls){
            System.out.println(j.getNombre());
        }
    }
    public void pregunta4(){
        int id=1;/*
        for (int i=0;i<Estatica.municipios.getTam();i++){
            JUDOKA xd=Estatica.municipios.get(i).buscarJudokaCi();
        }*/

       // Estatica.municipios.get(0).getClubes().get(0).anadir_Judoka(xd);

    }
}
