package com.example.judokas.Modelo;

import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;
import com.example.judokas.Modelo.PrograAvan.Lineal.Nodo;
import com.example.judokas.Modelo.PrograAvan.NoLineal.ArbolBinario;
import com.example.judokas.Modelo.PrograAvan.NoLineal.ArbolRB;

import java.util.Random;

public class Torneo {
    String nombre;
    String fecha;
    Lista<JUDOKA> participantes;
    Lista<Integer> victorias;
    ArbolRB<Integer,JUDOKA> participantesA;
    ArbolBinario<Integer,JUDOKA> eliminacionD;
    int tam;
    String clase;
    Random r=new Random();
    Lista<JUDOKA>aux;
    public Torneo(String nombre, String fecha) {
        this.nombre = nombre;
        this.fecha = fecha;
        tam=0;
        this.participantes = new Lista<>();
        victorias=new Lista<>();
        eliminacionD=new ArbolBinario<>();
        this.participantesA = new ArbolRB<>();
    }
    public void añadirParticipante(JUDOKA part)
    {
        tam++;
        participantes.insertar(part);
        victorias.insertar(0);
        participantesA.insertar(tam,part);

    }
    public void claseTorneo()
    {
        if (tam<=5)clase="ROUND ROBIN";
        else clase="ELIMINACION DIRECTA";
        System.out.println("EL TORNEO ES TIPO:" +clase);
    }
    public void comenzarTorneo(){
        if (tam<=5)
        {
            for(int i=1;i<tam;i++){
                for (int j=i+1;j<=tam;j++)
                {
                    combate(i-1,j-1);
                }
            }
            int idmax=0;
            for (int i=1;i<tam;i++){
                if (victorias.get(idmax)< victorias.get(i)){
                    idmax=i;
                }
            }
            System.out.println("EL JUDOKA GANDOR CON MAS VICTORIAS ES: "+participantes.get(idmax).getNombre());
        }
        else{
            if(tam<8){
                while(tam!=8){
                    añadirParticipante(null);
                }
            }
            sorteo();
            añadirArbol();
            combate(1,3);
            combate(5,7);
            combate(9,11);
            combate(13,15);
            combate(2,6);
            combate(10,14);
            combate(4,12);
            System.out.println("EL GANADOR DEFINITIVO ES: "+eliminacionD.get_nodo_by_llave(8));

        }
    }
    public void sorteo(){
        aux=new Lista<>();
        int[]vec=new int[8];
        int i=0;
        while(aux.getTam()!=8){
            int id;
            do{
                id=r.nextInt(0,7);

            }while(existeId(id,vec,i));

            vec[i]=id;

            System.out.println(vec[i]+"Holas"+id);
            aux.insertar(participantes.get(id));
            if((i+1)%2==0){
                if(aux.get(i)==null && aux.get(i-1)==null){
                    sorteo();
                    return;
                }
            }
            i++;
        }
    }
    public boolean existeId(int id,int[] v,int lim){
        for (int i=0;i<lim;i++)
        {

            if(v[i]==id){
                return true;
            }
        }
        return false;
    }
    public void añadirArbol(){
        eliminacionD.insertar(1,aux.get(1));
        eliminacionD.insertar(3,aux.get(2));
        eliminacionD.insertar(5,aux.get(3));
        eliminacionD.insertar(7,aux.get(4));
        eliminacionD.insertar(9,aux.get(5));
        eliminacionD.insertar(11,aux.get(6));
        eliminacionD.insertar(13,aux.get(7));
        eliminacionD.insertar(15,aux.get(8));
        eliminacionD.insertar(2,null);
        eliminacionD.insertar(4,null);
        eliminacionD.insertar(6,null);
        eliminacionD.insertar(8,null);
        eliminacionD.insertar(10,null);
        eliminacionD.insertar(12,null);
        eliminacionD.insertar(14,null);

    }
    public void combate(int c1,int c2){

        if (tam<=5)
        {
            System.out.println(participantes.get(c1).nombre +" VS "+ participantes.get(c2).nombre);
            if(r.nextInt(1,10)%2==0){
                System.out.println(participantes.get(c1)+" ES EL GANDADOR");
                victorias.set(c1,victorias.get(c1)+1);
            }else {
                System.out.println(participantes.get(c2)+" ES EL GANDADOR");
                victorias.set(c2,victorias.get(c2)+1);
            }
        }
        else{
            System.out.println(eliminacionD.get_element_by_llave(c1).nombre +" VS "+ eliminacionD.get_element_by_llave(c2).nombre);
            if(r.nextInt(1,10)%2==0){
                System.out.println(eliminacionD.get_element_by_llave(c1)+" ES EL GANDADOR");
                eliminacionD.cambiarDato((c1+c2)/2,eliminacionD.get_element_by_llave(c1));
            }else {
                System.out.println(eliminacionD.get_element_by_llave(c2) +" ES EL GANDADOR");
                eliminacionD.cambiarDato((c1+c2)/2,eliminacionD.get_element_by_llave(c2));
            }
        }
    }
}
