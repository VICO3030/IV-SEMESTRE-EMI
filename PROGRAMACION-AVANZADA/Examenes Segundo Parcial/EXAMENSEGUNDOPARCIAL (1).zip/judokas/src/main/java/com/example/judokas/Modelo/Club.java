package com.example.judokas.Modelo;

import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;
import com.example.judokas.Modelo.PrograAvan.NoLineal.ArbolRB;

public class Club {
    String nombre;
    String personeria;
    String direccion;
    ArbolRB<Integer, JUDOKA> judokas;
    int num_int= 0;

    public Club(String nombre, String personeria, String direccion) {
        this.nombre = nombre;
        this.personeria = personeria;
        this.direccion = direccion;
        this.judokas = new ArbolRB<Integer, JUDOKA>();
    }
    public int tam(){
        return num_int;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPersoneria() {
        return personeria;
    }

    public void setPersoneria(String personeria) {
        this.personeria = personeria;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public ArbolRB<Integer,JUDOKA> getJudokas() {
        return judokas;
    }
    public void actualizar_num_int(){
        num_int++;
    }

    public void anadir_Judoka(JUDOKA judoka) {
        actualizar_num_int();
        judokas.insertar(num_int,judoka);
    }
    public void mostrarJudokas()
    {
        judokas.amplitud();
    }
    public JUDOKA mostrarJudoka(int id)
    {
        return judokas.getValorByLlave(id);
    }
    public Lista<JUDOKA> getJudos()
    {
        return judokas.getAmplitud();
    }

    @Override
    public String toString() {
        return "Club{" +
                "nombre='" + nombre + '\'' +
                ", personeria='" + personeria + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}
