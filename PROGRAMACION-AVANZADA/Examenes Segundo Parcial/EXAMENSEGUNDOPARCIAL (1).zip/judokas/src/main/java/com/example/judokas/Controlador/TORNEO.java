package com.example.judokas.Controlador;

import com.example.judokas.Modelo.*;
import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class TORNEO implements Initializable {
    public ComboBox cmbMunicipio;
    public ComboBox cmbJudokas;
    public Button btnRegistrar;
    public ListView lstInscritos;
    public Button btnComenzar;
    private Stage stage;
    Torneo t;
    Lista<JUDOKA> c;
    public void setVentanaprincipal(Stage ventana) {
        stage=ventana;
    }

    public void cambiarMunicipio(ActionEvent actionEvent) {
        int idMunis=cmbMunicipio.getSelectionModel().getSelectedIndex();
        System.out.println(idMunis);
        cmbJudokas.getItems().removeAll(cmbJudokas.getItems());
        c=Estatica.municipios.get(idMunis).getTodosJudokas();
        for(JUDOKA n:c){
            System.out.println(n);

            cmbJudokas.getItems().add(n.getNombre());
        }
    }

    public void clickRegistrar(MouseEvent mouseEvent) {
        int idMunis=cmbMunicipio.getSelectionModel().getSelectedIndex();
        int idJudoka=cmbJudokas.getSelectionModel().getSelectedIndex();
        lstInscritos.getItems().add(c.get(idJudoka));
        t.añadirParticipante(c.get(idJudoka));

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        t=new Torneo("LOS CONEJITOS","HOY XD");
        cmbJudokas.getItems().removeAll(cmbJudokas.getItems());
        cmbMunicipio.getItems().removeAll(cmbMunicipio.getItems());
        for (Municipio m: Estatica.municipios){

            cmbMunicipio.getItems().add(m.getNombre());
        }
    }

    public void clickComenzar(MouseEvent mouseEvent) {
        t.claseTorneo();
        t.comenzarTorneo();
    }
}
