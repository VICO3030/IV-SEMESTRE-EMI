package com.example.judokas.Modelo;

import com.example.judokas.Modelo.PrograAvan.Lineal.Lista;

public class Municipio {
    String nombre;
    String personeria;
    Lista<Club> clubes;

    public Municipio(String nombre, String personeria) {
        this.nombre = nombre;
        this.personeria = personeria;
        this.clubes = new Lista<Club>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPersoneria() {
        return personeria;
    }

    public void setPersoneria(String personeria) {
        this.personeria = personeria;
    }

    public Lista<Club> getClubes() {
        return clubes;
    }

    public void anadir_club(Club club) {

        this.clubes.insertar(club);
    }
    public void mostrarClubes()
    {
        for (Club c: clubes)
        {
            System.out.println("______________________________________________________________________________________________");
            System.out.println(c);
            System.out.println("______________________________________________________________________________________________");
            c.mostrarJudokas();
        }
    }
    public Lista<JUDOKA> getTodosJudokas()
    {
        Lista<JUDOKA>j=new Lista<>();
        for (Club c: clubes)
        {
            for(int i=0;i<c.getJudos().getTam();i++){
                JUDOKA xd=c.getJudos().get(i);
                j.insertar(xd);
            }
        }
        return j;
    }
    public Lista<JUDOKA> judokaId(int id)
    {
        Lista<JUDOKA>j=new Lista<>();
        for (Club c: clubes)
        {
            if(c.tam()>=id){
                j.insertar(c.mostrarJudoka(id));
            }


        }
        return j;
    }
    public Lista<Club> getordenado()
    {
        Lista<Club>j=new Lista<>();
        int tam=clubes.getTam();
        int []tamId=new int[tam];
        int []Id=new int[tam];
        int i=0;

        for (Club c: clubes)
        {
            tamId[i]=c.judokas.get_tam();
            Id[i]=i;
            i++;
        }
        i=0;
        for (Club c: clubes)
        {int jj=0;
            for (Club x: clubes)
            {
                int aux;
                if(tamId[i]>tamId[jj]){
                    aux=tamId[i];
                    tamId[i]=tamId[jj];
                    tamId[jj]=aux;

                    aux=Id[i];
                    Id[i]=Id[jj];
                    Id[jj]=aux;
                }
                jj++;
            }
            i++;
        }
        i=0;
        for (Club c: clubes)
        {
            j.insertar(clubes.get(Id[i]));
            i++;
        }
        return j;
    }

    /*public void mostrarCat(String ca){
        for(Club c : clubes){
            c.mostrarPorCategorias(ca);
        }
    }*/
    @Override
    public String toString() {
        return "Municipio{" +
                "nombre='" + nombre + '\'' +
                ", personeria='" + personeria + '\'' +
                '}';
    }
}
