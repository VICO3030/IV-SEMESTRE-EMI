public class Main {
    public static void main(String[] args) {
            Juego juego = new Juego(2,3,"EquipoA","EquipoB");
            juego.llenardefe();
            juego.FueradeJuego();
    }
}
