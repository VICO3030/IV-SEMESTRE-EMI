package Librerias.PrograAvan.Lineal;

import java.io.Serializable;

public class Nodo<T> implements Serializable {
    public T item;
    public Nodo<T> enlace;
}
